/*-
 * Copyright (C) 2005 Erik Larsson
 * 
 * All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

package mathgame.devutils.mgsv1toolbox;

import mathgame.common.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import java.io.*;
import java.util.*;
import java.net.URL;

public class DocumentPane extends JPanel {
    private String name;
    private MGSv1Toolbox owner;
    private JPanel middlePanel;
    private JPanel southPanel;
    private JTextArea statusArea;
    private JButton moveUpButton;
    private JButton moveDownButton;
    private JButton addFilesButton;
    private JButton deleteButton;
    private JButton clearButton;
    private JButton writeFileButton;
    private JLabel itemCountLabel;
    //private JFileChooser imageFileChooser;
    //private JFileChooser saveFileChooser;
    private JTable userTable;
    private DefaultTableModel tableModel;
    private JScrollPane scrollPane;
    private Vector<String> columnNames;
    //private Vector<Vector<String>> rowData;
    //private HashMap<Vector<String>, MGSv1Frame> frames;
    private Vector<MGSv1Frame> frames;
    
    /*
    public static class DataPair<Left, Right> {
	private Left left;
	private Right right;
	public DataPair(Left left, Right right) {
	    this.left = left;
	    this.right = right;
	}
	public A getLeft() { return left; }
	public B getRight() { return right; }
	public String toString() { return left.toString(); }
    }
    */

    public DocumentPane(String name, MGSv1Toolbox owner) {
	this.name = name;
	this.owner = owner;
	//frames = new HashMap<Vector<String>, MGSv1Frame>();
	frames = new Vector<MGSv1Frame>();
	middlePanel = new JPanel();
	southPanel = new JPanel();
	statusArea = new JTextArea();
	moveUpButton = new JButton(new ImageIcon(ResourceConstants.BUTTON_ARROWUP));
	moveDownButton = new JButton(new ImageIcon(ResourceConstants.BUTTON_ARROWDOWN));
	addFilesButton = new JButton("L�gg till filer...");
	deleteButton = new JButton("Ta bort");
	clearButton = new JButton("Rensa");
	writeFileButton = new JButton("Skriv MGS-fil...");
	itemCountLabel = new JLabel("0 rader");
	//imageFileChooser = new JFileChooser();
	//saveFileChooser = new JFileChooser();
	columnNames = new Vector<String>(3);
	//rowData = new Vector<Vector<String>>();
	
	setLayout(new BorderLayout(5, 5));
	setBorder(new javax.swing.border.EmptyBorder(5, 5, 5, 5));
	middlePanel.setLayout(new BorderLayout(5, 5));
	southPanel.setLayout(new BorderLayout(5, 5));
	
	//imageFileChooser.setMultiSelectionEnabled(true);

	columnNames.add("Identifierare");
	columnNames.add("Typ");
	columnNames.add("Storlek");
	
	tableModel = new DefaultTableModel(10, 3) {
		public boolean isCellEditable(int row, int col) {
		    if(col == 2)
			return false;
		    else
			return true;
		}
	    };

	userTable = new JTable(tableModel);
	userTable.setCellSelectionEnabled(false);
	userTable.setColumnSelectionAllowed(false);
	userTable.setRowSelectionAllowed(true);
	Vector<Vector<String>> rowData = new Vector<Vector<String>>();
	tableModel.setDataVector(rowData, columnNames);

	scrollPane = new JScrollPane(userTable);

	moveUpButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    moveUpButtonActionPerformed();
		}
	    });
	moveDownButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    moveDownButtonActionPerformed();
		}
	    });

	JPanel arrowsPanel = new JPanel();
	arrowsPanel.setLayout(new GridBagLayout());
	GridBagConstraints c = new GridBagConstraints();
	
	c.fill = GridBagConstraints.VERTICAL;
	c.gridx = 0;
	c.gridy = 0;
	arrowsPanel.add(new JPanel(), c);

	c.fill = GridBagConstraints.NONE;
	c.gridy = 1;
	arrowsPanel.add(moveUpButton, c);
	c.gridy = 2;
	arrowsPanel.add(moveDownButton, c);

	c.fill = GridBagConstraints.VERTICAL;
	c.gridy = 3;
	arrowsPanel.add(new JPanel(), c);

	addFilesButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    addFilesButtonActionPerformed();
		}
	    });
	
	clearButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    clearButtonActionPerformed();
		}
	    });
	
	deleteButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    deleteButtonActionPerformed();
		}
	    });
	
	writeFileButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    writeFileButtonActionPerformed();
		}
	    });

	// Snabbt litet hack nedan. Fixa h�jden till 200.
	//userTable.setPreferredScrollableViewportSize(new Dimension(userTable.getPreferredScrollableViewportSize().width, 200));

	middlePanel.add(scrollPane, BorderLayout.CENTER);
	middlePanel.add(arrowsPanel, BorderLayout.EAST);
	
	//JPanel middleSouthPanel = new JPanel();
	//middleSouthPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 0));
	JPanel southWestPanel = new JPanel();
	southWestPanel.setLayout(new GridBagLayout());
	c = new GridBagConstraints();
	c.gridy = 0;

	c.fill = GridBagConstraints.NONE;
	c.gridx = 0;
	southWestPanel.add(addFilesButton, c);

	c.fill = GridBagConstraints.HORIZONTAL;
	c.gridx = 1;
	southWestPanel.add(new JPanel(), c);

	c.fill = GridBagConstraints.NONE;
	c.gridx = 2;
	southWestPanel.add(deleteButton, c);

	c.fill = GridBagConstraints.HORIZONTAL;
	c.gridx = 3;
	southWestPanel.add(new JPanel(), c);

	c.fill = GridBagConstraints.NONE;
	c.gridx = 4;
	southWestPanel.add(clearButton, c);

	c.fill = GridBagConstraints.HORIZONTAL;
	c.gridx = 5;
	southWestPanel.add(new JPanel(), c);

	c.fill = GridBagConstraints.NONE;
	c.gridx = 6;
	southWestPanel.add(writeFileButton, c);

	JPanel southEastPanel = new JPanel();
	southEastPanel.add(itemCountLabel);

	
	southPanel.add(southWestPanel, BorderLayout.CENTER);
	//	southPanel.add(new JPanel(), BorderLayout.CENTER);
	southPanel.add(southEastPanel, BorderLayout.EAST);
	/*
	c.fill = GridBagConstraints.HORIZONTAL;
	c.gridx = 7;
	southWestPanel.add(new JPanel(), c);

	c.fill = GridBagConstraints.NONE;
	c.gridx = 8;
	//c.anchor = GridBagConstraints.EAST;
	c.anchor = GridBagConstraints.WEST;
	southPanel.add(itemCountLabel, c);
	*/
	/*
	c.fill = GridBagConstraints.HORIZONTAL;
	c.gridx = 3;
	southPanel.add(new JPanel(), c);
	*/

	/*
	deleteButton.setAlignmentX(0.5f);
	clearButton.setAlignmentX(0.5f);
	*/

	/*
	southPanel.add(addFilesButton, BorderLayout.WEST);
	//middleSouthPanel.add(clearButton);
	middleSouthPanel.add(deleteButton, BorderLayout.WEST);
	middleSouthPanel.add(clearButton, BorderLayout.EAST);
	southPanel.add(middleSouthPanel, BorderLayout.CENTER);
	southPanel.add(writeFileButton, BorderLayout.EAST);
	*/
	add(middlePanel, BorderLayout.CENTER);
	add(southPanel, BorderLayout.SOUTH);
    }
    
    public DocumentPane(String name, MGSv1Toolbox owner, java.util.List<MGSv1Frame> frameList) {
	this(name, owner);
	
	Vector<Vector<String>> dataVector = getDataVector();
	for(int i = 0; i < frameList.size(); i++) {
	    Vector<String> temp = new Vector<String>();
	    MGSv1Frame current = frameList.get(i);
	    
	    temp.add(current.getFrameIdentifier());
	    temp.add(current.getContentType());
	    temp.add(getByteSizeString(current.getFrameSize()-current.getHeaderSize()));

	    dataVector.add(temp);
	    frames.add(current);
	}
	setDataVector(dataVector);
    }
    
    public String getName() {
	return name;
    }

    public Vector<Vector<String>> getDataVector() {
	Vector sourceVector = tableModel.getDataVector();
	Vector<Vector<String>> destinationVector = new Vector<Vector<String>>(sourceVector.size());
	for(int i = 0; i < sourceVector.size(); i++) {
	    Object o = sourceVector.get(i);
	    if(o instanceof Vector) {
		Vector v = (Vector)o;
		Vector<String> currentRow = new Vector<String>(v.size());
		for(int j = 0; j < v.size(); j++)
		    currentRow.add(v.get(j).toString());
		
		destinationVector.add(currentRow);
	    }
	    else throw new RuntimeException("Invalid type in vector...");
	}
	return destinationVector;
    }

    public void setDataVector(Vector dataVector) {
	//Vector<Vector<String>> dataVector = getRowData();
	tableModel.setDataVector(dataVector, columnNames);
	itemCountLabel.setText(dataVector.size() + " rader");
    }
    public boolean extractSelectedFields(File saveDir) {
	try {
	    HashMap<File, MGSv1Frame> fileData = new HashMap<File, MGSv1Frame>();
	    Vector dataVector = getDataVector();
	    for(int i = 0; i < tableModel.getRowCount(); i++) {
		Vector currentRow = (Vector)dataVector.get(i);
		MGSv1Frame correspondingFrame = frames.get(i);
		
		String identifier = currentRow.get(0).toString();//tableModel.getValueAt(i, 0).toString();
		String type = currentRow.get(1).toString();//tableModel.getValueAt(i, 1).toString();
		String filename;
		if(identifier.trim().equals("")) {
		    JOptionPane.showMessageDialog(this, "Alla f�lt av typen 'Identifierare' m�ste vara ifyllda", 
						  "Fel", JOptionPane.ERROR_MESSAGE);
		    return false;
		}
		else if(type.trim().equals(""))
		    filename = identifier;
		else
		    filename = identifier.trim() + "." + type.trim();
		
		fileData.put(new File(saveDir.getCanonicalPath()+System.getProperty("file.separator")+filename),
			     correspondingFrame);
	    }

	    Set<Map.Entry<File, MGSv1Frame>> mappings = fileData.entrySet();
	    Iterator<Map.Entry<File, MGSv1Frame>> i = mappings.iterator();
	    while(i.hasNext()) {
		Map.Entry<File, MGSv1Frame> e = i.next();
		writeMGSv1Data(e.getValue(), e.getKey());
	    }
	    return true;
	}
	catch(IOException ioe) {
	    ioe.printStackTrace();
	    JOptionPane.showMessageDialog(this, "Fel under extrahering av data. Se konsolen f�r detaljerad information...", "Fel", JOptionPane.ERROR_MESSAGE);
	    return false;
	}
    }
    
    public void writeMGSv1Data(MGSv1Frame frame, File outFile) throws FileNotFoundException, IOException {
	writeMGSv1Data(frame, new FileOutputStream(outFile));
    }
    public void writeMGSv1Data(MGSv1Frame frame, OutputStream out) throws IOException {
	byte buffer[] = new byte[65536]; //64kb-buffer
	InputStream is = frame.getDataInputStream();
	while(true) {
	    int bytesRead = is.read(buffer);
	    out.write(buffer, 0, bytesRead);
	    if(bytesRead < buffer.length)
		break;
	}
	is.close();
	out.close();
    }
    
    public void moveUpButtonActionPerformed() {
	Vector<Vector<String>> dataVector = getDataVector();
	int[] rowsToMove = userTable.getSelectedRows();
	
	if(rowsToMove.length > 0 && rowsToMove[0] != 0) {
	    for(int i = 0; i < rowsToMove.length; ++i) {
		int rowToMove = rowsToMove[i];
		dataVector.set(rowToMove-1, dataVector.set(rowToMove, dataVector.get(rowToMove-1)));
		frames.set(rowToMove-1, frames.set(rowToMove, frames.get(rowToMove-1)));
	    }
	    tableModel.setDataVector(dataVector, columnNames);
	    for(int i = 0; i < rowsToMove.length; ++i) {
		int rowToMove = rowsToMove[i];
		userTable.addRowSelectionInterval(rowToMove-1, rowToMove-1);
	    }
	}
    }
    public void moveDownButtonActionPerformed() {
	Vector<Vector<String>> dataVector = getDataVector();
	int[] rowsToMove = userTable.getSelectedRows();

	if(rowsToMove.length > 0 && rowsToMove[rowsToMove.length-1] != dataVector.size()-1) {
	    for(int i = rowsToMove.length-1; i >= 0; --i) {
		int rowToMove = rowsToMove[i];
		dataVector.set(rowToMove+1, dataVector.set(rowToMove, dataVector.get(rowToMove+1)));
		frames.set(rowToMove+1, frames.set(rowToMove, frames.get(rowToMove+1)));
	    }
	    tableModel.setDataVector(dataVector, columnNames);
	    for(int i = rowsToMove.length-1; i >= 0; --i) {
		int rowToMove = rowsToMove[i];
		userTable.addRowSelectionInterval(rowToMove+1, rowToMove+1);
	    }
	}
    }
    public void addFilesButtonActionPerformed() {
	JFileChooser chooser = owner.getDefaultFileChooser();
	chooser.setMultiSelectionEnabled(true);
	if(chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
	    Vector<Vector<String>> dataVector = getDataVector();
	    File[] selectedFiles = chooser.getSelectedFiles();
	    for(int i = 0; i < selectedFiles.length; i++) {
		File currentFile = selectedFiles[i];
		String filename = currentFile.getName();
		
		int extensionBeginIndex = filename.lastIndexOf('.')+1;
		String mainName, extension;
		if(extensionBeginIndex != 0)
		    mainName = filename.substring(0, extensionBeginIndex-1);
		else
		    mainName = filename;
		if(extensionBeginIndex != 0)
		    extension = filename.substring(extensionBeginIndex);
		else
		    extension = "";

		Vector<String> rowToAdd = new Vector<String>();
		MGSv1Frame frameToAdd = new MGSv1Frame(currentFile, 0, currentFile.length(), mainName, extension);

		rowToAdd.add(mainName);
		rowToAdd.add(extension);
		rowToAdd.add(getByteSizeString(currentFile.length()));
		
		dataVector.add(rowToAdd);		
		frames.add(frameToAdd);
	    }
	    setDataVector(dataVector);
	}
	owner.setCurrentDirectory(chooser.getCurrentDirectory());	    
    }
    public void deleteButtonActionPerformed() {
	Vector dataVector = getDataVector();
	int selectedRow = userTable.getSelectedRow();
	if(selectedRow != -1) {
	    dataVector.remove(selectedRow);
	    frames.remove(selectedRow);

	    setDataVector(dataVector);
	}
    }
    public void clearButtonActionPerformed() {
	Vector dataVector = getDataVector();
	
	dataVector.clear();
	frames.clear();
	
	setDataVector(dataVector);
    }
    public void writeFileButtonActionPerformed() {
	if(tableModel.getDataVector().size() < 1)
	    JOptionPane.showMessageDialog(this, "Listan �r tom. Det finns ingenting att skriva till fil...", "Information", JOptionPane.INFORMATION_MESSAGE);
	else {
	    JFileChooser chooser = owner.getDefaultFileChooser();
	    SimpleFileFilter fileFilter = new SimpleFileFilter();
	    fileFilter.addExtension("mgs");
	    fileFilter.setDescription("Lagringsfil f�r Matematikspelet (*.mgs)"); // MGS = Math-Game Storage
	    chooser.addChoosableFileFilter(fileFilter);
	    chooser.setMultiSelectionEnabled(false);
	    if(chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
		File file = chooser.getSelectedFile();
		if(chooser.getFileFilter() == fileFilter) {
		    try {
			String path = file.getCanonicalPath();
			if(!path.endsWith(".mgs"))
			    path = path + ".mgs";
			file = new File(path);
		    }
		    catch(IOException ioe) {
			// This means getCanonicalPath failed...
			// So what? We'll continue. :)
		    }
		}
		
		MGSv1Writer mgswriter = new MGSv1Writer(file);
		for(int i = 0; i < tableModel.getRowCount(); i++) {
		    String identifier = tableModel.getValueAt(i, 0).toString();
		    String contentType = tableModel.getValueAt(i, 1).toString();
		    if(identifier.trim().equals("") || contentType.trim().equals("")) {
			JOptionPane.showMessageDialog(this, "F�lten 'Identifierare' och 'Typ' m�ste b�da vara ifyllda f�r alla rader.", "Fel", JOptionPane.ERROR_MESSAGE);
			return;
		    }
		    //File currentFile = files.get(i);
		    //System.out.println("Trying to resolve association with " + dataVector.get(i).hashCode());
		    MGSv1Frame f = frames.get(i);
		    f.setFrameIdentifier(identifier.trim());
		    f.setContentType(contentType.trim());
		    //new MGSv1Frame(currentFile, 0, currentFile.length(), identifier.trim(), contentType.trim());
		    mgswriter.addFrame(f);
		}
		mgswriter.write();
		if(!mgswriter.hasWritten())
		    JOptionPane.showMessageDialog(this, "Det gick inte att skriva till filen av ok�nd anledning...", "Fel", JOptionPane.ERROR_MESSAGE);
		else {
		    JOptionPane.showMessageDialog(this, "MGSv1-datat har skrivits till filen " + file.getName(), "Information", JOptionPane.INFORMATION_MESSAGE);
		    name = file.getName();
		    owner.refreshTitles();
		}
	    }
	    owner.setCurrentDirectory(chooser.getCurrentDirectory());
	}
    }

    public String getByteSizeString(long size) {
	final long exbibyte = 1152921504606846976L; //2^60
	final long pebibyte = 1125899906842624L; //2^50
	final long tebibyte = 1099511627776L; //2^40
	final long gibibyte = 1073741824L; //2^30
	final long mebibyte = 1048576L; //2^20
	final long kibibyte = 1024L; //2^10
	if(size >= exbibyte)
	    return size/exbibyte + " EiB";
	else if(size >= pebibyte)
	    return size/pebibyte + " PiB";
	else if(size >= tebibyte)
	    return size/tebibyte + " TiB";
	else if(size >= gibibyte)
	    return size/gibibyte + " GiB";
	else if(size >= mebibyte)
	    return size/mebibyte + " MiB";
	else if(size >= kibibyte)
	    return size/kibibyte + " KiB";
	else 
	    return size + " B";
    }
}
