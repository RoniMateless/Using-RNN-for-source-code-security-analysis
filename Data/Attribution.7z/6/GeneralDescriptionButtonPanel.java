/*-
 * Copyright (C) 2004 Delby Arrospide, Niloofar Ghassemino, Lars Helander, Taghrid Hodroj,
 *                    Magnus Johansson, Caroline Koch, Erik Larsson, Helena Nilsson
 * 
 * All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

package mathgame.login;

import mathgame.common.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class GeneralDescriptionButtonPanel extends JPanel {
    public static final int LEFT_INSETS = 5;
    public static final int RIGHT_INSETS = 5;
    public static final int TOP_INSETS = 0;
    public static final int BOTTOM_INSETS = 0;
    private FixedWidthTextArea descriptionArea;
    private JButton startButton;
    private JCheckBox checkBox;
    
    public GeneralDescriptionButtonPanel(RootTab creator, String title, String description, String buttonText) {
	this(creator, title, description, buttonText, null);
    }
    
    public GeneralDescriptionButtonPanel(RootTab creator, String title, String description, String buttonText, String checkboxText) {
	int width = creator.PREFERRED_WIDTH - creator.LEFT_INSETS - creator.RIGHT_INSETS;

	setLayout(null);
	setBorder(new TitledBorder(title));

	descriptionArea = new FixedWidthTextArea(width-getInsets().left-getInsets().right-LEFT_INSETS-RIGHT_INSETS);
	descriptionArea.setText(description);
	descriptionArea.setOpaque(false);
	add(descriptionArea);
	descriptionArea.setSize(descriptionArea.getPreferredSize());
	descriptionArea.setLocation(getInsets().left+LEFT_INSETS, getInsets().top+TOP_INSETS);

	startButton = new JButton(buttonText);
	add(startButton);
	startButton.setSize(startButton.getPreferredSize());
	startButton.setLocation(descriptionArea.getLocation().x,
				descriptionArea.getLocation().y+descriptionArea.getSize().height+10);

	if(checkboxText != null) {
	    checkBox = new JCheckBox(checkboxText, false);
	    add(checkBox);
	    checkBox.setSize(checkBox.getPreferredSize());
	    checkBox.setLocation(startButton.getLocation().x+startButton.getSize().width+5,
				 startButton.getLocation().y+startButton.getSize().height/2-checkBox.getSize().height/2);
	}

	setPreferredSize(new Dimension(width, startButton.getLocation().y+startButton.getSize().height+BOTTOM_INSETS+getInsets().bottom));
    }
    public void addButtonListener(ActionListener al) {
	startButton.addActionListener(al);
    }
    public boolean isCheckboxSelected() {
	if(checkBox != null)
	    return checkBox.isSelected();
	else
	    return false;
    }
}
