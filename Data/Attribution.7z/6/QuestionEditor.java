package mathgame.question;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import mathgame.common.*;
import java.io.*;

public class QuestionEditor extends JFrame {

    public static final int HEADER = QuestionToolbox.HEADER;
    public static final int FOOTER = QuestionToolbox.FOOTER;
    public static final int TEXT = QuestionToolbox.TEXT;
    public static final int IMAGE = QuestionToolbox.IMAGE;

    private TextQuestionDialog tqd = null;
    private QuestionPane qp = null;
    private int numberOfAnswers;
    private int currentAnswer;

    private String currentSubject = null;
    private int currentLevel = -1;

    public QuestionEditor(){
	Container cont = getContentPane();
	cont.setLayout(new BorderLayout());

	setUpMenu();

	pack();
	setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	setSize(250, 100);
	setLocationRelativeTo(null);
	
	setTitle("Fr�geskaparen");
	setVisible(true);
    }

    
    JMenuItem insertQ;
    JMenuItem insertA;
    JMenuItem exit;
    JMenuItem newquestion;
    JMenuItem openquestion;
    JMenuItem savequestion;
    JMenuItem savetodatabase;
    JMenuItem properties;
    JMenuItem subject;
    JMenuItem level;

    final JFileChooser fileChooser = new JFileChooser(System.getProperty("user.dir"));

    private void setUpMenu(){
	MenuListener mList = new MenuListener();

	insertQ = new JMenuItem("Infoga fr�ga...");
	insertQ.addActionListener(mList);
	insertA = new JMenuItem("Infoga svar...");
	insertA.addActionListener(mList);

	exit = new JMenuItem("Avsluta");
	exit.addActionListener(mList);
	newquestion = new JMenuItem("Skapa ny fr�ga...");
	newquestion.addActionListener(mList);
	openquestion = new JMenuItem("�ppna fr�ga...");
	openquestion.addActionListener(mList);
	savequestion = new JMenuItem("Spara fr�ga...");
	savequestion.addActionListener(mList);
	savetodatabase = new JMenuItem("Spara och l�gg i databas...");
	savetodatabase.addActionListener(mList);

	properties = new JMenuItem("R�tt svarsalternativ...");
	properties.addActionListener(mList);
	subject = new JMenuItem("V�lj matematikmoment...");
	subject.addActionListener(mList);
	level = new JMenuItem("V�lj sv�righetsgrad...");
	level.addActionListener(mList);

	JMenu file = new JMenu("Arkiv");
	file.setMnemonic(KeyEvent.VK_A);
	file.add(newquestion);
	file.add(openquestion);
	file.add(savequestion);
	file.add(savetodatabase);
	file.addSeparator();
	file.add(exit);
	
	JMenu insert = new JMenu("Infoga");
	insert.setMnemonic(KeyEvent.VK_I);
	insert.add(insertQ);
	insert.add(insertA);

	JMenu options = new JMenu("Egenskaper");
	options.setMnemonic(KeyEvent.VK_T);
	options.add(properties);
	options.add(subject);
	options.add(level);

	JMenuBar menubar = new JMenuBar();
	menubar.add(file);
	menubar.add(options);
	menubar.add(insert);
	
	
	setJMenuBar(menubar);
    }

    
    private class MenuListener implements ActionListener {

	public void actionPerformed(ActionEvent e){
	    if(e.getSource() == exit){
		System.exit(0);
	    }
	    else if(e.getSource() == newquestion){
		if(qp != null || tqd != null){
		    JOptionPane.showMessageDialog(QuestionEditor.this, "Du har redan �ppnat en fr�ga", "Fel", 
						  JOptionPane.ERROR_MESSAGE);
		    return;
		}
		new StepOne();
	    }
	    else if(e.getSource() == insertQ){
		insertQuestion();
	    }
	    else if(e.getSource() == insertA){
		insertAnswer();
	    }
	    else if(e.getSource() == openquestion){
		if(qp != null || tqd != null){
		    JOptionPane.showMessageDialog(QuestionEditor.this, "Du har redan �ppnat en fr�ga", 
						  "Fel", JOptionPane.ERROR_MESSAGE);
		    return;
		}
		openQuestion();
	    }
	    else if(e.getSource() == savequestion){
		if(qp == null && tqd == null){
		    JOptionPane.showMessageDialog(QuestionEditor.this, "Du m�ste skapa en fr�ga f�rst.", "Fel", 
						  JOptionPane.ERROR_MESSAGE);
		    return;
		}
		saveQuestion();
	    }
	    else if(e.getSource() == savetodatabase){
		if(qp == null && tqd == null){
		    JOptionPane.showMessageDialog(QuestionEditor.this, "Du m�ste skapa en fr�ga f�rst.", "Fel", 
						  JOptionPane.ERROR_MESSAGE);
		    return;
		}
		saveToDatabase();
	    }
	    else if(e.getSource() == properties){
		setCorrectAnswer();
	    }
	    else if(e.getSource() == subject){
		setSubject();
	    }
	    else if(e.getSource() == level){
		setLevel();
	    }
	}
    }

    private void setSubject(){
	currentSubject = (String) JOptionPane.showInputDialog(QuestionEditor.this, "V�lj matematikmoment", 
							      "Indata", JOptionPane.QUESTION_MESSAGE, null,
							      Database.getSubjects(), currentSubject);
    }

    private void setLevel(){
	try {
	    String temp = (String) JOptionPane.showInputDialog(QuestionEditor.this, 
							       "V�lj sv�righetsgrad", "Indata", 
							       JOptionPane.QUESTION_MESSAGE, null,
							       Database.getLevels(), ""+currentLevel);
	    if(temp == null) return;
	    currentLevel = Integer.parseInt(temp);
	} catch(Exception err){
	    JOptionPane.showMessageDialog(QuestionEditor.this, "Ov�ntat fel. Kontakta utvecklarna. (8H4KLJD)", "Fel", 
					  JOptionPane.ERROR_MESSAGE);
	}
    }

    private void setCorrectAnswer(){
	if(qp == null && tqd == null){
	    JOptionPane.showMessageDialog(QuestionEditor.this, "Du m�ste skapa en fr�ga f�rst.", "Fel", 
					  JOptionPane.ERROR_MESSAGE);
	    return;
	}
	String initial = "Svar ";
	if(qp != null) initial += (qp.correctAnswer+1);
	else if(tqd != null) initial += (tqd.correctAnswer+1);
	String[] values = new String[numberOfAnswers];
	for(int i=0; i<numberOfAnswers; i++)
	    values[i] = "Svar "+(i+1);
	String ans = (String) JOptionPane.showInputDialog(QuestionEditor.this, "V�lj r�tt svar", "Indata",
							  JOptionPane.QUESTION_MESSAGE, null, values, initial);
	if(ans == null) return;
	int ansNo = 0;
	try {
	    ansNo = Integer.parseInt((ans.split("\\s"))[1])-1;
	} catch(Exception err){
	    JOptionPane.showMessageDialog(QuestionEditor.this, "Ov�ntat fel. Kontakta utvecklarna. (7FFH87D)", "Fel", 
					  JOptionPane.ERROR_MESSAGE);
	    return;
	}
	if(qp != null)
	    qp.correctAnswer = ansNo;
	else if(tqd != null)
	    tqd.correctAnswer = ansNo;
	
    }

    private void saveToDatabase(){
	if(qp != null && qp.correctAnswer == -1)
	    setCorrectAnswer();
	else if(tqd != null && tqd.correctAnswer == -1)
	    setCorrectAnswer();
	if(currentSubject == null)
	    setSubject();
	if(currentLevel == -1)
	    setLevel();

	String path = saveQuestion();

	if(path == null) return;

	Database.addQuestion(path, currentSubject, currentLevel);
    }

    private void openQuestion(){
	if(fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION){
	    if(fileChooser.getSelectedFile().exists()){
		try {
		    Question q = QuestionToolbox.loadQuestion(fileChooser.getSelectedFile().getAbsolutePath());
		    if(q instanceof ImageQuestion){
			numberOfAnswers = ((ImageQuestion)q).answers.length;
			qp = new QuestionPane(this, (ImageQuestion)q);
		    }
		    else {
			numberOfAnswers = ((TextQuestion)q).answers.length;
			tqd = new TextQuestionDialog(this, (TextQuestion)q);
		    }
		} catch(Exception e){
		    JOptionPane.showMessageDialog(this, "Felaktig fr�gefil.", "Fel", JOptionPane.ERROR_MESSAGE);
		}
	    }
	}
    }

    // Returns path to question if saving OK, null otherwise or if aborted by user
    private String saveQuestion(){
	if(fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION){
	    if(fileChooser.getSelectedFile().exists()){
		if(JOptionPane.showConfirmDialog(this, "Filen \"" 
						 +fileChooser.getSelectedFile().getAbsolutePath() 
						 + "\" finns redan.\n"
						 + "Forts�tt?", "V�lj fil", 
						 JOptionPane.YES_NO_CANCEL_OPTION, 
						 JOptionPane.QUESTION_MESSAGE) != JOptionPane.YES_OPTION)
		    return null; 
	    }
	    
	    String userdir = fileChooser.getName(new File(System.getProperty("user.dir"))).toLowerCase();
	    String abspath = fileChooser.getSelectedFile().getAbsolutePath().toLowerCase(); 
	    int index = abspath.indexOf(userdir);
	    if(index != -1){
		abspath = abspath.substring(index+userdir.length());
		String fileSep = System.getProperty("file.separator");
		if(abspath.charAt(0) == fileSep.charAt(fileSep.length()-1))
		    abspath = abspath.substring(1);
	    }
	    try {
		if(qp != null)
		    qp.saveQuestion(abspath);
		else if(tqd != null)
		    tqd.saveQuestion(abspath);
	    } catch(Exception e){
		JOptionPane.showMessageDialog(this, "Ett ov�ntat fel intr�ffade.\nFilen sparades kanske inte korrekt.\nKontakta utvecklarna (X7FJ8D7).", "Fel", 
						  JOptionPane.ERROR_MESSAGE);
		return null;
	    }
	    return abspath;
	}
	return null;
    }
    
    
    public void insertQuestion(){
	if(qp == null){
	    JOptionPane.showMessageDialog(this, "Du m�ste skapa en bildfr�ga f�rst.", "Fel", 
						  JOptionPane.ERROR_MESSAGE);
	    return;
	}
	if(fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION){
	    if(fileChooser.getSelectedFile().exists()){
		String filename = fileChooser.getSelectedFile().getPath(); 
		qp.setQuestion(Toolkit.getDefaultToolkit().createImage(filename));
	    }
	}
    }

    public void insertAnswer(){
	if(qp == null){
	    JOptionPane.showMessageDialog(this, "Du m�ste skapa en bildfr�ga f�rst.", "Fel", 
						  JOptionPane.ERROR_MESSAGE);
	    return;
	}
	String initial = "Svar "+(currentAnswer+1);
	if(currentAnswer < numberOfAnswers) currentAnswer++;
	String[] values = new String[numberOfAnswers];
	for(int i=0; i<numberOfAnswers; i++)
	    values[i] = "Svar "+(i+1);
	String ans = (String) JOptionPane.showInputDialog(this, "V�lj svarsalternativ", "Indata",
						 JOptionPane.QUESTION_MESSAGE, null, values, initial);
	if(ans == null) return;
	int ansNo = 0;
	try {
	    ansNo = Integer.parseInt((ans.split("\\s"))[1])-1;
	} catch(Exception e){
	    JOptionPane.showMessageDialog(this, "Ov�ntat fel. Kontakta utvecklarna. (7FACBQD)", "Fel", 
						  JOptionPane.ERROR_MESSAGE);
	    return;
	}
	if(fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION){
	    if(fileChooser.getSelectedFile().exists()){
		String filename = fileChooser.getSelectedFile().getPath(); 
		qp.setAnswer(Toolkit.getDefaultToolkit().createImage(filename), ansNo);
	    }
	}

    }
    
    public void newQuestion(int numberOfAnswers){
	this.numberOfAnswers = numberOfAnswers;
	currentAnswer = 0;
	if(isImage)
	    qp = new QuestionPane(this, numberOfAnswers);
	else
	    tqd = new TextQuestionDialog(this, numberOfAnswers);
    }
    
    public void dispose(String toDispose){
	if(toDispose.equals("qp"))
	    qp = null;
	else if(toDispose.equals("tqd"))
	    tqd = null;
    }


    private class StepOne extends JDialog implements ActionListener {
	
	private JButton next = new JButton("N�sta >");
	//private JButton prev = new JButton("< F�reg�ende");
	private JButton cancel = new JButton("Avbryt");
	
	private JRadioButton text = new JRadioButton("Textfr�ga");
	private JRadioButton image = new JRadioButton("Bildfr�ga");
	
	public StepOne(){
	    super(QuestionEditor.this, true);
	    JPanel p1 = new JPanel();
	    p1.setLayout(new GridLayout(0, 1));
	    p1.add(text);
	    p1.add(image);
	    p1.setBorder(BorderFactory.createEmptyBorder(5, 30, 5, 5));

	    JPanel butPanel = new JPanel();
	    //butPane.add(prev); 
	    butPanel.add(next); butPanel.add(new JLabel("      ")); butPanel.add(cancel);

	    next.addActionListener(this);
	    cancel.addActionListener(this);

	    Container cont = getContentPane();
	    cont.setLayout(new BorderLayout());
	    
	    cont.add(p1);
	    cont.add(butPanel, BorderLayout.SOUTH);
	    cont.add(new JLabel("V�lj om du vill skapa en textfr�ga eller en bildfr�ga."), BorderLayout.NORTH);

	    ((JComponent) cont).setBorder(BorderFactory.createEmptyBorder(5, 5, 0, 5));

	    ButtonGroup bg = new ButtonGroup();
	    bg.add(text);
	    text.setSelected(!isImage);
	    image.setSelected(isImage);
	    bg.add(image);

	    pack();
	    setLocationRelativeTo(QuestionEditor.this);
	    setTitle("Skapa fr�ga 1 av 2");
	    setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e){
	    setVisible(false);
	    
	    if(e.getSource() == next){
		isImage = image.isSelected();
		new StepTwo(this);
	    }
	    
	    dispose();
	    
	}

    }

    private boolean isImage;

    public class StepTwo extends JDialog implements ActionListener {

	private JButton next = new JButton("Slutf�r");
	private JButton prev = new JButton("< F�reg�ende");
	private JButton cancel = new JButton("Avbryt");

	private JTextField noOfAns = new JTextField(5);

	public StepTwo(JDialog jd){
	    super(jd, true);
			 
	    JPanel butPanel = new JPanel();
	    butPanel.add(prev); butPanel.add(next); butPanel.add(new JLabel("      ")); butPanel.add(cancel);
	    prev.addActionListener(this);
	    next.addActionListener(this);
	    cancel.addActionListener(this);

	    JPanel actPanel = new JPanel();
	    actPanel.add(new JLabel("Ange antal svarsalternativ:"));
	    actPanel.add(noOfAns);

	    Container cont = getContentPane();
	    cont.setLayout(new BorderLayout());
	    cont.add(actPanel);
	    cont.add(butPanel, BorderLayout.SOUTH);
	    
	    ((JComponent) cont).setBorder(BorderFactory.createEmptyBorder(5, 5, 0, 5));

	    pack();
	    setLocationRelativeTo(jd);
	    setTitle("Skapa fr�ga 2 av 2");
	    setVisible(true);

	}
	
	public void actionPerformed(ActionEvent e){
	    setVisible(false);
	    
	    if(e.getSource() == next){
		int nans = 3;
		try {
		    nans = Integer.parseInt(noOfAns.getText());
		} catch(Exception err){
		    JOptionPane.showMessageDialog(QuestionEditor.this, "Felaktigt antal givet.", "Fel", 
						  JOptionPane.ERROR_MESSAGE);
		    setVisible(true);
		    return;
		}
		newQuestion(nans);
	    }
	    else if(e.getSource() == prev){
		new StepOne();
	    }
	    
	    dispose();
	    
	}


    }


}
