package mathgame.diagnos;

import mathgame.common.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class SaveDiagnos extends JDialog implements ActionListener {

    private String filename;
    private int maxPoints;

    private String[] subjects = Database.getSubjects();
    private JCheckBox[] moment;
    private JSlider level;

    private JButton saveButton = new JButton("L�gg till");
    private JButton cancelButton = new JButton("Avbryt");

    public SaveDiagnos(JFrame owner, String filename, int maxPoints){
	super(owner, true);
	this.filename = filename;
	this.maxPoints = maxPoints;

	Container c = getContentPane();

	c.setLayout(new BorderLayout());

	JPanel buttonPanel = new JPanel();
	buttonPanel.add(saveButton);
	buttonPanel.add(cancelButton);
	saveButton.addActionListener(this);
	cancelButton.addActionListener(this);

	JPanel centerPanel = new JPanel();
	centerPanel.setLayout(null);
	initContent(centerPanel);
	
	c.add(centerPanel);
	c.add(buttonPanel, BorderLayout.SOUTH);

	setSize(400, 200);
	setResizable(false);
	setTitle("Spara till databas");
	setLocationRelativeTo(owner);
	setVisible(true);
    }

    private void initContent(JPanel c){
	moment = new JCheckBox[subjects.length];

	int x1 = 5;
	int x2 = 250;
	int y = 5;
	int gap = 5;

	JLabel l1 = new JLabel("Ange vilka moment som provet behandlar:");
	l1.setLocation(x1, y);
	l1.setSize(l1.getPreferredSize());
	c.add(l1);

	for(int i=0; i<moment.length; i++){
	    moment[i] = new JCheckBox(subjects[i]);
	    moment[i].setLocation(x2, y);
	    moment[i].setSize(moment[i].getPreferredSize());
	    c.add(moment[i]);
	    y += moment[i].getHeight() + gap;
	}

	y += gap;
	/*
	JLabel l2 = new JLabel("Ange provets sv�righetsgrad");
	l2.setLocation(x1, y);
	l2.setSize(l2.getPreferredSize());
	c.add(l2);

	level = new JSlider(Database.getMinLevel(), Database.getMaxLevel());
	level.setMinorTickSpacing(1);
	level.setMajorTickSpacing(1);
	level.setPaintTicks(true);
	level.setSnapToTicks(true);

	level.setSize(level.getPreferredSize());

	JLabel l2_1 = new JLabel("L�tt");
	JLabel l2_2 = new JLabel("Sv�rt");
	l2_1.setLocation(x2, y);
	l2_1.setSize(l2_1.getPreferredSize());
	l2_2.setSize(l2_2.getPreferredSize());
	l2_2.setLocation(x2 + level.getWidth() - l2_2.getWidth(), y);

	c.add(l2_1);
	c.add(l2_2);

	y += l2_1.getHeight();
	level.setLocation(x2, y);

	c.add(level);
	*/
    }


    public void actionPerformed(ActionEvent e){
	if(e.getSource() == saveButton){
	    int numMoment = 0;
	    for(int i=0; i<moment.length; i++)
		if(moment[i].isSelected()) numMoment++;
	    String[] subj = new String[numMoment];
	    int j = 0;
	    for(int i=0; i<subjects.length; i++){
		if(moment[i].isSelected()){
		    subj[j++] = subjects[i];
		}
	    }
	    Database.addTest(filename, subj, maxPoints);
	}
	setVisible(false);
	dispose();
    }


}
