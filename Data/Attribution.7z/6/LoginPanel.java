/*-
 * Copyright (C) 2004 Delby Arrospide, Niloofar Ghassemino, Lars Helander, Taghrid Hodroj,
 *                    Magnus Johansson, Caroline Koch, Erik Larsson, Helena Nilsson
 * 
 * All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

package mathgame.login;

import mathgame.common.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class LoginPanel extends JPanel {
    
    private MainWindow parent;
    private NewUserDialog newUserDialog = null;
    private JButton loginButton;
    private JButton newUserButton;
    private JLabel mathgameLabel;
    private JLabel loginLabel;
    private JLabel usernameLabel;
    private JLabel passwordLabel;
    private JPasswordField passwordField;
    private JTextField usernameField;
    private String username;

    public LoginPanel(MainWindow parent, int width, int height) {
	this.parent = parent;
	int leftInsets, topInsets;
	leftInsets = width/2;

        mathgameLabel = new JLabel();
        loginLabel = new JLabel();
        usernameField = new JTextField(new TextLengthChecker(Database.SIZE_PERSON_ANVANDARNAMN), "", 15);
        loginButton = new JButton();
        newUserButton = new JButton();
        usernameLabel = new JLabel();
        passwordLabel = new JLabel();
        passwordField = new JPasswordField(new TextLengthChecker(Database.SIZE_PERSON_LOSENORD), "", 15); // No reason really, since pwd is hashed

        setLayout(null);

        mathgameLabel.setFont(mathgameLabel.getFont().deriveFont(18f));
        mathgameLabel.setText("Matematikspelet");
        add(mathgameLabel);
	mathgameLabel.setSize(mathgameLabel.getPreferredSize());
	mathgameLabel.setLocation(-mathgameLabel.getPreferredSize().width/2, 0);

        loginLabel.setFont(loginLabel.getFont().deriveFont(12f));
        loginLabel.setText("Inloggning");
        add(loginLabel);
	loginLabel.setSize(loginLabel.getPreferredSize());
	loginLabel.setLocation(mathgameLabel.getLocation().x+mathgameLabel.getSize().width/2-loginLabel.getSize().width/2,
			       mathgameLabel.getLocation().y+mathgameLabel.getSize().height+10);

        usernameLabel.setHorizontalAlignment(SwingConstants.TRAILING);
        usernameLabel.setText("Anv\u00e4ndarnamn");
        add(usernameLabel);
	usernameLabel.setSize(Math.max(usernameLabel.getPreferredSize().width, passwordLabel.getPreferredSize().width),
			      usernameLabel.getPreferredSize().height);

        passwordLabel.setHorizontalAlignment(SwingConstants.TRAILING);
        passwordLabel.setText("L\u00f6senord");
        add(passwordLabel);
	passwordLabel.setSize(usernameLabel.getSize());
	
	usernameLabel.setLocation(loginLabel.getLocation().x+loginLabel.getSize().width/2-(usernameLabel.getSize().width+10+usernameField.getPreferredSize().width)/2,
				  loginLabel.getLocation().y+loginLabel.getSize().height+15);
	
        usernameField.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent evt) {
                usernameFieldKeyPressed(evt);
            }
        });
        add(usernameField);
	usernameField.setSize(usernameField.getPreferredSize());
	//usernameField.setSize(80, 19);
	usernameField.setLocation(usernameLabel.getLocation().x+usernameLabel.getSize().width+10,
				  (usernameLabel.getLocation().y+usernameLabel.getSize().height/2-
				   usernameField.getSize().height/2));

	passwordLabel.setLocation(usernameLabel.getLocation().x,
				  Math.max(usernameLabel.getLocation().y+usernameLabel.getSize().height, usernameField.getLocation().y+usernameField.getSize().height)+10);

        passwordField.setFont(usernameField.getFont());
        passwordField.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent evt) {
                passwordFieldKeyPressed(evt);
            }
        });
        add(passwordField);
	passwordField.setSize(passwordField.getPreferredSize());
	//passwordField.setSize(80, 19);
	passwordField.setLocation(passwordLabel.getLocation().x+passwordLabel.getSize().width+10,
				  (passwordLabel.getLocation().y+passwordLabel.getSize().height/2-
				   passwordField.getSize().height/2));

        loginButton.setText("Logga in");
        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                loginButtonActionPerformed(evt);
            }
        });
        add(newUserButton);
        add(loginButton);
	loginButton.setSize(loginButton.getPreferredSize());

        newUserButton.setText("Ny anv\u00e4ndare");
        newUserButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                newUserButtonActionPerformed(evt);
            }
        });
        add(newUserButton);
	newUserButton.setSize(newUserButton.getPreferredSize());
	
	loginButton.setLocation(((passwordField.getLocation().x+passwordField.getSize().width-passwordLabel.getLocation().x)/2+passwordLabel.getLocation().x)-(loginButton.getSize().width+10+newUserButton.getSize().width)/2,
				Math.max(passwordLabel.getLocation().y+passwordLabel.getSize().height,
					 passwordField.getLocation().y+passwordField.getSize().height)+15);
	newUserButton.setLocation(loginButton.getLocation().x+loginButton.getSize().width+10, loginButton.getLocation().y);

	if(newUserButton.getLocation().y+newUserButton.getSize().height < height)
	    topInsets = (height-(newUserButton.getLocation().y+newUserButton.getSize().height))/2;
	else
	    topInsets = 0;

	for(Component c : getComponents())
	    c.setLocation(c.getLocation().x+leftInsets, c.getLocation().y+topInsets);
	
	setPreferredSize(new Dimension(width, height));
	setMinimumSize(new Dimension(width, height));
    }

    public String getUsername() {
	return username;
    }

    private void usernameFieldKeyPressed(KeyEvent evt) {
	if(evt.getKeyCode() == KeyEvent.VK_ENTER) {
	    if(!usernameField.getText().trim().equals("")) {
		if(new String(passwordField.getPassword()).trim().equals(""))
		    passwordField.requestFocusInWindow();
		else
		    login();
	    }
	}
    }
    private void passwordFieldKeyPressed(KeyEvent evt) {
	if(evt.getKeyCode() == KeyEvent.VK_ENTER) {
	    if(!new String(passwordField.getPassword()).trim().equals("")) {
		if(usernameField.getText().trim().equals(""))
		    usernameField.requestFocusInWindow();
		else
		    login();
	    }
	}
    }
    private void loginButtonActionPerformed(ActionEvent evt) {
	login();
    }

    private void newUserButtonActionPerformed(ActionEvent evt) {
	if(newUserDialog == null)
	    newUserDialog = new NewUserDialog(parent);
	else
	    newUserDialog.reset();
	newUserDialog.setVisible(true);
    }

    private void login() {
	username = usernameField.getText().trim();
	char[] password = passwordField.getPassword();
	int statusCode = Database.getInstance().validateLogin(username, password);
	if(statusCode != Database.INVALID_USER)
	    /*parent.loginOk(statusCode)*/;
	else
	    JOptionPane.showMessageDialog(this, "Felaktigt anv�ndarnamn eller l�senord!", "Fel", JOptionPane.ERROR_MESSAGE);
	passwordField.setText("");
    }

    public static void main(String[] args) {
       	try {
	    javax.swing.UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
	    /*
	     * Beskrivning av olika look&feels:
	     *   http://java.sun.com/docs/books/tutorial/uiswing/misc/plaf.html
	     */
	}
	catch(Exception e) {
	    //Gick det inte? jaja, ingen fara
	}

        EventQueue.invokeLater(new Runnable() {
            public void run() {
		JFrame testFrame = new JFrame("Matematikspelet - Inloggning");
		testFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		LoginPanel lp = new LoginPanel(null, 800, 600);
		testFrame.getContentPane().add(lp, BorderLayout.CENTER);
		testFrame.pack();
		testFrame.setVisible(true);
            }
        });
    }
}
