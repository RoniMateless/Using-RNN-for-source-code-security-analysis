package mathgame.game;

import mathgame.common.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.util.LinkedList;
import java.applet.*;

public class Player extends Actor implements KeyListener {

    private final int LEFT = -1, UP = -1;
    private final int RIGHT = 1, DOWN = 1;

    private final int NOSTATE = -1;
    private final int STANDING = 0;
    private final int WALKING = 1;
    private final int RUNNING = 2;
    private final int JUMPING = 3;
    private final int CLIMBING = 4;
    private final int STANDING_ON_LADDER = 5;
    private final int WALKING_OUT_A_DOOR = 6;
    private final int OPENING_DOOR = 7;

    private ClosedDoor doorToOpen;

    private final int FRAME_INTERVAL = 5;

    private boolean keyLeft;
    private boolean keyRight;
    private boolean keyUp;
    private boolean keyDown;
    private boolean keySpace;
    private boolean keySpaceReleased = true;
    private boolean keyEscapeReleased = true;

    private int direction;
    private int lastDirection;
    private int state;
    private int prevState;
    private int nextState;
    private int committedState;
    private int committedPrevState;
    private int committedDirection;

    private double painSpeed = 0.0;
    public double speedX = 0.0;
    public double speedY = 0.0;
    private double accX = 0.0;
    private double accY = 0.0;
    private double g = 10.0;

    private double creationTime = System.currentTimeMillis();

    private long stopHollowTime;

    private int frame = 0;

    private Image[] standing = new Image[2];
    private Image[] walkingRight = new Image[4];
    private int walkingRightIterator = 0;
    private Image[] walkingLeft = new Image[4];
    private int walkingLeftIterator = 0;
    private Image[] climbing = new Image[2];
    private int climbingIterator = 0;
    private Image[] walkingThroughDoor = new Image[2];
    private int walkingThroughDoorIterator = 0;
    private float walkingThroughDoorScaleFactor = 0.98f;
    private int walkingThroughDoorPlayerWidth;
    private int walkingThroughDoorPlayerHeight;
    private Image[] jumpingLeft = new Image[1];
    private int jumpingLeftIterator = 0;
    private Image[] jumpingRight = new Image[1];
    private int jumpingRightIterator = 0;
    private Image[] fallingLeft = new Image[2];
    private int fallingLeftIterator = 0;
    private Image[] fallingRight = new Image[2];
    private int fallingRightIterator = 0;
    private Image emptyImage;
    private Game game;
    private LevelObject downLimiting, upLimiting, leftLimiting, rightLimiting;
    private int downLimit = 1000000, upLimit = -1, leftLimit = -1, rightLimit = 1000000;

    //private int stopBlinkingTime;
    private long blinkingInterval = 0, blinkingWaypoint = 0;
    private int blinkingCount = 0;
    private boolean blinking = false;
    //private short picturesToUse;
    private AudioClip jumpSound;
    
    public Player(Game igame) {
	game = igame;
	//picturesToUse = Main.picturesToUse;
	keyLeft = false;
	keyRight = false;
	emptyImage = new BufferedImage(1, 1, BufferedImage.TYPE_INT_RGB);
	initPics();
	state = JUMPING;
	nextState = NOSTATE;
	image = standing[0];
	width = standing[0].getWidth(null);
	height = standing[0].getHeight(null);
	hitArea = new Rectangle(x, y, width, height);
	walkingThroughDoorPlayerWidth = width;
	walkingThroughDoorPlayerHeight = height;
	jumpSound = Applet.newAudioClip(ClassLoader.getSystemResource("mathgame/common/ljud/ding.wav"));
    }

    public void setPics(short type) {
	if(!(type != Main.KEEN_PICS && type != Main.BOY_PICS && type != Main.GIRL_PICS)) {
	    Game.picturesToUse = type;
	    initPics();
	}
	else throw new IllegalArgumentException("Illegal type");
    }
    
    private void initPics() {
	if(Game.picturesToUse == Main.KEEN_PICS) {
	    standing[0] = ImageArchive.getImage("mathgame/common/figurer/standing.png");
	    walkingRight[0] = ImageArchive.getImage("mathgame/common/figurer/keenRunRight0.png");
	    walkingRight[1] = ImageArchive.getImage("mathgame/common/figurer/keenRunRight1.png");
	    walkingRight[2] = ImageArchive.getImage("mathgame/common/figurer/keenRunRight2.png");
	    walkingRight[3] = ImageArchive.getImage("mathgame/common/figurer/keenRunRight3.png");	
	    walkingLeft[0] = ImageArchive.getImage("mathgame/common/figurer/keenRunLeft0.png");
	    walkingLeft[1] = ImageArchive.getImage("mathgame/common/figurer/keenRunLeft1.png");
	    walkingLeft[2] = ImageArchive.getImage("mathgame/common/figurer/keenRunLeft2.png");
	    walkingLeft[3] = ImageArchive.getImage("mathgame/common/figurer/keenRunLeft3.png");
	}
	else if(Game.picturesToUse == Main.BOY_PICS) {
	    standing[0] = ImageArchive.getImage("mathgame/common/figurer/kille/boyStandRight.png");
	    standing[1] = ImageArchive.getImage("mathgame/common/figurer/kille/boyStandLeft.png");

	    walkingRight[0] = ImageArchive.getImage("mathgame/common/figurer/kille/boyRunRight0.png");
	    walkingRight[1] = ImageArchive.getImage("mathgame/common/figurer/kille/boyRunRight1.png");
	    walkingRight[2] = ImageArchive.getImage("mathgame/common/figurer/kille/boyRunRight2.png");
	    walkingRight[3] = ImageArchive.getImage("mathgame/common/figurer/kille/boyRunRight3.png");	
	    walkingLeft[0] = ImageArchive.getImage("mathgame/common/figurer/kille/boyRunLeft0.png");
	    walkingLeft[1] = ImageArchive.getImage("mathgame/common/figurer/kille/boyRunLeft1.png");
	    walkingLeft[2] = ImageArchive.getImage("mathgame/common/figurer/kille/boyRunLeft2.png");
	    walkingLeft[3] = ImageArchive.getImage("mathgame/common/figurer/kille/boyRunLeft3.png");
	    
	    climbing[0] = ImageArchive.getImage("mathgame/common/figurer/kille/boyClimb1.png");
	    climbing[1] = ImageArchive.getImage("mathgame/common/figurer/kille/boyClimb2.png");

	    walkingThroughDoor[0] = ImageArchive.getImage("mathgame/common/figurer/kille/boyEnterDoor1.png");
	    walkingThroughDoor[1] = ImageArchive.getImage("mathgame/common/figurer/kille/boyEnterDoor2.png");

	    jumpingLeft[0] = ImageArchive.getImage("mathgame/common/figurer/kille/boyJumpLeft.png");
	    jumpingRight[0] = ImageArchive.getImage("mathgame/common/figurer/kille/boyJumpRight.png");

	    fallingRight[0] = ImageArchive.getImage("mathgame/common/figurer/kille/boyFallRight1.png");
	    fallingRight[1] = ImageArchive.getImage("mathgame/common/figurer/kille/boyFallRight2.png");
	    fallingLeft[0] = ImageArchive.getImage("mathgame/common/figurer/kille/boyFallLeft1.png");
	    fallingLeft[1] = ImageArchive.getImage("mathgame/common/figurer/kille/boyFallLeft2.png");
	   
	}
	else if(Game.picturesToUse == Main.GIRL_PICS) {
	    standing[0] = ImageArchive.getImage("mathgame/common/figurer/tjej/girlStandRight.png");
	    standing[1] = ImageArchive.getImage("mathgame/common/figurer/tjej/girlStandLeft.png");

	    walkingRight[0] = ImageArchive.getImage("mathgame/common/figurer/tjej/girlRunRight0.png");
	    walkingRight[1] = ImageArchive.getImage("mathgame/common/figurer/tjej/girlRunRight1.png");
	    walkingRight[2] = ImageArchive.getImage("mathgame/common/figurer/tjej/girlRunRight2.png");
	    walkingRight[3] = ImageArchive.getImage("mathgame/common/figurer/tjej/girlRunRight3.png");
	    walkingLeft[0] = ImageArchive.getImage("mathgame/common/figurer/tjej/girlRunLeft0.png");
	    walkingLeft[1] = ImageArchive.getImage("mathgame/common/figurer/tjej/girlRunLeft1.png");
	    walkingLeft[2] = ImageArchive.getImage("mathgame/common/figurer/tjej/girlRunLeft2.png");
	    walkingLeft[3] = ImageArchive.getImage("mathgame/common/figurer/tjej/girlRunLeft3.png");	

	    climbing[0] = ImageArchive.getImage("mathgame/common/figurer/tjej/girlClimb1.png");
	    climbing[1] = ImageArchive.getImage("mathgame/common/figurer/tjej/girlClimb2.png");

	    walkingThroughDoor[0] = ImageArchive.getImage("mathgame/common/figurer/tjej/girlEnterDoor1.png");
	    walkingThroughDoor[1] = ImageArchive.getImage("mathgame/common/figurer/tjej/girlEnterDoor2.png");

	    jumpingLeft[0] = ImageArchive.getImage("mathgame/common/figurer/tjej/girlJumpLeft.png");
	    jumpingRight[0] = ImageArchive.getImage("mathgame/common/figurer/tjej/girlJumpRight.png");

	    fallingRight[0] = ImageArchive.getImage("mathgame/common/figurer/tjej/girlFallRight1.png");
	    fallingRight[1] = ImageArchive.getImage("mathgame/common/figurer/tjej/girlFallRight2.png");
	    fallingLeft[0] = ImageArchive.getImage("mathgame/common/figurer/tjej/girlFallLeft1.png");
	    fallingLeft[1] = ImageArchive.getImage("mathgame/common/figurer/tjej/girlFallLeft2.png");

	    //emptyImage = ImageArchive.getImage("mathgame/common/figurer/tjej/girlNotThere.png");
	}
	emptyImage = ImageArchive.getImage("mathgame/common/figurer/tjej/girlNotThere.png");
    }

    public void update() {
	if(nextState != NOSTATE) {
	    state = nextState;
	    nextState = NOSTATE;
	}
	updateStates();
	updateSpeeds();
	updatePlayer();
	hitArea.x = x;
	hitArea.y = y;
	if(frame == 0) {
	    if(hollow) {
		if(stopHollowTime < System.currentTimeMillis()) 
		    hollow = false;
	    }
	    /*if(blinking) {
		if(stopBlinkingTime < System.currentTimeMillis())
		    blinking = false;
		    }*/
	    updateFrame();
	    frame = FRAME_INTERVAL;
	}
	else frame--;
    }

    public synchronized void updateStates() {
	prevState = state;

	if(prevState == WALKING_OUT_A_DOOR) return; // Cannot change state when already walking out of level
	else if(prevState == OPENING_DOOR){
	    if(doorToOpen.isOpen()){
		state = WALKING_OUT_A_DOOR;
		game.signalLevelChange(doorToOpen.nextLevel);
	    }
	    return;
	}

	if(keyUp && !keyDown) {
	    Sprite s = game.ctb.getInteractiveItem(this, 1); // Scan layer 1 for items
	    if(s instanceof Door){
		state = WALKING_OUT_A_DOOR;
		game.signalLevelChange(((Door) s).nextLevel);
		return;
	    }
	    else if(s instanceof ClosedDoor && game.statusBar.hasKey()){
		state = OPENING_DOOR;
		doorToOpen = (ClosedDoor) s;
		doorToOpen.trigger(1);
		return;
	    }
	    else if(s instanceof Ladder){
		state = CLIMBING;
		direction = UP;
		return;
	    }
	}
	else if(keyDown && !keyUp){
	    Sprite s = game.ctb.getInteractiveItem(this, 1);
	    if(s instanceof Ladder){
		state = CLIMBING;
		direction = DOWN;
		return;
	    }
	}
	if(prevState == CLIMBING || prevState == STANDING_ON_LADDER){
	    Sprite s = game.ctb.getInteractiveItem(this, 1);
	    if(s instanceof Ladder)
		state = STANDING_ON_LADDER;
	    else state = JUMPING;

	    if(keyLeft && !keyRight)
		direction = LEFT;
	    else if(keyRight && !keyLeft)
		direction = RIGHT;
	    else direction = 0;
	}
	else if(keyLeft && !keyRight){
	    direction = LEFT;
	    state = WALKING;
	}
	else if(keyRight && !keyLeft){
	    direction = RIGHT;
	    state = WALKING;
	}
	else {
	    if(prevState == WALKING_OUT_A_DOOR);
	    else {
		if(prevState != STANDING && direction != 0) {
		    lastDirection = direction;
		    //System.out.println("Setting last direction to: " + lastDirection);
		}
		direction = 0;
		state = STANDING;
 	    }
	}
	if(keySpace || prevState == JUMPING){
	    if(direction != 0) lastDirection = direction;
	    state = JUMPING;
	}
    }
    
    public void updateSpeeds() {
	if(painSpeed != 0) {
	    //System.out.println("Intercepted neural pain impulse");
	    state = JUMPING;
	    prevState = JUMPING;
	    speedY = painSpeed;
	    painSpeed = 0;
	}
	else if(state == JUMPING){
	    if(prevState != JUMPING) {
		if(keySpace) {
		    if(game.getSoundEnabled()) jumpSound.play();
		    keySpace = false;
		}
		speedY = -11.5;
	    }
	    else
		speedY = speedY + 0.6;
 	}
	if(state == STANDING)
	    speedX = 0;
	else if(state == WALKING_OUT_A_DOOR || state == OPENING_DOOR){
	    speedX = 0;
	    speedY = 0;
	}
	else if(state == CLIMBING){
	    speedY = 1*direction;
	    speedX = keyLeft? LEFT : 0;
	    speedX += keyRight? RIGHT : 0;
	    
	}
	else if(state == STANDING_ON_LADDER){
	    speedY = 0;
	    speedX = 2*direction;
	}
	else if(prevState == CLIMBING || prevState == STANDING_ON_LADDER){
	    speedY = 0;
	    speedX = 2*direction;
	    state = JUMPING;
	}
	else
	    speedX = 2*direction;
    }

    public void updatePlayer() {
	final boolean debug = false; //�ndra till true f�r debug-meddelanden i konsol
	int newx = x, newy = y;
	//painSpeed = 0;
	if(!(speedX == 0 && speedY == 0)) {
	
	    newx = (int)((x + speedX*1.5) + 0.5);  // Math.round()
	    newy = (int)((y + speedY*1.5) + 0.5);
	
	    Collision[] c;
	    if(debug)
		c = game.ctb.checkForCollisionsDebug(this, newx, newy);
	    else
		c = game.ctb.checkForCollisions(this, newx, newy);
	
		
	    if(c[0].getTarget() == null) {
		synchronized(this) {
		    x = newx;
		    y = newy;
		}
	    }
	    else {
		//if(painSpeed != 0) System.out.println("painSpeed != 0");
		for(int i = 0; i < c.length; i++) {
		    LevelObject current = c[i].getTarget();
		    if(current == null) break;
		    if(c[i].getType() == Collision.UP) {
			if(debug) System.out.println("c nr: (" + i + ") " + current + ":Collision.UP"); //DEBUG
			newy = current.y + current.height;
			speedY = 0.7;
			//upLimit = newy;
			//upLimiting = current;
		    }
		    else if(c[i].getType() == Collision.DOWN) {
			if(debug) System.out.println("c nr: (" + i + ") " + current + ":Collision.DOWN"); //DEBUG
			newy = current.y - height;
			speedY = 0.0;//7;
			downLimit = newy;
			downLimiting = current;
		    }
		    else if(c[i].getType() == Collision.LEFT) {
			if(debug) System.out.println("c nr: (" + i + ") " + current + ":Collision.LEFT"); //DEBUG
			newx = current.x + current.width;
			speedX = 0.0;
			//leftLimit = newx;
			//leftLimiting = current;
		    }
		    else if(c[i].getType() == Collision.RIGHT) {
			if(debug) System.out.println("c nr: (" + i + ") " + current + ":Collision.RIGHT"); //DEBUG
			newx = current.x - width;
			speedX = 0.0;
			//rightLimit = newx;
			//rightLimiting = current;
		    }
		
		    //F�r att kunna trigga boxar o dylikt...
		    if(current instanceof TriggeredActor)
			((TriggeredActor)current).trigger(c[i].getType());				
		}
		/*if(painSpeed != 0) {
		    System.out.println("We've got speed");
		    speedY = painSpeed;
		    painSpeed = 0;
		    state = JUMPING;
		    }*/
		synchronized(this) {
		    y = newy;
		    x = newx;
		}
	    }
	}
	
	if(newy == downLimit && painSpeed == 0) {
	    if(standingOn(downLimiting, newx, newy)/* && (downLimiting != null && !(downLimiting instanceof MovingActor))*/) {
		if(state == JUMPING) {
		    if(direction != 0) {
			state = WALKING;
			//System.out.println("direction != 0");
		    }
		    else {
			state = STANDING;
			    
			//System.out.println("direction == 0, lastDirection == " + lastDirection);
		    }
		}
	    }
	    else if(downLimiting != null) {
		downLimit = 10000000;
		
		downLimiting = null;
		
		nextState = JUMPING;
	    }
	    
	}

    }
    
    public void damage() {
	setHollow(2000);
	setBlinking(500, 4);
	game.statusBar.addHealth(-3);
	//System.out.println("Ouch!!");
	painSpeed = -g*0.5;

    }
    
    public boolean inVerticalLineWith(LevelObject lo, int newx) {
	return (!(lo == null) && (((newx + width) > lo.x) && (newx < (lo.x + lo.width))));
	/*if(lo == null) return false;
	if(((newx + width) > lo.x) && (newx < (lo.x + lo.width))) {
	    //System.out.println((y+height) + " " + lo.y);
	    return true;
	}
	else
	return false;*/
    }
    
    /*public boolean inVerticalLineWith(LevelObject lo) {
	if(lo == null) return false;
	if(((y + height) >= lo.y) && (y <= (lo.y + lo.height))) {
	    //System.out.println((y+height) + " " + lo.y);
	    return true;
	}
	else
	    return false;
	
	    }*/
    
    public boolean standingOn(LevelObject lo, int newx, int newy) {
	return inVerticalLineWith(lo, newx) && (!(lo == null) && (lo.y == newy + height));
    }

    public synchronized void updateFrame() {
	if(committedState == WALKING && committedDirection == LEFT){
	    if(committedPrevState != committedState){
		if(!hollow) 
		    image = walkingLeft[0];
		else 
		    image = makeImageTransparent(walkingLeft[0]);
		walkingLeftIterator = 1;
	    }
	    else {
		if(!hollow) 
		    image = walkingLeft[walkingLeftIterator++];
		else
		    image = makeImageTransparent(walkingLeft[walkingLeftIterator++]);
		walkingLeftIterator = (walkingLeftIterator == 4?0:walkingLeftIterator);
	    }
	}
	else if(committedState == WALKING  && committedDirection == RIGHT){
	    if(committedPrevState != committedState){
		if(!hollow)
		    image = walkingRight[0];
		else 
		    image = makeImageTransparent(walkingRight[0]);
		walkingRightIterator = 1;
	    }
	    else {
		if(!hollow) 
		    image = walkingRight[walkingRightIterator++];
		else 
		    image = makeImageTransparent(walkingRight[walkingRightIterator++]);
		walkingRightIterator = (walkingRightIterator == 4?0:walkingRightIterator);
	    }
	}
	else if(committedState == CLIMBING){
	    if(!hollow)
		image = climbing[(int) (climbingIterator/4)];
	    else 
		image = makeImageTransparent(climbing[(int) (climbingIterator/4)]);
	    climbingIterator++;
	    climbingIterator = (climbingIterator >= climbing.length*4? 0 : climbingIterator);
	}
	else if(committedState == WALKING_OUT_A_DOOR){
	    hollow = false;
	    image = walkingThroughDoor[(int) (walkingThroughDoorIterator/2)];
	    walkingThroughDoorIterator++;
	    int oldWidth = walkingThroughDoorPlayerWidth;
	    int oldHeight = walkingThroughDoorPlayerHeight;
	    walkingThroughDoorPlayerWidth *= walkingThroughDoorScaleFactor;  // Scale player down
	    walkingThroughDoorPlayerHeight *= walkingThroughDoorScaleFactor; // So that he appears to go inwards
	    if(walkingThroughDoorPlayerWidth < 1) walkingThroughDoorPlayerWidth = 1;
	    else x += (int) Math.ceil((oldWidth - walkingThroughDoorPlayerWidth)/2);
	    if(walkingThroughDoorPlayerHeight < 1) walkingThroughDoorPlayerHeight = 1;
	    else y += (int) Math.ceil((oldHeight - walkingThroughDoorPlayerHeight)/2);
	    image = image.getScaledInstance(walkingThroughDoorPlayerWidth, walkingThroughDoorPlayerHeight, 
					    Image.SCALE_FAST);
	    if(walkingThroughDoorIterator >= walkingThroughDoor.length*2) walkingThroughDoorIterator = 0;
	}
	else if(committedState == STANDING_ON_LADDER){
	    // Do not change image..
	}
	else if(committedState == STANDING || committedState == OPENING_DOOR){
	    if(lastDirection == LEFT){
		if(!hollow)
		    image = standing[1];
		else
		    image = makeImageTransparent(standing[1]);
	    }
	    else {
		if(!hollow)
		    image = standing[0];
		else 
		    image = makeImageTransparent(standing[0]);
	    }
	}
	else if(committedState == JUMPING) {
	    if(lastDirection == LEFT){
		if(speedY < 0){ // Were on our way up... 
		    if(!hollow)
			image = jumpingLeft[0];
		    else image = makeImageTransparent(jumpingLeft[0]);
		} 
		else if(speedY < 4){
		    if(!hollow)
			image = fallingLeft[0];
		    else image = makeImageTransparent(fallingLeft[0]);
		}
		else {
		    if(!hollow)
			image = fallingLeft[1];
		    else image = makeImageTransparent(fallingLeft[1]);
		}
	    }
	    else {
		if(speedY < 0){ // Were on our way up... 
		    if(!hollow)
			image = jumpingRight[0];
		    else image = makeImageTransparent(jumpingRight[0]);
		} 
		else if(speedY < 4){
		    if(!hollow)
			image = fallingRight[0];
		    else image = makeImageTransparent(fallingRight[0]);
		}
		else {
		    if(!hollow)
			image = fallingRight[1];
		    else image = makeImageTransparent(fallingRight[1]);
		}
	    }
	}
	long currentTime = System.currentTimeMillis();
	if(blinking) {
	    if(blinkingCount == 0)
		blinking = false;
	    else if(currentTime >= blinkingWaypoint && blinkingCount > 0) {
		image = emptyImage;
		blinkingWaypoint = currentTime + blinkingInterval;
		blinkingCount--;
	    }
	    /*else if(currentTime >= (blinkingWaypoint/2+blinkingWaypoint/4+blinkingWaypoint/8) && blinkingCount > 0) {
		image = emptyImage;
		return;
		}*/
	  
	}

    }

    public String stateToText(int i) {
	if(i == STANDING) return "STANDING";
	if(i == WALKING) return "WALKING";
	if(i == RUNNING) return "RUNNING";
	if(i == JUMPING) return "JUMPING";
	if(i == CLIMBING) return "CLIMBING";
	if(i == STANDING_ON_LADDER) return "STANDING ON LADDER";
	if(i == WALKING_OUT_A_DOOR) return "WALKING OUT A DOOR";
	return "" + 0;
    }
    public String directionToText(int i) {
	if(i == LEFT) return "LEFT";
	if(i == RIGHT) return "RIGHT";    
	return "" + 0;
    }

    public void keyPressed(KeyEvent e) {
	
	switch(e.getKeyCode()){
	case KeyEvent.VK_G:
	    System.gc();
	    break;
	case KeyEvent.VK_LEFT:
	    //System.out.println("keyLeft pressed");
	    keyLeft = true;
	    break;
	case KeyEvent.VK_RIGHT:
	    //System.out.println("keyRight pressed");
	    keyRight = true;
	    break;
	case KeyEvent.VK_UP:
	    keyUp = true;
	    break;
	case KeyEvent.VK_DOWN:
	    keyDown = true;
	    break;
	case KeyEvent.VK_SPACE:
	    //System.out.println("keySpace pressed");
	    if(keySpaceReleased) {
		keySpace = true;
		keySpaceReleased = false;
	    }
	    break;
	case KeyEvent.VK_ESCAPE:
	    /*if(keyEscapeReleased) {
	      keyEscapeReleased = false;*/
		SwingWorker sw = new SwingWorker() {
			public Object construct() {
			    game.toggleMainMenu();
			    return null;
			}
		    };
		//game.toggleMainMenu();
		sw.start();
		//}
	    break;
	case KeyEvent.VK_D:
	    game.killPlayer();
	    break;
	}
    }
    
    public void keyReleased(KeyEvent e) {
	switch(e.getKeyCode()){
	case KeyEvent.VK_LEFT:
	    //System.out.println("keyLeft released");
	    keyLeft = false;
	    break;
	case KeyEvent.VK_RIGHT:
	    //System.out.println("keyRight released");
	    keyRight = false;
	    break;
	case KeyEvent.VK_UP:
	    keyUp = false;
	    break;
	case KeyEvent.VK_DOWN:
	    keyDown = false;
	    break;
	case KeyEvent.VK_SPACE:
	    //System.out.println("keySpace released");
	    keySpace = false;
	    keySpaceReleased = true;
	    break;
	case KeyEvent.VK_ESCAPE:
	    keyEscapeReleased = true;
	    break;
	}
    }

    public void releaseAllKeys(){
	keyLeft = false;
	keyRight = false;
	keyUp = false;
	keyDown = false;
	keySpace = false;
    }

    public void keyTyped(KeyEvent e) { /*System.out.println("DAD" + Math.random());*/ }
    
    public void commitChanges() {
	synchronized(this) {
	    committedx = x;
	    committedy = y;
	    committedState = state;
	    committedPrevState = prevState;
	    committedDirection = direction;
	}
    }

    /**
     * Makes the player for <ms> milliseconds! 
     */
    public void setHollow(int ms){
	stopHollowTime = System.currentTimeMillis() + ms;
	hollow = true;
    }
    
    public void setBlinking(int interval, int blinks) {
	blinkingCount = blinks;
	blinkingInterval = interval;
	blinking = true;
	blinkingWaypoint = System.currentTimeMillis();
    }


    // Maybe this method shouldn't be here..
    // Returns a transparent copy of the original image
    private Image makeImageTransparent(Image img) {
	return makeImageTransparent(img, 0x5F);
    }

    private Image makeImageTransparent(Image img, int alpha) {
	if(!(img instanceof BufferedImage)) return img;
	BufferedImage newimg = new BufferedImage(img.getWidth(null), img.getHeight(null), 
						   BufferedImage.TYPE_INT_ARGB);

	WritableRaster wr = newimg.getColorModel().createCompatibleWritableRaster(img.getWidth(null), img.getHeight(null));

	int[] olddata = ((DataBufferInt) ((BufferedImage) img).getRaster().getDataBuffer()).getData();
	int[] newdata = ((DataBufferInt) wr.getDataBuffer()).getData();
	
	int alphamask = alpha << 24;

	for(int i=0; i < olddata.length; i++){
	    newdata[i] = olddata[i];
	    if((newdata[i] & 0xFF000000) != 0)
		newdata[i] |= alphamask;  // Mask in some alpha
	}
				     							
	newimg.setData(wr);

	return newimg;
    }
}
