package mathgame.game;

import mathgame.common.*;
import java.util.*;
import java.awt.Rectangle;

public class RepaintManager {

    public static final int MAX_DIRTY_AREAS = 500;
    public static final int ITERATORS = 5;

    private Rectangle[] dirtyAreas;
    private int ptr;
    private boolean lock;

    private StaticDirtyIterator[] sdits;

    public RepaintManager(){
	dirtyAreas = new Rectangle[MAX_DIRTY_AREAS];
	for(int i=0; i<dirtyAreas.length; i++){
	    dirtyAreas[i] = new Rectangle();
	}
	ptr = 0;
	lock = false;
	setUpIterators();
    }

    private void setUpIterators(){
	sdits = new StaticDirtyIterator[ITERATORS];
	for(int i=0; i<ITERATORS; i++){
	    sdits[i] = new StaticDirtyIterator();
	}
    }

    public void setDirty(int x, int y, int width, int height){
	//addDirtyRegion(new Rectangle(x, y, width, height));
	while(lock) Thread.yield();
	lock = true;
	if(ptr >= MAX_DIRTY_AREAS) ptr = MAX_DIRTY_AREAS - 1;
	dirtyAreas[ptr].x = x;
	dirtyAreas[ptr].y = y;
	dirtyAreas[ptr].width = width;
	dirtyAreas[ptr++].height = height;
	lock = false;
    }

    public void addDirtyRegion(Rectangle r){
	setDirty(r.x, r.y, r.width, r.height);
    }

    /**
     * Don't use this method as it allocated a new array on the heap!
     */ 
    public Rectangle[] getDirtyRegions(){
	while(lock) Thread.yield();
	lock = true;
	Rectangle[] toReturn = new Rectangle[ptr];
	try {
	    System.arraycopy(dirtyAreas, 0, toReturn, 0, ptr);
	} catch(Exception e){ e.printStackTrace(); }
	ptr = 0;
	lock = false;
	return toReturn;
    }

    public synchronized Iterator getDirtyIterator(){
	while(lock) Thread.yield();
	lock = true;
	for(int i=0; i<sdits.length; i++){
	    if(!sdits[i].locked){
		//System.out.println(i);
		sdits[i].use();
		if(sdits[i].inited){ 
		    lock = false;
		    return sdits[i];
		}
	    }
	}
	System.out.println("Allocating new dirtyIterator");
	StaticDirtyIterator sdit = new StaticDirtyIterator();
	sdit.use();
	lock = false;
	return sdit;
    }

    public void clearDirtyRegions(){
	ptr = 0;
    }

    private class StaticDirtyIterator implements Iterator {
	
	private Rectangle[] dirtyBuffer;
	private int ourPtr;
	private int iterator;
	boolean locked;
	boolean inited;

	public StaticDirtyIterator(){
	    dirtyBuffer = new Rectangle[MAX_DIRTY_AREAS];
	    locked = false;
	    inited = false;
	}

	public void use(){
	    if(locked){
		inited = false;
		return;
	    }
	    locked = true;
	    try {
		System.arraycopy(dirtyAreas, 0, dirtyBuffer, 0, ptr);
	    } catch(Exception e){ e.printStackTrace(); }
	    ourPtr = ptr;
	    ptr = 0;
	    iterator = 0;
	    inited = true;
	}
	public boolean hasNext(){
	    if(iterator < ourPtr) 
		return true;
	    else {
		inited = false;
		locked = false;
		return false;
	    }
	}

	public Object next(){
	    if(inited && hasNext())
		return dirtyBuffer[iterator++];
	    return null;
	}

	public void remove(){}
    }
}
