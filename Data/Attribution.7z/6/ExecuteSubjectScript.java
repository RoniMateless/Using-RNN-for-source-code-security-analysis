/*-
 * Copyright (C) 2004 Delby Arrospide, Niloofar Ghassemino, Lars Helander, Taghrid Hodroj,
 *                    Magnus Johansson, Caroline Koch, Erik Larsson, Helena Nilsson
 * 
 * All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

package mathgame.common;
import mathgame.question.reader.*;
import java.io.*;
import java.util.Vector;

public class ExecuteSubjectScript {
    public static class Entry {
	public String subjectName = null;
	public String description = null;
	public String helpTextFilename = null;
	public String sourceFilename = null;
	public String encoding = null;
	public int level = -1;
    }
    private static BufferedReader stdin =
	new BufferedReader(new InputStreamReader(System.in));
    private static String sourceFilePath = "";
   
    public static void main(String[] args) throws IOException {
	if(args.length != 1 && args.length != 2) {
	    System.out.println("Fel antal argument.");
	    System.out.println("Programmet ExecuteSubjectScript tar exakt 2 argument:");
	    System.out.println(" 1. s�kv�gen till filen inneh�llande momentscriptet");
	    System.out.println(" 2. (ej obligatorisk) s�kv�gen till katalogen inneh�llande k�llfilerna");
	}
	else {
	    Vector<Entry> entries = new Vector<Entry>();
	    Vector<Integer> damagedLines = new Vector<Integer>();
	    String filename = args[0];
	    if(args.length == 2)
		sourceFilePath = args[1] + "/";
	    BufferedReader buf = new BufferedReader(new FileReader(filename));
	    int lineNr = 0;
	    int currentLevel = -1;
	    String currentEncoding = "";
	    String currentLine = buf.readLine();
	    while(currentLine != null) {
		if(currentLine.trim().startsWith("Moment:")) {
		    Entry e = new Entry();
		    int entryStartLine = lineNr;
		    currentLine = buf.readLine();
		    ++lineNr;
		    while(validSubjectEntry(currentLine)) {
			String trimmedLine = currentLine.trim();
			if(trimmedLine.startsWith("Namn: ")) {
			    String data = trimmedLine.substring("Namn: ".length()).trim();
			    e.subjectName = data;
			}
			else if(trimmedLine.startsWith("Beskrivning: ")) {
			    String data = trimmedLine.substring("Beskrivning: ".length()).trim();
			    e.description = data;
			}
			else if(trimmedLine.startsWith("Hj�lptext: ")) {
			    String data = trimmedLine.substring("Hj�lptext: ".length()).trim();
			    e.helpTextFilename = data;
			}
			else if(trimmedLine.startsWith("K�llfil: ")) {
			    String data = trimmedLine.substring("K�llfil: ".length()).trim();
			    e.sourceFilename = data;
			}
			else if(trimmedLine.startsWith("Kodning: ")) {
			    String data = trimmedLine.substring("Kodning: ".length()).trim();
			    e.encoding = data;
			}
			else if(trimmedLine.startsWith("Niv�: ")) {
			    String data = trimmedLine.substring("Niv�: ".length()).trim();
			    e.level = Integer.parseInt(data);
			}
			currentLine = buf.readLine();
			++lineNr;	
		    }
		    if(e.subjectName == null) {
			System.out.println("FEL: Momentet som b�rjar p� rad " + entryStartLine + " specifierar inget momentnamn. Hoppar �ver...");
			damagedLines.add(entryStartLine);
			continue;
		    }
		    if(e.description == null) {
			System.out.println("VARNING: Momentet som b�rjar p� rad " + entryStartLine + " specifierar ingen beskrivning.");
			e.description = "";
		    }
		    if(e.helpTextFilename == null) {
			System.out.println("VARNING: Momentet som b�rjar p� rad " + entryStartLine + " specifierar ingen hj�lptextfil.");
			e.helpTextFilename = "";
		    }
		    if(e.sourceFilename == null) {
			System.out.println("VARNING: Momentet som b�rjar p� rad " + entryStartLine + " specifierar ingen k�llfil.");
			e.sourceFilename = "";
		    }
		    else {
			if(e.encoding == null) {
			    if(currentEncoding != null)
				e.encoding = currentEncoding;
			    else {
				System.out.println("FEL: Momentet som b�rjar p� rad " + entryStartLine + " specifierar ingen kodning, trots att k�llfil �r specifierad, och global kodning har inte blivit satt. Hoppar �ver...");
				damagedLines.add(entryStartLine);
				continue;
			    }
			}
			if(e.level == -1) {
			    if(currentLevel != -1)
				e.level = currentLevel;
			    else {
				System.out.println("VARNING: Momentet som b�rjar p� rad " + entryStartLine + " specifierar ingen niv�, och global niv� har inte heller blivit satt. Hoppar �ver...");
				damagedLines.add(entryStartLine);
				continue;
			    }
			}
		    }
		    entries.add(e);
		    continue;
		}
		else if(currentLine.trim().startsWith("#")) {
		    String command = currentLine.substring(1).trim();
		    if(command.startsWith("NIV� "))
			currentLevel = Integer.parseInt(command.substring("NIV� ".length()).trim());
		    else if(command.startsWith("KODNING "))
			currentEncoding = command.substring("KODNING ".length()).trim();
		}
		else if(!(currentLine.trim().startsWith("%") || currentLine.trim().equals("")))
		    System.out.println("Line " + lineNr + ": Tolkningsfel."); //Parse error = tolkningsfel?
		currentLine = buf.readLine();
		++lineNr;
	    
	    }
	    
	    System.out.println("F�ljande poster l�stes:");
	    for(Entry e : entries)
		printEntry(e, System.out);
	    if(!damagedLines.isEmpty()) {
		System.out.println("F�ljande poster kunde inte l�sas:");
		for(int i : damagedLines)
		    System.out.println("  Post som b�rjar vid rad: " + i);
	    }

	    Vector<String> nonexistentSourcefiles = new Vector<String>();
	    for(Entry e : entries) {
		File f = new File(sourceFilePath + e.sourceFilename);
		if(!f.exists())
		    nonexistentSourcefiles.add(e.sourceFilename);
	    }
	    if(!nonexistentSourcefiles.isEmpty()) {
		System.out.println("F�ljande k�llfiler kunde inte hittas:");
		for(String s : nonexistentSourcefiles)
		    System.out.println("  " + s);
		System.out.println("Avslutar...");
	    }
	    else {		
		System.out.println("Alla k�llfiler funna.");
		System.out.println("Dessa moment kommer att behandlas:");
		for(Entry e : entries) {
		    System.out.print(e.subjectName + " ");
		    if(e.sourceFilename != null)
			System.out.print("(samt fr�gor fr�n fil: " + e.sourceFilename + ")");
		    System.out.println();
		}
		System.out.println("  ");
		System.out.println("Kontrollera alla meddelanden och tryck enter f�r att b�rja k�rningen...");
		stdin.readLine();
		for(Entry e : entries)
		    processEntry(e);
		
	    }
	}
	
    }

    private static void printEntry(Entry e, PrintStream ps) {
	ps.println("Moment:");
	ps.println("  Namn: " + e.subjectName);
	ps.println("  Beskrivning: " + e.description);
	ps.println("  Hj�lptext: " + e.helpTextFilename);
	ps.println("  K�llfil: " + e.sourceFilename);
 	ps.println("  Niv�: " + e.level);
    }

    private static boolean validSubjectEntry(String s) {
	if(s != null) {
	    s = s.trim();
	    return (s.startsWith("Namn: ") || s.startsWith("Beskrivning: ") || 
		    s.startsWith("Hj�lptext: ") || s.startsWith("K�llfil: ") || s.startsWith("Niv�: "));
	}
	else return false;
    }
    
    private static boolean processEntry(Entry e) {
	/* 1. Add subject */
	if(Database.getInstance().addSubject(e.subjectName, e.description, e.helpTextFilename))
	    System.out.println("- Momentet \"" + e.subjectName + "\" lades till i databasen");
	else {
	    System.out.println(e.subjectName + ": Kunde inte l�gga till moment i databas.");
	    return false;
	}
	
	/* 2. Add all questions */
	if(e.sourceFilename != null) {
	    try {
		BufferedReader in = new BufferedReader(new FileReader(sourceFilePath + e.sourceFilename));	    
		String mgsFilename = e.sourceFilename.substring(0, e.sourceFilename.lastIndexOf(".")) + ".mgs";
		MGSv1Writer mgsWriter = new MGSv1Writer(new File(Common.QUESTION_DIR + "/" + mgsFilename));
		
		QuestionSourceFileDecoder sourceFileDecoder;
		if(e.encoding.toLowerCase().equals("heltalsproblem"))
		    sourceFileDecoder = new QuestionSourceFileDecoder.Heltalsproblem();
		else if(e.encoding.toLowerCase().equals("likhetsproblem"))
		    sourceFileDecoder = new QuestionSourceFileDecoder.Likhetsproblem();
		else if(e.encoding.toLowerCase().equals("j�mf�relseproblem"))
		    sourceFileDecoder = new QuestionSourceFileDecoder.Jamforelseproblem();
		else if(e.encoding.toLowerCase().equals("r�kneproblem"))
		    sourceFileDecoder = new QuestionSourceFileDecoder.Rakneproblem();
		else if(e.encoding.toLowerCase().equals("br�kapproximering"))
		    sourceFileDecoder = new QuestionSourceFileDecoder.Brakapproximering();
		else if(e.encoding.toLowerCase().equals("decimal_och_procentr�kning"))
		    sourceFileDecoder = new QuestionSourceFileDecoder.DecimalOchProcentrakning();
		else {
		    System.out.println(e.subjectName + ": Ok�nd fr�getyp");
		    return false;
		}
		
		int numQ = sourceFileDecoder.decode(in, e.sourceFilename, e.subjectName, e.level, mgsWriter);		
		mgsWriter.write();
		
		for(MGSv1Frame i : mgsWriter.getFrames()) {
		    //System.out.println("Adding " + i.getFrameIdentifier() + " from " + destinationFolder + " to database.");
		    Database.getInstance().addQuestion(i.getFrameIdentifier(), mgsFilename, e.subjectName, e.level);
		}
		System.out.println("- " + numQ + " fr�gor har lagts i filen \"" + mgsFilename + "\", samt registrerats i databasen.");
		return true;
	    }
	    catch(Exception ex) {
		ex.printStackTrace();
		return false;
	    }
	}
	else
	    return true;
    }
}
