package mathgame.game;

import mathgame.common.*;
import java.awt.*;
import javax.swing.*;

public class ClosedDoor extends TriggeredActor {

    private static final int FRAME_INTERVAL = 10;
    private int frame = 0;

    String nextLevel;

    private Image[] openingAnimation;
    private int animPtr;

    private boolean open;
    
    private Game game;
    
    public ClosedDoor(Game game, String nextLevel, int x, int y){
	this.game = game;
	this.x = x;
	this.y = y;
	this.nextLevel = nextLevel;
	
	triggered = false;

	animPtr = 0;
	initPics();
	image = openingAnimation[0];
	width = -1;
	while(width == -1)
	    width = image.getWidth(null); 
	height = -1;
	while(height == -1)
	    height = image.getHeight(null);
	this.hitArea = new Rectangle(x, y, width, height);
    }
    
    public void update(){
	if(triggered && !open){
	    if(frame == 0){
		open();
		frame = FRAME_INTERVAL;
	    }
	    else frame--;
	}
    }

    public void open(){
	image = openingAnimation[animPtr];
	if(animPtr >= openingAnimation.length-1){
	    animPtr = 0;
	    open = true;
	}
	else animPtr++;
    }

    public boolean trigger(int direction){
	if(triggered) return false;
	triggered = true;
	return triggered;
    }

    public boolean isOpen(){
	return open;
    }

    private void initPics(){
	openingAnimation = new Image[5];
	openingAnimation[0] = ImageArchive.getImage("mathgame/common/mbilder/door_locked.png");
	openingAnimation[1] = ImageArchive.getImage("mathgame/common/mbilder/door_opening_1.png");
	openingAnimation[2] = ImageArchive.getImage("mathgame/common/mbilder/door_opening_2.png");
	openingAnimation[3] = ImageArchive.getImage("mathgame/common/mbilder/door_opening_3.png");
	openingAnimation[4] = ImageArchive.getImage("mathgame/common/mbilder/door_opened.png");
    }

}
