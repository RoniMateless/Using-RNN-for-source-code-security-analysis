package mathgame.common;

import java.util.*;
import mathgame.game.Actor;

public class PositionMap {

    public static final int DEFAULT_WIDTH = 800;
    public static final int DEFAULT_HEIGHT = 600;
    public static final double CELL_SIZE = 100.0;
    public static final int ITERATORS = 10;

    private int mapWidth;
    private int mapHeight;
    private double cellSize;
    private int cellSizeInt;
     
    private Entry[][] map;

    private StaticIterator[] sits;

    public PositionMap(){
	this(DEFAULT_WIDTH, DEFAULT_HEIGHT, CELL_SIZE);
    }

    public PositionMap(int mapWidth, int mapHeight){
	this(mapWidth, mapHeight, CELL_SIZE);
    }

    public PositionMap(int mapWidth, int mapHeight, double cellSize){
	this.mapWidth = mapWidth;
	this.mapHeight = mapHeight;
	this.cellSize = cellSize;
	cellSizeInt = (int) cellSize;
	int width = (int) Math.ceil((double) mapWidth / cellSize);
	int height = (int) Math.ceil((double) mapHeight / cellSize);
	map = new Entry[width][height];
	setUpIterators();
    }

    private void setUpIterators(){
	sits = new StaticIterator[ITERATORS];
	for(int i=0; i<ITERATORS; i++){
	    sits[i] = new StaticIterator();
	}
    }

    public int getCellSize(){
	return cellSizeInt;
    }
    public int getWidth(){
	return map.length;
    }
    public int getHeight(){
	return map[0].length;
    }

    public void addSprite(Sprite s) throws Exception {
	if(s == null) throw new Exception("Attempted to add null sprite");
	int mapX = (int) Math.floor((double) s.x / cellSize);
	int mapY = (int) Math.floor((double) s.y / cellSize);
	int mapX2 = (int) Math.ceil((double) (s.x + s.width) / cellSize);
	int mapY2 = (int) Math.ceil((double) (s.y + s.height) / cellSize);
	if(mapX < 0 || mapY < 0 || mapX2 > map.length || mapY2 > map[0].length)
	    throw new Exception("Sprite does not fit in map");

	for(int i=mapX; i < mapX2; i++){
	    for(int j=mapY; j < mapY2; j++){
		Entry toAdd = new Entry(s);
		if(map[i][j] != null){
		    map[i][j].prev = toAdd;
		    toAdd.next = map[i][j];
		    map[i][j] = toAdd;
		}
		else {
		    map[i][j] = toAdd;
		}
	    }
	}
    }

    public void removeSprite(Sprite s) throws Exception {
	int mapX = (int) Math.floor((double) s.x / cellSize);
	int mapY = (int) Math.floor((double) s.y / cellSize);
	int mapX2 = (int) Math.ceil((double) (s.x + s.width) / cellSize);
	int mapY2 = (int) Math.ceil((double) (s.y + s.height) / cellSize);
	if(mapX < 0 || mapY < 0 || mapX2 > map.length || mapY2 > map[0].length)
	    throw new Exception("Sprite coordinates out of map bounds");
	for(int i=mapX; i < mapX2; i++){
	    for(int j=mapY; j < mapY2; j++){
		for(Entry e = map[i][j]; e != null; e = e.next){
		    if(e.sprite == s){   // We found our sprite!
			if(e.next == null){ // We're the last sprite in the list
			    if(e.prev == null) // We're the only sprite in the list
				map[i][j] = null;
			    else 
				e.prev.next = null;
			}
			else if(e.prev == null){ // We're the first sprite in the list
			    e.next.prev = null;
			    map[i][j] = e.next;
			}
			else { // We have entries before and after us
			    e.prev.next = e.next;  
			    e.next.prev = e.prev;
			}
			break; // We're done in this cell
		    }
		}
		
	    }
	}
    }

    // This method should be as fast as possible
    public void validateActor(Actor a, int oldx, int oldy){
	if(oldx == a.x && oldy == a.y) return;  // We haven't moved!
	
	int newmapX = a.x / cellSizeInt; 
	int newmapY = a.y / cellSizeInt; 
	int oldmapX = oldx / cellSizeInt;
	int oldmapY = oldy / cellSizeInt;

	double x2 = (oldx+a.width) / cellSize;
	double y2 = (oldy+a.height) / cellSize;
	int oldmapX2 = ((x2 - (int)x2) > 0) ? (int)x2 + 1 : (int)x2; // Just a faster version of Math.ceil()
	int oldmapY2 = ((y2 - (int)y2) > 0) ? (int)y2 + 1 : (int)y2;

	x2 = (a.x+a.width) / cellSize;
	y2 = (a.y+a.height) / cellSize;
	int newmapX2 = ((x2 - (int)x2) > 0) ? (int)x2 + 1 : (int)x2; // Just a faster version of Math.ceil()
	int newmapY2 = ((y2 - (int)y2) > 0) ? (int)y2 + 1 : (int)y2;

	if(newmapX == oldmapX && newmapY == oldmapY &&
	   newmapX2 == oldmapX2 && newmapY2 == oldmapY2) return; // We haven't moved in the map


	int minX = newmapX < oldmapX ? newmapX : oldmapX; minX = minX < 0 ? 0 : minX;
	int minY = newmapY < oldmapY ? newmapY : oldmapY; minY = minY < 0 ? 0 : minY;
	int maxX = newmapX2 > oldmapX2 ? newmapX2 : oldmapX2; maxX = maxX > map.length ? map.length : maxX;
	int maxY = newmapY2 > oldmapY2 ? newmapY2 : oldmapY2; maxY = maxY > map[0].length ? map[0].length : maxY;

	for(int i=minX; i < maxX; i++){
	    for(int j=minY; j < maxY; j++){
		if(i >= newmapX && i < newmapX2 && j >= newmapY && j < newmapY2){
		    if(i >= oldmapX && i < oldmapX2 && j >= oldmapY && j < oldmapY2) 
			continue; // We are still in this cell 
		    else { // We should add the actor
			Entry toAdd = new Entry(a);
			if(map[i][j] != null){
			    map[i][j].prev = toAdd;
			    toAdd.next = map[i][j];
			    map[i][j] = toAdd;
			}
			else {
			    map[i][j] = toAdd;
			}	
		    }
		}
		else {
		    if(i >= oldmapX && i < oldmapX2 && j >= oldmapY && j < oldmapY2){ // We should remove the actor
			for(Entry e = map[i][j]; e != null; e = e.next){
			    if(e.sprite == a){   // We found our sprite!
				if(e.next == null){ // We're the last sprite in the list
				    if(e.prev == null) // We're the only sprite in the list
					map[i][j] = null;
				    else 
					e.prev.next = null;
				}
				else if(e.prev == null){ // We're the first sprite in the list
				    e.next.prev = null;
				    map[i][j] = e.next;
				}
				else { // We have entries before and after us
				    e.prev.next = e.next;  
				    e.next.prev = e.prev;
				}
				break; // We're done in this cell
			    }
			}	
		    }
		    else continue;  // We have nothing to do with this cell
		}
	    }
	}
    }
    
    public SpriteIterator getSprites(int x, int y, int width, int height){
	/*
	int mapX = (int) Math.floor((double) x / cellSize);
	int mapY = (int) Math.floor((double) y / cellSize);
	*/
	int mapX = x / cellSizeInt;
	int mapY = y / cellSizeInt;
	int mapX2 = (int) Math.ceil((double) (x+width) / cellSize);
	int mapY2 = (int) Math.ceil((double) (y+height) / cellSize);
	return new SpriteIterator(mapX, mapY, mapX2, mapY2);
    }

    // This method is never used...
    public Iterator getSprites(int i, int j){
	return new SpriteIterator(i, j, i+1, j+1);
    }

    /**
     * Returns an iterator without allocating a new object on the heap,
     * thus minimizes the use of garbage collection. Allocates a new iterator
     * if all the current ones is in use.
     */ 
    public synchronized Iterator getStaticIterator(int x, int y, int width, int height){
	
	if(true)
	    return getFastIterator(x, y, width, height); // Currently not implemented
	
	int mapX = x / cellSizeInt;
	int mapY = y / cellSizeInt;
	int mapX2 = (int) Math.ceil((double) (x+width) / cellSize);
	int mapY2 = (int) Math.ceil((double) (y+height) / cellSize);
	for(int i=0; i<sits.length; i++){
	    if(!sits[i].locked){  // This one is not in use
		//sits[i].locked = true;
		//System.out.println("Using iterator #: " +i);
		sits[i].use(mapX, mapY, mapX2, mapY2);
		if(sits[i].inited) return sits[i];
	    }
	}
	//System.out.println("All iterators are in use.. allocating a new one");
	StaticIterator toReturn = new StaticIterator();
	toReturn.use(mapX, mapY, mapX2, mapY2);
	return toReturn;
    }

    public FastSpriteIterator getFastIterator(int x, int y, int width, int height){
	int mapX = x / cellSizeInt;
	int mapY = y / cellSizeInt;
	double x2 = (x+width) / cellSize;
	double y2 = (y+height) / cellSize;
	int mapX2 = ((x2 - (int)x2) > 0) ? (int)x2 + 1 : (int)x2;
	int mapY2 = ((y2 - (int)y2) > 0) ? (int)y2 + 1 : (int)y2;

	    //int mapX2 = (int) Math.ceil((double) (x+width) / cellSize);
	    //int mapY2 = (int) Math.ceil((double) (y+height) / cellSize);
		
	return new FastSpriteIterator(mapX, mapY, mapX2, mapY2);
    }

    // Returns an iterator over all the sprites in the map. Do not use this method
    // in the game.
    public Iterator iterator(){
	return new SpriteIterator(0, 0, map.length, map[0].length);
    }

    public Sprite getSprite(int x, int y){
	int mapX = (int) Math.floor((double) x / cellSize);
	int mapY = (int) Math.floor((double) y / cellSize);
	Entry end;
	for(end = map[mapX][mapY]; end != null; end = end.next){
	    if(end.next == null) break;
	}
	for(end = end; end != null; end = end.prev){
	    if(end.sprite.x <= x && end.sprite.y <= y &&
	       end.sprite.width + end.sprite.x >= x &&
	       end.sprite.height + end.sprite.y >= y)
		return end.sprite;
	}
	return null;
    }

    private class Entry {
	
	Sprite sprite;
	Entry next;
	Entry prev;

	public Entry(Sprite s){
	    sprite = s;
	}

	public Entry(Sprite s, Entry n, Entry p){
	    sprite = s;
	    next = n;
	    prev = p;
	}
    }

    private class SpriteIterator implements Iterator {

	private LinkedList list;
	
	public SpriteIterator(int mapX, int mapY, int mapX2, int mapY2){
	    list = new LinkedList();
	    
	    if(mapX2 > map.length)
		mapX2 = map.length;
	    if(mapY2 > map[0].length)
		mapY2 = map[0].length;
	
	    for(int i = mapX; i < mapX2; i++){
		for(int j = mapY; j < mapY2; j++){
		    for(Entry e = map[i][j]; e != null; e = e.next){
			list.add(e.sprite);
		    }
		}
	    }
	    
	}


	public boolean hasNext(){
	    return !list.isEmpty();
	}
    
	public Object next() {
	    return list.removeFirst();
	}
	
	public void remove(){}
	
    }
	
    private class FastSpriteIterator implements Iterator {
	
	private int mapX;
	private int mapY;
	private int mapX2;
	private int mapY2;
	
	private int i;
	private int j;
	private Entry e;

	//private Hashtable temp;

	public FastSpriteIterator(int mapX, int mapY, int mapX2, int mapY2){
	    this.mapX = mapX;
	    this.mapY = mapY;
	    this.mapX2 = mapX2;
	    this.mapY2 = mapY2;
	    if(mapX < 0)
		this.mapX = 0;
	    if(mapY < 0)
		this.mapY = 0;
	    if(mapX2 > map.length)
		this.mapX2 = map.length;
	    if(mapY2 > map[0].length)
		this.mapY2 = map[0].length;

	    i = this.mapX;
	    j = this.mapY;
	    e = null;

	    // temp = new Hashtable(127, 2.0f);
	}

	// Always returns false
	public boolean hasNext(){
	    return false;
	}
	
	/**
	 * Returns the next sprite or null if no more sprites are left.
	 */
	public Object next(){
	    for(i = i; i < mapX2; i++){
		for(j = j; j < mapY2; j++){
		    if(e == null)
			e = map[i][j];
		    for(e = e; e != null; e = e.next){
			Object toReturn = (Object) e.sprite;
			int mX = e.sprite.x / cellSizeInt;
			int mY = e.sprite.y / cellSizeInt;
			//System.out.println(""+mX +" " +mY +" : " +i +" " +j +" : " +mapX + " " +mapY);
			if(mX == i && mY == j){ // First time we see this sprite!
			    e = e.next; // Because we will return before the incrementation step
			    if(e == null) j++;
			    return toReturn;
			}
			else if(i == mapX || j == mapY){
			    if(j == mapY && mX == i && mY < mapY){
				e = e.next;
				if(e == null) j++;
				return toReturn;
			    }
			    else if(i == mapX && mY == j && mX < mapX){
				e = e.next;
				if(e == null) j++;
				return toReturn;
			    }
			    else if(j == mapY && i == mapX && mX < mapX &&  mY < mapY){
				e = e.next;
				if(e == null) j++;
				return toReturn;
			    }
			}
		    }
		}
		j = mapY;
	    }
	    return null;
	}

	/*
	public Object next(){
	    for(i = i; i < mapX2; i++){
		for(j = j; j < mapY2; j++){
		    if(e == null)
			e = map[i][j];
		    for(e = e; e != null; e = e.next){
			Sprite toReturn = e.sprite;
			if(temp.containsKey(toReturn)) continue;
			temp.put(toReturn, toReturn);
			e = e.next; // Because we will return before the incrementation step
			return (Object) toReturn;
		    }
		}
		j = mapY;
	    }
	    return null;
	}
	*/

	public void remove(){}
	
    }

    private class StaticIterator implements Iterator {
	
	private int mapX;
	private int mapY;
	private int mapX2;
	private int mapY2;
	
	private int i;
	private int j;
	private Entry e;

	boolean locked;
	boolean inited;

	public StaticIterator(){
	    locked = false;
	    inited = false;
	}

	/**
	 * Uses this Iterator object (instead of constructor)
	 */
	public void use(int mapX, int mapY, int mapX2, int mapY2){
	    if(locked){ 
		inited = false; // Just to be sure..
		return;
	    }
	    locked = true;

	    this.mapX = mapX;
	    this.mapY = mapY;
	    this.mapX2 = mapX2;
	    this.mapY2 = mapY2;
	    if(mapX < 0)
		this.mapX = 0;
	    if(mapY < 0)
		this.mapY = 0;
	    if(mapX2 > map.length)
		this.mapX2 = map.length;
	    if(mapY2 > map[0].length)
		this.mapY2 = map[0].length;

	    i = this.mapX;
	    j = this.mapY;
	    e = null;
	    inited = true;
	}

	// Always returns false
	public boolean hasNext(){
	    return false;
	}
	
	/**
	 * Returns the next sprite or null if no more sprites are left.
	 */
	public Object next(){
	    if(!inited) return null;

	    for(i = i; i < mapX2; i++){
		for(j = j; j < mapY2; j++){
		    if(e == null)
			e = map[i][j];
		    for(e = e; e != null; e = e.next){
			Object toReturn = (Object) e.sprite;
			int mX = e.sprite.x / cellSizeInt;
			int mY = e.sprite.y / cellSizeInt;
			//System.out.println(""+mX +" " +mY +" : " +i +" " +j +" : " +mapX + " " +mapY);
			if(mX == i && mY == j){ // First time we see this sprite!
			    e = e.next; // Because we will return before the incrementation step
			    if(e == null) j++;
			    return toReturn;
			}
			else if(i == mapX || j == mapY){
			    if(j == mapY && mX == i && mY < mapY){
				e = e.next;
				if(e == null) j++;
				return toReturn;
			    }
			    else if(i == mapX && mY == j && mX < mapX){
				e = e.next;
				if(e == null) j++;
				return toReturn;
			    }
			    else if(j == mapY && i == mapX && mX < mapX &&  mY < mapY){
				e = e.next;
				if(e == null) j++;
				return toReturn;
			    }
			}
		    }
		}
		j = mapY;
	    }

	    // This iterator won't return anything more... 
	    inited = false;
	    locked = false;
	    //System.out.println("Unlocking iterator");

	    return null;
	}

	public void remove(){}
	
	

    }

}
