package mathgame.game;

import mathgame.common.*;
import java.io.*;
import java.awt.*;
import java.util.Vector;

public class Level {

    private Vector levelSprites;
    private String levelBackground;
    private int layer;
    private int width;
    private int height;

    public Level(int width, int height){
	this.width = width;
	this.height = height;
	levelSprites = new Vector();
	levelBackground = "";
    }

    public void setLayer(int layer){
	this.layer = layer;
    }

    public int getLayer(){
	return layer;
    }

    public void addSprite(SpriteData s){
	levelSprites.add(s.getSpriteData());
    }

    public void addSprites(SpriteData [] ss){
	levelSprites.ensureCapacity(levelSprites.size() + ss.length);
	for(int i=0; i<ss.length; i++){
	    levelSprites.add(ss[i].getSpriteData());
	}
    }

    public Background getBackground() throws Exception {
	String [] tokenized = levelBackground.split("\\s");
	if(tokenized[0] != "Background") throw new Exception("Corrupted level data");
	return new Background(Toolkit.getDefaultToolkit().createImage(tokenized[1]));
    }

    public Sprite getNextSprite() throws Exception {
	if(levelSprites.size() <= 0) throw new Exception("No more sprites in level");
	Sprite nextSprite;
	String [] nextSpriteData = ((String) levelSprites.get(levelSprites.size()-1)).split("\\s");
	return null;
    }

    public void setBackground(String backgroundImageFilename){
	levelBackground = "Background "+backgroundImageFilename;
    }

    public void load(String fileName){
	load(new File(fileName));
    }

    public void load(File file){
	levelSprites = new Vector();
	try {
	    BufferedReader in = new BufferedReader(new FileReader(file));
	    while(in.ready()){
		String line = in.readLine();
		if(line.length() == 0 || line.charAt(0) == '/') continue;
		if(line.substring(0, 9) == "Background")
		    levelBackground = line;
		else levelSprites.add(line);
	    }
	} catch(Exception e){ e.printStackTrace(); }
    }

    public void save(String fileName){
	save(new File(fileName));
    }

    public void save(File file){
	try { 
	    BufferedWriter out = new BufferedWriter(new FileWriter(file));
	    String header = "/ Entry  X  Y  Width Height Layer ImagePath\n";
	    out.write(header, 0, header.length());
	    if(levelBackground.length() > 0){
		out.write(levelBackground, 0, levelBackground.length());
		out.newLine();
	    }	    
	    for(int i=0; i<levelSprites.size(); i++){
		String toWrite = (String) levelSprites.get(i);
		out.write(toWrite, 0, toWrite.length());
		out.newLine();
	    }
	    out.close();
	} catch(Exception e){ e.printStackTrace(); }
    }


}
