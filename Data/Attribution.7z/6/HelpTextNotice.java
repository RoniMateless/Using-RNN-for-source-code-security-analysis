/*-
 * Copyright (C) 2004 Delby Arrospide, Niloofar Ghassemino, Lars Helander, Taghrid Hodroj,
 *                    Magnus Johansson, Caroline Koch, Erik Larsson, Helena Nilsson
 * 
 * All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

package mathgame.game.helptext;

import mathgame.game.GamePage;
import java.awt.*;
import java.awt.font.*;
import java.awt.geom.*;

public class HelpTextNotice implements GamePage {

    private static final Font font = new Font("Dialog", Font.BOLD, 15);
    private static final String TEXT1 = "Vill du ha hj�lp?";
    private static final String TEXT2 = "Tryck d� H...";
    private String[] lines;
    private final Rectangle bounds;

    public HelpTextNotice(Rectangle bounds) {
	this(bounds, TEXT1, TEXT2);
    }

    public HelpTextNotice(Rectangle bounds, String t1, String t2) {
	this(bounds, new String[] {t1, t2});
    }

    public HelpTextNotice(Rectangle bounds, String[] lines) {
	this.bounds = bounds;
	this.lines = lines;
	System.out.println("HelpTextNotice created with bounds: " + bounds);
    }

    public Rectangle getBounds() {
	return bounds;
    }
    
    public float getAlphaValue() {
	return 1.0f;
    }
    public void initRenderSession(Graphics2D g) {}
    public void paint(Graphics2D g, Rectangle clipRect) {
	System.err.println("paint called with clip " + clipRect);
	show(g);
    }

    public void show(Graphics g) {
	//g.translate(bounds.x, bounds.y);

	Graphics2D g2 = (Graphics2D) g;

	FontRenderContext frc = g2.getFontRenderContext();
	Rectangle[] tbs = new Rectangle[lines.length];
	int widest = 0;
	for(int i = 0; i < tbs.length; i++) {
	    TextLayout tl = new TextLayout(lines[i], font, frc);
	    tbs[i] = tl.getBounds().getBounds();
	    if(tbs[i].width > widest) widest = tbs[i].width;
	}

	Font oldFont = g.getFont();
	Color oldColor = g.getColor();

	g.setFont(font);
	g.setColor(Color.WHITE);
	g.fillRect(bounds.x, bounds.y, bounds.width, bounds.height);
	g.setColor(Color.BLUE);
	g.drawRect(bounds.x, bounds.y, bounds.width-1, bounds.height-1);
	g.drawRect(bounds.x+1, bounds.y+1, bounds.width-3, bounds.height-3);
	g.setColor(Color.RED);
	
	int x = bounds.width/2 - widest /2;

	// Special case first
	if(lines.length == 2) {
	    g.drawString(lines[0], bounds.x+x, bounds.y+bounds.height/2-(int) (tbs[0].height*0.5));
	    g.drawString(lines[1], bounds.x+x, bounds.y+bounds.height/2+tbs[1].height);
	}
	else {
	    int y = tbs[0].height + 16;
	    int gap = 10;
	    for(int i = 0; i < lines.length; i++) {
		g.drawString(lines[i], bounds.x+x, bounds.y+y);
		y += gap + tbs[i].height;
	    }
	}

	g.setFont(oldFont);
	g.setColor(oldColor);
	//g.translate(-bounds.x, -bounds.y);
    }
    

}
