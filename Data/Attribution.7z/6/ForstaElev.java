package mathgame.database;


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.*;
import mathgame.game.*;

public class ForstaElev extends JFrame implements ActionListener {

    JPanel contentPane;
    GridLayout fl = new GridLayout(4,1);
    JPanel panelFrame;

    Connection conn;



    //String[] data = {"Logik", "Geometri", "Br�k"};



    JLabel jLabelempty1 = new JLabel(" ");
    JLabel jLabelempty2 = new JLabel(" ");
    JLabel jLabelempty3 = new JLabel(" ");
    JLabel jLabelempty4 = new JLabel(" ");
    JLabel jLabelempty5 = new JLabel(" ");
    JLabel jLabelempty6 = new JLabel(" ");
    //JLabel jLabelMoment = new JLabel("V�lj spelmoment: ");
    //JLabel jLabelSpelNamn = new JLabel("V�lj spelnamn: ");

    //JButton buttonDiagnos = new JButton("G�r diagnostiskt prov");
    JButton buttonSpela = new JButton("B�rja spela");

    String query1, query2;
    ResultSet rs1,rs2;
    Statement stmt, stmt2;
    int antal;
    Vector moment;
    String[] data ;
    ArrayList aL;
    MainWindow currentGameWindow;
    mathgame.diagnos.DiagnosShow currentDiagnoseWindow;
    //JComboBox combo = new JComboBox();
    //JComboBox momentcombo = new JComboBox();
    //JComboBox combo2 = new JComboBox();
    //JComboBox spelcombo = new JComboBox();
    private String userID;

    private ForstaElev() {}

    /**Construct the frame*/
    public ForstaElev(String iuserID) {
      userID = iuserID;
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }


  }
  /**Component initialization*/
  private void jbInit() throws Exception  {

      currentGameWindow = null;
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(new FlowLayout(1,1,1));
    contentPane.setBackground(Color.white);
    this.setSize(new Dimension(400, 200));
    this.setTitle("Matematikspelet v" + mathgame.game.Main.VERSION + " - Elev");
    createFrame();
  }


  private void createFrame(){
    panelFrame= new JPanel();
    panelFrame.setLayout(fl);
    panelFrame.setBackground(Color.white);

    //panelForm1.setSize(new Dimension(400, 400));

    //L�gger till actionlistener
    //buttonDiagnos.addActionListener(this);
    buttonSpela.addActionListener(this);

    //buttonDiagnos.setBackground(Color.pink);
    buttonSpela.setBackground(Color.pink);

    //panelFrame.add(jLabelMoment);
    //panelFrame.add(combo);

    //panelFrame.add(jLabelSpelNamn);
    //panelFrame.add(combo2);

    //panelFrame.add(jLabelempty3);
    //panelFrame.add(jLabelempty4);


    panelFrame.add(jLabelempty1);
    //panelFrame.add(buttonDiagnos);
    panelFrame.add(jLabelempty2);
    panelFrame.add(buttonSpela);

    contentPane.add(panelFrame);
    contentPane.setVisible(true);

 }




  public void actionPerformed(ActionEvent e) {

      /*if(e.getSource()== buttonDiagnos){

      if(currentDiagnoseWindow == null || !currentDiagnoseWindow.isVisible())
	  currentDiagnoseWindow = new mathgame.diagnos.DiagnosShow(userID);
      else
	  JOptionPane.showMessageDialog(this, "Du har redan ett diagnosf�nster �ppet.", "FEL", JOptionPane.ERROR_MESSAGE);
	  
      //this.dispose();

      }*/
  if(e.getSource()== buttonSpela){

      if(currentGameWindow == null || (currentGameWindow.getGame() != null && currentGameWindow.getGame().isFinished())) {
	  //currentDiagnoseWindow = new mathgame.diagnos.DiagnosShow(userID);
	  
	  //currentGameWindow = new MainWindow(userID);
	  currentGameWindow = new MainWindow();
      }
      else
	  JOptionPane.showMessageDialog(this, "Du har redan ett spel startat. Spela klart det innan du f�rs�ker starta ett nytt", "P�g�ende spel", JOptionPane.ERROR_MESSAGE);
      //this.dispose();
      

  }

}

  /**Overridden so we can exit when window is closed*/
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      System.exit(0);
    }
  }


}
