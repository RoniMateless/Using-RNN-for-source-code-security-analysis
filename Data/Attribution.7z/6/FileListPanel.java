/*-
 * Copyright (C) 2004 Delby Arrospide, Niloofar Ghassemino, Lars Helander, Taghrid Hodroj,
 *                    Magnus Johansson, Caroline Koch, Erik Larsson, Helena Nilsson
 * 
 * All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

package mathgame.devutils.animationtest;

import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class FileListPanel extends JPanel {
    
    private Vector<FileListItem> items;
    private File[] files;
    private FileListItem selected;
   
    /** Creates new form MP3ToolsFileList */
    public FileListPanel(File[] ifiles) {
	files = ifiles;
	selected = null;
	items = new Vector<FileListItem>();
	if(files != null) {
	    for(int i = 0; i < files.length; i++)
		addFile(files[i], i+1);
	}
	initComponents();
    }
    
    /** 
	This method is called from within the constructor to
        initialize the form.
     */
    private void initComponents() {

	setLayout(null);
	setBackground(new Color(227, 227, 207));

	Dimension panelSize;
	for(int i = 0; i < items.size(); i++) {
	    FileListItem currentItem = (FileListItem)items.get(i);
	    add(currentItem);
	    //currentItem.setSize(300, currentItem.getPreferredSize().height);
	    currentItem.setSize(currentItem.getPreferredSize());
	    currentItem.setLocation(0, i*16);
	    
	    panelSize = new Dimension(getPreferredSize().width, getPreferredSize().height + 16);
	    if(currentItem.getSize().width > getPreferredSize().width)
		panelSize.setSize(currentItem.getSize().width, panelSize.getHeight());
	    
	    setPreferredSize(panelSize);
	
	}
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent evt) {
                mousePress();
            }
        });
    }
    
    /** Exit the Application */
    private void exitForm(java.awt.event.WindowEvent evt) {
        System.exit(0);
    }
    
    private void mousePress() {
	setSelected(null);
	allLightsOff(null); //Alla ljus st�ngs av
    }
    
    public void setSelected(FileListItem fli) {
	selected = fli;
    }
    
    public void moveDownSelected() {
	if(selected == null || selected.getNr() >= items.size())
	    return;

	Vector<FileListItem> reorganizedVector = new Vector<FileListItem>();
	for(int i = 0; i < selected.getNr()-1; i++)
	    reorganizedVector.add(items.get(i));
	FileListItem bubble = (FileListItem)items.get(selected.getNr());
	bubble.setNr(selected.getNr());
	bubble.setLocation(0, bubble.getLocation().y-16);
	bubble.setSize(bubble.getPreferredSize());
	reorganizedVector.add(bubble);
	selected.setNr(selected.getNr()+1);
	selected.setLocation(0, selected.getLocation().y+16);
	selected.setSize(selected.getPreferredSize());
	reorganizedVector.add(selected);
	for(int i = selected.getNr(); i < items.size(); i++)
	    reorganizedVector.add(items.get(i));
	items = reorganizedVector;
    }
    public void moveUpSelected() {
	if(selected == null || selected.getNr() <= 1)
	    return;

	Vector<FileListItem> reorganizedVector = new Vector<FileListItem>();
	for(int i = 0; i < selected.getNr()-2; i++)
	    reorganizedVector.add(items.get(i));
	selected.setNr(selected.getNr()-1);
	selected.setLocation(0, selected.getLocation().y-16);
	selected.setSize(selected.getPreferredSize());
	reorganizedVector.add(selected);
	FileListItem bubble = (FileListItem)items.get(selected.getNr()-1);
	bubble.setNr(selected.getNr()+1);
	bubble.setLocation(0, bubble.getLocation().y+16);
	bubble.setSize(bubble.getPreferredSize());
	reorganizedVector.add(bubble);
	for(int i = bubble.getNr(); i < items.size(); i++)
	    reorganizedVector.add(items.get(i));
	items = reorganizedVector;
	
    }

    public void addFile(File f, int nr) {
	items.add(new FileListItem(this, f, nr));
    }
    
    public FileListItem[] getFileListItems() {
	FileListItem[] result = new FileListItem[items.size()];
	for(int i = 0; i < result.length; i++)
	    result[i] = (FileListItem)items.get(i);
	return result;
    }
    
    public File[] getFiles() {
	File[] result = new File[items.size()];
	for(int i = 0; i < items.size(); i++) {
	    result[i] = ((FileListItem)items.get(i)).getFile();
	}
	return result;
    }
    
    public void allLightsOff(FileListItem exception) {	
	FileListItem currentItem;
	for(int i = 0; i < items.size(); i++) {
	    currentItem = ((FileListItem)items.get(i));
	    if(currentItem != exception)
		currentItem.lightOff();
	}
    }
}
