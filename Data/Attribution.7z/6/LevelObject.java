package mathgame.game;

import java.awt.*;

/**
 * A LevelObject represents a visible object in a level in the math-game.
 */
public class LevelObject extends mathgame.common.Sprite {
    
    /** 
     * Creates a new LevelObject which is a member of the level iparentLevel,
     * and has the position coordinates (iposition_x, iposition_y) in that
     * level.
     */
    /*public LevelObject(Level iparentLevel, int iposition_x, int iposition_y) {
	//parentLevel = iparentLevel;
	x = iposition_x;
	y = iposition_y;
    }*/

    /**
     * The level which this LevelObject is a member of.
     * It can only be a member of one.
     */
    //public Level parentLevel;

    /**
     * The x-coordinate of this LevelObject's position in the
     * coordinate space for its level.
     */
    //public int x;  // x already defined in Sprite.java /Lars

    /**
     * The y-coordinate of this LevelObject's position in the
     * coordinate space for its level.
     */
    //public int y;  // y already defined in Sprite.java /Lars
    
    public int committedx, committedy;
    
    protected boolean hollow = false;
    
    //Vill jag verkligen ha show-metoden liggande i varje enskilt LevelObject?
    public void show(Graphics g, int viewPortOffsetX, int viewPortOffsetY){
	g.drawImage(image, committedx-viewPortOffsetX, committedy-viewPortOffsetY, null);
    }
    
    public void setHollow(boolean b) {
	hollow = b;
    }
    public boolean isHollow() {
	return hollow;
    }
    
    public Rectangle getBounds() {
	hitArea.x = x;
	hitArea.y = y;
	return hitArea; //new Rectangle(x, y, width, height);
    }
    
    public void commitChanges() {
	synchronized(this) {
	    committedx = x;
	    committedy = y;
	}
    }
    
    /*public boolean collisionWith(LevelObject l2, int newx, int newy) {
	Rectangle r1 = new Rectangle(newx, newy, width, height);
	Rectangle r2 = new Rectangle(l2.x, l2.y, l2.width, l2.height);
	//System.out.println(r1);
	//System.out.println(r2);
	if(r1.intersects(r2)) {
	    //System.out.println("WHOA");
	    return true;
	}
	else
	    return false;
	    }*/
}
