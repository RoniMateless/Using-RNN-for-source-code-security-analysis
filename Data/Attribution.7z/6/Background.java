package mathgame.common;

import java.awt.*;
import java.awt.image.*;

public class Background {

    private Image image;
    private int width;
    private int height;

    public Background(Image image){
	this.image = image;
	width = -1;
	while(width == -1)
	    width = image.getWidth(null);  //getWidth() returns -1 if image is not yet loaded
	height = -1;
	while(height == -1)
	    height = image.getHeight(null);
    }

    public void drawBackground(Graphics g, int fromX, int fromY, int forWidth, int forHeight){
	/* int startX = (fromX / width) * width;
	int startY = (fromY / height) * height;
	int stopX = startX + forWidth;
	int stopY = startY + forHeight; */ 
	//System.out.println("\n\n --- START --- ");
	for(int startX = (fromX / width) * width, x = startX; x <= startX + forWidth; x += width){
	    for(int startY = (fromY / height) * height, y = startY; y <= startY + forHeight; y += height){
		//System.out.println("x = " +x +" y = " +y);
		g.drawImage(image, x-fromX, y-fromY, null);
	    }
	}
	//System.out.println(" --- STOP --- ");
    }
    

}
