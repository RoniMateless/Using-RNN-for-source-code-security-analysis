/*-
 * Copyright (C) 2004 Delby Arrospide, Niloofar Ghassemino, Lars Helander, Taghrid Hodroj,
 *                    Magnus Johansson, Caroline Koch, Erik Larsson, Helena Nilsson
 * 
 * All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

package mathgame.common;

import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;

public class LevelConverter extends JFrame {
    private LevelConverter thisObject;

    private JPanel backgroundPanel;
    private FixedWidthTextArea descriptionArea;
    private DefaultTableModel tableModel;
    private JTable filesTable;
    private JScrollPane tableScrollPane;
    private JPanel buttonPanel;
    private JButton selectButton;
    private JButton convertButton;
    private JFileChooser fileChooser;
    private Vector<String> columnNames = new Vector<String>(1);
    private File[] selectedFiles = null;
    
    public LevelConverter() {
	super("Bankonverteraren");
	thisObject = this;

	columnNames.add("Filnamn");
	
	backgroundPanel = new JPanel();
	descriptionArea = new FixedWidthTextArea(300, "Konverterar fr�n det banformat som anv�nds i version 0.8 av Matematikspelet till det som anv�nds i version 0.9. V�lj de filer du vill konvertera med knappen \"V�lj filer\" och klicka sedan p� \"Konvertera\".");
	tableModel = new DefaultTableModel(3, 1) {
		public boolean isCellEditable(int row, int col) {
		    return false;
		    //return col > 0;
		}
	    };
	filesTable = new JTable(tableModel);
	tableScrollPane = new JScrollPane(filesTable);
	buttonPanel = new JPanel();
	selectButton = new JButton("V�lj filer");
	convertButton = new JButton("Konvertera");
	fileChooser = new JFileChooser(System.getProperty("user.dir"));

	backgroundPanel.setBorder(new TitledBorder("Konvertera banformat"));
	BorderLayout bl = new BorderLayout();
	bl.setVgap(10);
	backgroundPanel.setLayout(bl);

	descriptionArea.setWidth(tableScrollPane.getPreferredSize().width);
	filesTable.setCellSelectionEnabled(false);
	filesTable.setColumnSelectionAllowed(false);
	filesTable.setRowSelectionAllowed(true);
	selectButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent evt) {
		    if(fileChooser.showOpenDialog(thisObject) == JFileChooser.APPROVE_OPTION) {
			File[] files = fileChooser.getSelectedFiles();
			Vector<Vector<String>> rowData = new Vector<Vector<String>>();
			for(int i = 0; i < files.length; i++) {
			    Vector<String> yatzy = new Vector<String>();
			    yatzy.add(files[i].getName());
			    rowData.add(yatzy);
			}
			refreshList(rowData);
			selectedFiles = files;
		    }
		}
	    });
	convertButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent evt) {
		    if(selectedFiles != null) {
			Vector<File> errorVector = new Vector<File>();
			for(File f : selectedFiles) {
			    try {
				convertLevel(f);
			    }
			    catch(IOException ioe) {
				errorVector.add(f);
				JOptionPane.showMessageDialog(thisObject, "Fel vid konvertering av bana \"" + f.getName() + "\"!\nSe konsolen f�r utf�rlig information.", "Fel", JOptionPane.ERROR_MESSAGE);
			    }
			}
			if(!errorVector.isEmpty()) {
			    String errorString = "";
			    for(File f : errorVector)
				errorString = errorString + f.getName() + "\n";
			    
			    JOptionPane.showMessageDialog(thisObject, "Fel uppstod vid konvertering av f�ljande banor:\n" + errorString, "Fel", JOptionPane.ERROR_MESSAGE);
			}
			else
			    JOptionPane.showMessageDialog(thisObject, "Alla banor konverterades!", "Information", JOptionPane.INFORMATION_MESSAGE);
		    }
		}
	    });
	fileChooser.setMultiSelectionEnabled(true);
	

	buttonPanel.setLayout(new FlowLayout());
	buttonPanel.add(selectButton);
	buttonPanel.add(convertButton);
	
	backgroundPanel.add(descriptionArea, BorderLayout.NORTH);
	backgroundPanel.add(tableScrollPane, BorderLayout.CENTER);
	backgroundPanel.add(buttonPanel, BorderLayout.SOUTH);
	getContentPane().add(backgroundPanel);
	refreshList(null);

	setDefaultCloseOperation(EXIT_ON_CLOSE);
	pack();
	setLocationRelativeTo(null);
    }

    public void refreshList(Vector<Vector<String>> rowData) {
	tableModel.setDataVector(rowData, columnNames);
	/*
	Database.UserInfo[] infos = Database.getUserInfos();
	Vector<Vector<String>> rowData = new Vector<Vector<String>>();
	//for(int i = 0; i < 100; i++) {
	for(Database.UserInfo info : infos) {
	    Vector<String> newItems = new Vector<String>();
	    newItems.add(info.username);
	    newItems.add(info.firstName);
	    newItems.add(info.lastName);
	    newItems.add(info.loginNr);
	    newItems.add(info.className);
	    newItems.add(info.isTeacher?"L�rare":"Elev");
	    rowData.add(newItems);
	}
	//}
	tableModel.setDataVector(rowData, columnNames);
	*/
    }    

    public static void convertLevel(File f) throws IOException {
	final String toDelete = "mathgame/common/";
	StringBuffer result = new StringBuffer();
	FileReader fr = new FileReader(f);
	BufferedReader buf = new BufferedReader(fr);
	String currentLine = buf.readLine();
	//String result = "";
	String lineSeparator = System.getProperty("line.separator");
	boolean pathWritten = false;
	while(currentLine != null) {
	    if(currentLine.startsWith("Game tune: ")) {
		String[] components = currentLine.split(" ");
		String temp = "";
		if(components[2] != null) {
		    temp = fixFileSeparators(components[2]);
		    int index = temp.indexOf(toDelete);
		    if(index != -1) {
			temp = temp.substring(index+toDelete.length(), temp.length());
		    }
		}
		result.append("Game tune: " + temp + lineSeparator);
	    }
	    else if(currentLine.startsWith("Layer: ")) {
		String[] components = currentLine.split(" ");
		String temp = "";
		if(components[9] != null) {
		    temp = fixFileSeparators(components[9]);
		    int index = temp.indexOf(toDelete);
		    if(index != -1) {
			temp = temp.substring(index+toDelete.length(), temp.length());
		    }
		    for(int i = 0; i < components.length-1; i++)
			result.append((i==9?temp:components[i]) + " ");
		    result.append((components.length-1==9?temp:components[components.length-1]) + lineSeparator);
		}
		else {
		    result.append(currentLine + lineSeparator);
		}
	    }
	    else {
		result.append(currentLine + lineSeparator);
	    }
	    currentLine = buf.readLine();
	}
	fr.close();
	buf.close();
	
	OutputStream out = new FileOutputStream(f);
	out.write(result.toString().getBytes());
	out.close();
    }

    public static String fixFileSeparators(String source) {
	char[] sourceArray = source.toCharArray();
	for(int i = 0; i < sourceArray.length; i++) {
	    if(sourceArray[i] == '\\')
		sourceArray[i] = '/';
	}
	return new String(sourceArray);
    }
    
    public static void main(String[] args) throws IOException {
	/*
	if(args.length != 1)
	    System.out.println("Don't understand");
	else
	    convertLevel(new File(args[0]));
	*/
       	try {
	    javax.swing.UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
	    /*
	     * Beskrivning av olika look&feels:
	     *   http://java.sun.com/docs/books/tutorial/uiswing/misc/plaf.html
	     */
	}
	catch(Exception e) {
	    //Gick det inte? jaja, ingen fara
	}
	(new LevelConverter()).setVisible(true);
    }
}
