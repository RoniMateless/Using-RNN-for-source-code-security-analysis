package mathgame.common;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.*;

public class Database {

    static Connection conn = null;

    static String[] subjects = null;
    static String[] levels = { "1", "2", "3", "4", "5" };
    
    /*static {

	try {

	    //Ladda in databas driver
	    Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");

	    //Connecta mot db
	    //conn = DriverManager.getConnection("jdbc:odbc:Database");
	    conn = DriverManager.getConnection("jdbc:odbc:math-game");
	    conn.setAutoCommit(true);

	    // Print all warnings
	    showSQLWarning(conn.getWarnings());

	} catch(SQLException se){
	    showSQLException(se);
	} catch(Exception e){
	    e.printStackTrace();
	}

	subjects = initSubjects();

	}*/



    public Database() {
    }


    public static String[] getSubjects(){
	return subjects;
    }

    private static String[] initSubjects(){
	int antal = 0;
	String query1, query2;
	ResultSet rs1,rs2;
	Statement stmt, stmt2;

	try {
	    query1= "Select * FROM Moment";
	    query2="Select count(*) from moment";
	    stmt= conn.createStatement();
	    stmt2= conn.createStatement();
	    rs1=stmt.executeQuery(query1);
	    rs2=stmt2.executeQuery(query2);


	    while(rs2.next()){
		antal=rs2.getInt(1);
	    }

	    String [] arrayMoment = new String [antal];

	    String moment = " ";

	    int i=0;
	    while(rs1.next()){
		moment = rs1.getString(1);
		arrayMoment [i] = moment;
		moment=" ";
		i++;
	    }

	    return arrayMoment;
	}
	catch(SQLException se){
	    showSQLException(se);
	}
	catch(Exception e){
	    System.out.println( e ) ;
	}

	return null;
    }


    /*******************************GET DIAGNOSFIL*****************************************/




    public static String[] getDiagnosFil(){
	int antal = 0;
	String query1, query2;
	ResultSet rs1,rs2;
	Statement stmt, stmt2;

	try {
	    query1 = "Select DiagnosFil FROM Diagnos";
	    query2 = "Select count(*) from Diagnos";
	    stmt = conn.createStatement();
	    stmt2 = conn.createStatement();
	    rs1 = stmt.executeQuery(query1);
	    rs2 = stmt2.executeQuery(query2);


	    while(rs2.next()){
		antal=rs2.getInt(1);
	    }

	    String [] arrayDiagnosFil = new String [antal];

	    String diagnosFil = " ";

	    int i=0;
	    while(rs1.next()){
		diagnosFil = rs1.getString(1);
		arrayDiagnosFil [i] = diagnosFil;
		diagnosFil=" ";
		i++;
	    }

	    return arrayDiagnosFil;
	}
	catch(SQLException se){
	    showSQLException(se);
	}
	catch(Exception e){
	    System.out.println( e ) ;
	}

	return null;
    }


    /*****************************GET QUESTIONS!*********************************/

    public static String[] getQuestions(String[] subjects, int level){
	Object[] holder = new Object[subjects.length];
	int numElem = 0;
	for(int i=0; i<subjects.length; i++){
	    String[] s = getQuestions(subjects[i], level);
	    numElem += s.length;
	    holder[i] = (Object) s;
	}

	String[] result = new String[numElem];
	int k = 0;
	for(int i=0; i<holder.length; i++){
	    String[] s = (String[]) holder[i];
	    for(int j=0; j<s.length; j++){
		result[k++] = s[j];
	    }
	}
	return result;
    }


    public static String[] getQuestions(String subject, int level){
	return new String[] { "fr�gor/bildfr�ga1" }; //M�ste ers�ttas med en bra l�sning
	/* int antalq = 0;
	String query1, query2;
	ResultSet rs1,rs2;
	PreparedStatement pstmt, pstmt2;
	try {

	    query1= "Select Fr�ga FROM Fr�ga WHERE MomentNamn=? AND Sv�righetsgrad=?";
	    query2="Select count(*) FROM Fr�ga WHERE MomentNamn=? AND Sv�righetsgrad=?";
	    pstmt= conn.prepareStatement(query1);
	    pstmt2= conn.prepareStatement(query2);

	    pstmt.setString(1, subject);
	    pstmt.setInt(2, level);

	    pstmt2.setString(1, subject);
	    pstmt2.setInt(2, level);

	    rs1=pstmt.executeQuery();
	    rs2=pstmt2.executeQuery();



	    while(rs2.next()){
		antalq=rs2.getInt(1);
	    }

	    String [] arrayQuestions = new String [antalq];

	    String fr�ga = " ";

	    int i=0;
	    while(rs1.next()){
		fr�ga = rs1.getString(1);
		arrayQuestions [i] = fr�ga;
		fr�ga=" ";
		i++;
	    }
	    return arrayQuestions;
	}

	catch(SQLException se){
	    showSQLException(se);
	}
	catch(Exception e){
	    System.out.println( e ) ;
	}
	return null;*/
    }

    /************************************GET DIAGNOS***************************************/

   
    /***************************INSERT POINTS!*************************************/

    public static void insertPoints(String loginnr, String spelnamn, int points, String tid, String datum){
	int elevID=0;
	String query1, queryGetElevid;
	ResultSet rs1,rs2;
	PreparedStatement pstmt1, pstmtGE;

	try {

	    queryGetElevid="Select ElevID FROM ELEV WHERE Personnummer=?";
	    query1= "INSERT INTO SpelResultat (ElevID, SpelNamn, Po�ng, Tid, Datum ) VALUES(?,?,?,?,?)";

	    pstmtGE= conn.prepareStatement(queryGetElevid);
	    pstmt1= conn.prepareStatement(query1);

	    pstmtGE.setString(1, loginnr);
	    rs1=pstmtGE.executeQuery();

	    while(rs1.next()){
		elevID=rs1.getInt(1);
	    }

	    pstmt1.setInt(1, elevID);
	    pstmt1.setString(2, spelnamn);
	    pstmt1.setInt(3, points);
	    pstmt1.setString(4, tid);
	    pstmt1.setString(5, datum);
	    pstmt1.executeUpdate();

	}

	catch(SQLException se){
	    showSQLException(se);
	}
	catch(Exception e){
	    e.printStackTrace();
	}

    }

    public static String[] getLevels(){
	return levels;
    }

    public static int getMinLevel(){
	return Integer.parseInt(levels[0]);
    }

    public static int getMaxLevel(){
	return Integer.parseInt(levels[levels.length-1]);
    }

    public static void addQuestion(String filnamn, String moment, int svarighetsgrad){
	String query1;
	PreparedStatement pstmt1;

	try {

	    query1= "INSERT INTO Fr�ga (Fr�ga, Sv�righetsgrad, Spelfr�ga, MomentNamn ) VALUES(?,?,?,?)";

	    pstmt1= conn.prepareStatement(query1);

	    pstmt1.setString(1, filnamn);
	    pstmt1.setInt(2, svarighetsgrad);
	    pstmt1.setString(3, "Yes");
	    pstmt1.setString(4, moment);
	    pstmt1.executeUpdate();
	}

	catch(SQLException se){
	    showSQLException(se);
	}
	catch(Exception e){
	    e.printStackTrace();
	}

    }
    /*******************************************AddQUESTION************************************/

 public static void addTest(String filnamn, String [] moment, int maxpo�ng){
     String query1, query2, s_moment;
	PreparedStatement pstmt1,pstmt2;

	try {

	    query1 = "INSERT INTO Diagnos (DiagnosFil, Maxpo�ng ) VALUES(?,?)";
	    query2 = "INSERT INTO DiagnosMoment (DiagnosFil,MomentNamn) VALUES(?,?)";


	    pstmt1 = conn.prepareStatement(query1);
	    pstmt2 = conn.prepareStatement(query2);
	    pstmt1.setString(1, filnamn);
	    pstmt1.setInt(2, maxpo�ng);
	    pstmt1.executeUpdate();
	    
	    pstmt2.setString(1, filnamn);
	    
	    int antalElement = moment.length;
		
	    for(int i=0;i<antalElement;i++){


		s_moment = moment[i];
		pstmt2.setString(2, s_moment);

		pstmt2.executeUpdate();
	    }
	    //pstmt2.executeUpdate();
	    
	}

	catch(SQLException se){
	    showSQLException(se);
	}
	catch(Exception e){
	    e.printStackTrace();
	}

    }



    /*************************INSERT GAME_QUESTION_RESULTS***************************************/
    
    /*
      String loginNr kan man f� via MainGranssnitt.getLoginNr()
      D� m�ste man vara inloggad allts�!
      String filnamn �r namnet p� de banfiler man spelar d� man svarar p� fr�gorna.
    */
    public static void insertGameQuestionResult(boolean answer, String frageFilnamn, String banfil, String frageText ,String loginNr){
	String query1; 
        String query2;
        String insert;
        //String s_loginNr="";
        int elevID=0;
        int frageID=0;

	PreparedStatement pstmt1;
        PreparedStatement pstmt2;
        PreparedStatement pstmt3;
        ResultSet rs1, rs2, rs3;

	try {
            query1="Select Fr�geID FROM Fr�ga WHERE Fr�ga=?";
            query2="Select ElevID FROM Elev WHERE Personnummer=?";

            insert= "INSERT INTO SpelResFr�ga (Fr�geID, ElevID, SpelFil, Resultat,Fr�geText ) VALUES(?,?,?,?,?)";

	    pstmt1= conn.prepareStatement(query1);
            pstmt1.setString(1,frageFilnamn);
            rs1=pstmt1.executeQuery();

	    while(rs1.next()){
            frageID=rs1.getInt(1);
            }

            pstmt2= conn.prepareStatement(query2);
            pstmt2.setString(1,loginNr);
            rs2=pstmt2.executeQuery();

            while(rs2.next()){
		elevID=rs2.getInt(1);
            }


            pstmt3= conn.prepareStatement(insert);
            pstmt3.setInt(1,frageID);
            pstmt3.setInt(2,elevID);
            pstmt3.setString(3, banfil);

	    if(answer){
            pstmt3.setString(4, "R");
            }else{
            pstmt3.setString(4, "F");
            }
            pstmt3.setString(5,frageText);
	    pstmt3.executeUpdate();
	    

	}
	

	catch(SQLException se){
	    showSQLException(se);
	}
	catch(Exception e){
	    e.printStackTrace();
	}

    }

    //****************************INSERT DIAGNOS_QUESTION_RESULTS***********************************
    /*
      String loginNr kan man f� via MainGranssnitt.getLoginNr()
      D� m�ste man vara inloggad allts�!
    */
    public static void insertDiagnosQuestionResult(boolean answer, String fr�geFilnamn, String provFilnamn, String frageText,String loginNr){
	String query1;
        String query2;
        String insert;
        int elevID=0;
        int frageID=0;

	PreparedStatement pstmt1;
        PreparedStatement pstmt2;
        PreparedStatement pstmt3;
        ResultSet rs1, rs2, rs3;

	try {
            query1="Select Fr�geID FROM Fr�ga WHERE Fr�ga=?";
            query2="Select ElevID FROM Elev WHERE Personnummer=?";

            insert= "INSERT INTO Fr�gorDiagnos (Fr�geID, DiagnosFil, ElevID, Resultat, Fr�geText) VALUES(?,?,?,?,?)";

	    pstmt1= conn.prepareStatement(query1);
            pstmt1.setString(1,fr�geFilnamn);
            rs1=pstmt1.executeQuery();

	    while(rs1.next()){
            frageID=rs1.getInt(1);
            }

            pstmt2= conn.prepareStatement(query2);
            pstmt2.setString(1,loginNr);
            rs2=pstmt2.executeQuery();

            while(rs2.next()){
            elevID=rs2.getInt(1);
            }


            pstmt3= conn.prepareStatement(insert);
            pstmt3.setInt(1,frageID);
	    pstmt3.setString(2, provFilnamn);
            pstmt3.setInt(3,elevID);
            

            if(answer){
            pstmt3.setString(4, "R");
            }else{
            pstmt3.setString(4, "F");
            }
            pstmt3.setString(5,frageText);
	    pstmt3.executeUpdate();


	}

	catch(SQLException se){
	    showSQLException(se);
	}
	catch(Exception e){
	    e.printStackTrace();
	}

    }

    //*********************************

//**************************CREATE LEVEL!**************************************


   public static void createLevel(String banFilNamn, String [] moment){
	String query1;

        String insert, insert1,s_moment;
        String  banfil = null;
        PreparedStatement pstmt1;
        PreparedStatement pstmt2;
        PreparedStatement pstmt3;

        ResultSet rs1;

	try {
            query1="Select SpelFil FROM Spel WHERE SpelFil=?";
            insert= "INSERT INTO Spel (SpelFil) VALUES(?)";
            insert1="INSERT INTO SpelMoment(SpelFil,MomentNamn) VALUES(?,?)";

	    pstmt1= conn.prepareStatement(query1);
            pstmt1.setString(1,banFilNamn);
            rs1=pstmt1.executeQuery();

	    //try{

            while(rs1.next()){
		banfil=rs1.getString(1);
            }

            //}catch(Exception e){

            if(banfil == null || banfil.equals("")){

		pstmt2= conn.prepareStatement(insert);
		pstmt2.setString(1,banFilNamn);
		pstmt2.executeUpdate();
		System.out.println("Lade till bana!");

		int antalElement = moment.length;
		
		for(int i=0;i<antalElement;i++){
		    s_moment=moment[i];
		    pstmt3= conn.prepareStatement(insert1);
		    pstmt3.setString(1,banFilNamn);
		    pstmt3.setString(2, s_moment);
		    pstmt3.executeUpdate();
		    
		}
            }


            //}






	}

	catch(SQLException se){
	    showSQLException(se);
	}
	catch(Exception e){
	    e.printStackTrace();
	}

    }






    //**************************************INSERT DiagnosResult*************************************************/



public static void insertDiagnosResult( String diagnosFil, String loginNr, int po�ng){
	String query1; 
        String insert;
        
        int elevID=0;

	PreparedStatement pstmt1;
        PreparedStatement pstmt2;
        ResultSet rs1;

	try {
            
            query1="Select ElevID FROM Elev WHERE Personnummer=?";

            insert= "INSERT INTO DiagnosResultat( ElevID, DiagnosFil, Po�ng, Datum ) VALUES(?,?,?,?)";

	    pstmt1= conn.prepareStatement(query1);
            pstmt1.setString(1,loginNr);
            rs1=pstmt1.executeQuery();
	    //new java.sql.Date(System.currentTimeMillis())
	    while(rs1.next()){
            elevID=rs1.getInt(1);
            }

            pstmt2= conn.prepareStatement(insert);
            pstmt2.setInt(1,elevID);
	    pstmt2.setString(2,diagnosFil);
	    pstmt2.setString(3,po�ng+"");
	    pstmt2.setDate(4,new java.sql.Date(System.currentTimeMillis()));
	    
            pstmt2.executeUpdate();

            
	    

	}
	

	catch(SQLException se){
	    showSQLException(se);
	}
	catch(Exception e){
	    e.printStackTrace();
	}

    }

    //****************************INSERT DIAGNOS_QUESTION_RESULTS***********************************
    /*
      String loginNr kan man f� via MainGranssnitt.getLoginNr()
      D� m�ste man vara inloggad allts�!
    */
    /*public static void insertDiagnosQuestionResult(boolean answer, String filnamn, String frageText, String loginNr){
	String query1;
        String query2;
        String insert;
        String  s_loginNr="";
        int elevID=0;
        int frageID=0;

	PreparedStatement pstmt1;
        PreparedStatement pstmt2;
        PreparedStatement pstmt3;
        ResultSet rs1, rs2, rs3;

	try {
            query1="Select Fr�geID FROM Fr�ga WHERE Fr�ga=?";
            query2="Select ElevID FROM Elev WHERE Personnummer=?";

            insert= "INSERT INTO Fr�gorDiagnos (Fr�geID, DiagnosFil, ElevID, Resultat, Fr�geText) VALUES(?,?,?,?,?)";

	    pstmt1= conn.prepareStatement(query1);
            pstmt1.setString(1,filnamn);
            rs1=pstmt1.executeQuery();

	    while(rs1.next()){
            frageID=rs1.getInt(1);
            }

            pstmt2= conn.prepareStatement(query2);
            pstmt2.setString(1,s_loginNr);
            rs2=pstmt2.executeQuery();

            while(rs2.next()){
            elevID=rs2.getInt(1);
            }


            pstmt3= conn.prepareStatement(insert);
            pstmt3.setInt(1,frageID);
	    pstmt3.setString(2, filnamn);
            pstmt3.setInt(3,elevID);
            

            if(answer){
            pstmt3.setString(4, "R");
            }else{
            pstmt3.setString(4, "F");
            }
            pstmt3.setString(5,frageText);
	    pstmt3.executeUpdate();


	}

	catch(SQLException se){
	    showSQLException(se);
	}
	catch(Exception e){
	    e.printStackTrace();
	}

    }
    */

//**********************************************************************************************
    private static void showSQLWarning(SQLWarning warn){
	for( ; warn != null; warn = warn.getNextWarning()){
	    JOptionPane.showMessageDialog(null,
					  "SQL Warning:\n" +
					  "State  : " + warn.getSQLState() +"\n" +
					  "Message: " + warn.getMessage() +"\n" +
					  "Error  : " + warn.getErrorCode(),
					  "SQL Warning", JOptionPane.WARNING_MESSAGE);
	}
    }

    private static void showSQLException(SQLException se){
	while( se != null ){
	    JOptionPane.showMessageDialog(null,
					  "SQL Exception:\n" +
					  "State  : " + se.getSQLState() +"\n" +
					  "Message: " + se.getMessage() +"\n" +
					  "Error  : " + se.getErrorCode(),
					  "SQL Exception", JOptionPane.ERROR_MESSAGE);

	    se = se.getNextException() ;
	}
    }



}










