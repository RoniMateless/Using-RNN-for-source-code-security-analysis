package mathgame.common;

import java.io.*;
import javax.swing.JOptionPane;
import java.awt.image.*;
import java.awt.*;

public class QuestionToolbox {

    public static final int HEADER = 0xABCDEF;
    public static final int FOOTER = 0xFEDCBA;
    public static final int TEXT = 0x0;
    public static final int IMAGE = 0x1;

    public QuestionToolbox(){}

    public static Question loadQuestion(String filename) throws Exception {
	DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(filename)));
	
	if(in.readInt() != HEADER){
	    wrongHeader(filename);
	    return null;
	}
	int type = in.readInt();
	if(type != TEXT && type != IMAGE){
	    wrongHeader(filename);
	    return null;
	}
	int numberOfAnswers = in.readInt();
	if(numberOfAnswers <= 0){
	    showError("Fr�ga \"" +filename +"\" har bara\n" +numberOfAnswers +" svarsalternativ");
	    return null;
	}
	int correctAnswer = in.readInt();
	if(correctAnswer < 0 || correctAnswer >= numberOfAnswers){
	    showError("Fr�ga \"" +filename +"\" har felaktigt specificerat\n" +
		      "svarsalternativ " +(correctAnswer+1) +" som r�tt svarsalternativ");
	    return null;
	}
	if(in.readInt() != FOOTER){
	    wrongHeader(filename);
	    return null;
	}

	// The header is correct.. we can start decoding the question

	if(type == TEXT)
	    return loadTextQuestion(in, numberOfAnswers, correctAnswer, filename);
	else if(type == IMAGE)
	    return loadImageQuestion(in, numberOfAnswers, correctAnswer, filename);
	
	return null;
    }

    private static TextQuestion loadTextQuestion(DataInputStream in, int nans, int cans, String filename) throws Exception {
	TextQuestion result = new TextQuestion();
	result.answers = new String[nans];
	result.correctAnswer = cans;
	result.filename = filename;
	
	char[] q = new char[in.readInt()];
	for(int i=0; i<q.length; i++)
	    q[i] = in.readChar();

	result.question = new String(q);

	for(int i=0; i<nans; i++){
	    char[] a = new char[in.readInt()];
	    for(int j=0; j<a.length; j++){
		a[j] = in.readChar();
	    }
	    result.answers[i] = new String(a);
	}

	return result;
    }

    private static ImageQuestion loadImageQuestion(DataInputStream in, int nans, int cans, String filename) throws Exception {
	ImageQuestion result = new ImageQuestion();
	result.answers = new BufferedImage[nans];
	result.correctAnswer = cans;
	result.filename = filename;

	int qlength = in.readInt();
	int qwidth = in.readInt();
	int qheight = in.readInt();
	
	GraphicsConfiguration gconf =  GraphicsEnvironment.getLocalGraphicsEnvironment().
	    getDefaultScreenDevice().getDefaultConfiguration();


	result.question = gconf.createCompatibleImage(qwidth, qheight, Transparency.BITMASK);

	WritableRaster wr = result.question.getColorModel().createCompatibleWritableRaster(qwidth, qheight);
	int[] qData = ((DataBufferInt) wr.getDataBuffer()).getData();

	if(qlength != qData.length){
	    showError("Corrupted image data:\n" +filename);
	    return null;
	}

	for(int i=0; i<qData.length; i++){
	    int pixelData = in.readInt();
	    if((pixelData & 0xFF000000) != 0)  // We have an opaque section?
		pixelData |= 0xFF000000;
	    qData[i] = pixelData;
	}

	result.question.setData(wr);

	for(int i=0; i<nans; i++){
	    int alength = in.readInt();
	    int awidth = in.readInt();
	    int aheight = in.readInt();
	    result.answers[i] = gconf.createCompatibleImage(awidth, aheight, Transparency.BITMASK);
	    wr = result.answers[i].getColorModel().createCompatibleWritableRaster(awidth, aheight);
	    int[] aData = ((DataBufferInt) wr.getDataBuffer()).getData();
	    if(alength != aData.length){
		showError("Corrupted image data:\n" +filename);
		return null;
	    }
	    for(int j=0; j<aData.length; j++){
		int pixelData = in.readInt();
		if((pixelData & 0xFF000000) != 0)
		    pixelData |= 0xFF000000;
		aData[j] = pixelData;
	    }
	    result.answers[i].setData(wr);
	}

	return result;
    }

    private static void wrongHeader(String filename){
	showError("Felaktig header i fr�ga \n\"" +filename +"\""); 
    }

    private static void showError(String errorMess){
	JOptionPane.showMessageDialog(null, errorMess, "Fel", JOptionPane.ERROR_MESSAGE);
    }

}
