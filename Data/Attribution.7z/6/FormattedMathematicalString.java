/*-
 * Copyright (C) 2004 Delby Arrospide, Niloofar Ghassemino, Lars Helander, Taghrid Hodroj,
 *                    Magnus Johansson, Caroline Koch, Erik Larsson, Helena Nilsson
 * 
 * All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

package mathgame.game.popuppane;

import java.awt.Graphics2D;
import java.awt.Stroke;
import java.awt.BasicStroke;
import java.util.Vector;

public class FormattedMathematicalString extends FormattedString {

    private Vector<Object> strings;
    private int rowWidth;
    private int currentWidth;
    private int fontHeight;
    private int currentMaxHeight;
    private int currentTotalMaxHeight;

    private static final int hGap = 6;
    private static final int hGap2 = 5; //Taken out from TextPopupPane. Don't know the reason for it being 5 and not 6 but...
    private static final int vGap = 5;
    
    public FormattedMathematicalString(int rowWidth, int firstLineAscent, int fontHeight) {
	super(fontHeight, firstLineAscent, 0);
	this.strings = new Vector<Object>();
	this.rowWidth = rowWidth;
	this.fontHeight = fontHeight;
	this.currentWidth = 0;
    }
    
    public void setFirstLineAscent(int ascent) {
	System.err.println("Setting first line ascent to " + ascent);
	firstLineAscent = ascent;
    }
    
    public void drawString(Graphics2D g, int x, int y) {
	int startx = x;
	int currentLineHeight = fontHeight;
	//y += g.getFontMetrics().getMaxAscent();
	y += firstLineAscent;

	for(int i = 0; i < strings.size(); i++) {
	    Object o = strings.elementAt(i);
	    if(o instanceof DrawingUnit) {
		DrawingUnit d = (DrawingUnit) o;
		int yoffset = (d.lineHeight - d.objectHeight) / 2;
		d.draw(g, x, y + yoffset); 
		x += d.objectWidth + vGap;
		currentLineHeight = d.lineHeight;
	    }
	    else if(o instanceof Newline) {
		x = startx;
		y += currentLineHeight + vGap;
		currentLineHeight = fontHeight;
	    }
	}
    }    
    public int getHeight() {
	int x = 0;
	int y = 0;
	int startx = x;
	int currentLineHeight = fontHeight;
	for(int i = 0; i < strings.size(); i++) {
	    Object o = strings.elementAt(i);
	    if(o instanceof DrawingUnit) {
		DrawingUnit d = (DrawingUnit) o;
		int yoffset = (d.lineHeight - d.objectHeight) / 2;
		//d.draw(g, x, y + yoffset); 
		x += d.objectWidth + vGap;
		currentLineHeight = d.lineHeight;
	    }
	    else if(o instanceof Newline) {
		x = startx;
		y += currentLineHeight + vGap;
		currentLineHeight = fontHeight;
	    }
	}
	return y-vGap;
    }    

    
    public void addString(String s, int width) {
	if(width + currentWidth > rowWidth) {
	    addNewline();
	}
	while(s.charAt(s.length()-1) == '\n') {
	    addNewline();
	    System.out.println("Adding new line after: " +s);
	    s = s.substring(0, s.length()-1);
	}
	strings.add(new DrawingUnit(s, width, fontHeight));
	currentWidth += width + vGap;
	if(currentMaxHeight < fontHeight) {
	    currentMaxHeight = fontHeight;
	}
    }

    public void addFraction(String nominator, String denominator, int nomWidth, int denomWidth) {
	Fraction f = new Fraction(nominator, denominator, nomWidth, denomWidth);

	int width = nomWidth > denomWidth ? nomWidth : denomWidth;

	if(width + currentWidth > rowWidth) {
	    addNewline();
	}
	strings.add(new DrawingUnit(f, width, fontHeight * 2 + hGap));
	currentWidth += width + vGap;
	if(currentMaxHeight < fontHeight * 2 + hGap) {
	    currentMaxHeight = fontHeight * 2 + hGap;
	}
    }

    public void addNotEquals(int width) {
	if(width + currentWidth > rowWidth) {
	    addNewline();
	}
	strings.add(new DrawingUnit(new NotEquals(), width, fontHeight));
	currentWidth += width + vGap;
	if(currentMaxHeight < fontHeight) {
	    currentMaxHeight = fontHeight;
	}
    }

    public void addTimesOperator(int width) {
	if(width + currentWidth > rowWidth) {
	    addNewline();
	}
	strings.add(new DrawingUnit(new TimesOperator(), width, fontHeight));
	currentWidth += width + vGap;
	if(currentMaxHeight < fontHeight) {
	    currentMaxHeight = fontHeight;
	}
    }

    public void addSpecialCharacter(String sc) {
	// do something here..
    }

    public void addNewline() {
	for(int i=strings.size()-1; i >= 0; i--) {
	    Object o = strings.get(i);
	    if(o instanceof DrawingUnit) 
		((DrawingUnit) o).lineHeight = currentMaxHeight;
	    else if(o instanceof Newline) break;
	    
	}
	strings.add(new Newline());
	currentWidth = 0;
	totalHeight += currentMaxHeight + hGap2;
	currentMaxHeight = fontHeight; // 0;
    }
    
    public void computeTotalHeight() {
	if(strings.get(strings.size()-1) instanceof Newline);
	else addNewline();
    }
    
    private class DrawingUnit {

	Object toDraw;
	int objectWidth;
	int objectHeight;
	int lineHeight;

	public DrawingUnit(Object o, int w, int h) {
	    toDraw = o;
	    objectWidth = w;
	    objectHeight = h;
	}

	public void draw(Graphics2D g, int x, int y) {
	    Stroke s = g.getStroke();
	    if(toDraw instanceof String) {
		String str = (String) toDraw;
		g.drawString(str, x, y);
	    }
	    else if(toDraw instanceof Fraction) {
		Fraction f = (Fraction) toDraw;
				
		int xoffset = (objectWidth - f.nomWidth) / 2;
		g.drawString(f.nominator, x + xoffset + hGap/2, y);
		y += hGap / 2;		
		g.setStroke(new BasicStroke(2.0f));
		g.drawLine(x + hGap/2 + 2, y+1, x + objectWidth + 2, y+1);
		y += fontHeight + hGap / 2;
		xoffset = (objectWidth - f.denomWidth) / 2;
		g.drawString(f.denominator, x + xoffset + hGap/2, y);
	    }
	    else if(toDraw instanceof NotEquals) {
		g.drawString("=", x, y);
		g.setStroke(new BasicStroke(2.0f));
		g.drawLine(x+1, y-1, x+objectWidth-2, y-2*objectHeight/3-2);
	    }
	    else if(toDraw instanceof TimesOperator) {
		g.fillOval(x+objectWidth/2, y-objectHeight/2, 5, 5);
	    }
	    g.setStroke(s);
	}
    }

    private class Fraction {
	String nominator;
	String denominator;
	int nomWidth;
	int denomWidth;
	public Fraction(String nom, String denom, int nomW, int denomW) {
	    nominator = nom;
	    denominator = denom;
	    nomWidth = nomW;
	    denomWidth = denomW;
	}
    }

    private class NotEquals {}

    private class TimesOperator {}

    private class Newline {}
}
