package mathgame.game;
import mathgame.common.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.util.*;
import java.io.*;

public class MainMenu extends Component {
    
    private static final URL
	BACKGROUND_IMAGE = ClassLoader.getSystemResource("mathgame/common/spelbilder/menupage.png"),
	BACKGROUND_IMAGE_SEGMENT = ClassLoader.getSystemResource("mathgame/common/spelbilder/menupagesegment.png"),
	BACKGROUND_IMAGE_FOOTER = ClassLoader.getSystemResource("mathgame/common/spelbilder/menupagefooter.png"),
	LOGO_IMAGE = ClassLoader.getSystemResource("mathgame/common/spelbilder/mathgame-logo-transparent.png"),
	SOUND_OFF_A_IMAGE = ClassLoader.getSystemResource("mathgame/common/spelbilder/mainmenu/soundoff_a.png"),
	SOUND_OFF_I_IMAGE = ClassLoader.getSystemResource("mathgame/common/spelbilder/mainmenu/soundoff_i.png"),
	SOUND_ON_A_IMAGE = ClassLoader.getSystemResource("mathgame/common/spelbilder/mainmenu/soundon_a.png"),
	SOUND_ON_I_IMAGE = ClassLoader.getSystemResource("mathgame/common/spelbilder/mainmenu/soundon_i.png");

    private Image backgroundImage, backgroundImageSegment, backgroundImageFooter, logoImage;
    private Image[] soundImagesActive, soundImagesPassive;
    private Game game;
    public int y_position = 0, committed_y_position = 0, y_max, y_last_update = 0;
    private int posx = 100, width, activeItem = 0;
    private boolean visible = false, pullingUp = false, pullingDown = false;
    //private MenuItem[] mainMenuItems;
    private AWTEventListener keyCatcher;
    private MenuPage currentPage;
    
    public MainMenu(Game igame) {
	game = igame;
	loadBasicImages();
	y_max = backgroundImage.getHeight(null);
	width = backgroundImageFooter.getWidth(null);
	keyCatcher = new MainMenuKeyListener(this);
	loadStartPage();
    }
    
    public void loadBasicImages() {
	backgroundImage = game.makeImageTransparent(ImageArchive.getImage(BACKGROUND_IMAGE), 0x5F);
	backgroundImageSegment = game.makeImageTransparent(ImageArchive.getImage(BACKGROUND_IMAGE_SEGMENT), 0x5F);
	backgroundImageFooter = game.makeImageTransparent(ImageArchive.getImage(BACKGROUND_IMAGE_FOOTER), 0x5F);
	logoImage = ImageArchive.getImage(LOGO_IMAGE);
	soundImagesActive = new Image[2];
	soundImagesActive[0] = ImageArchive.getImage(SOUND_OFF_A_IMAGE);
	soundImagesActive[1] = ImageArchive.getImage(SOUND_ON_A_IMAGE);
	soundImagesPassive = new Image[2];
	soundImagesPassive[0] = ImageArchive.getImage(SOUND_OFF_I_IMAGE);
	soundImagesPassive[1] = ImageArchive.getImage(SOUND_ON_I_IMAGE);
    }

    public void loadIngamePage() {
	MenuPage result = new MenuPage(this);
	TextMenuItem item1 = new ChangeSoundItem(this);
	item1.setLocation(posx + width/2 - item1.width/2, 300);
	item1.setWantsToBeCentered(true);
	item1.setEnabled(true);
	result.addItem(item1);
	TextMenuItem item2 = new ExitGameItem(this, "Avsluta spel");
	item2.setLocation(posx + width/2 - item2.width/2, 350);
	item2.setWantsToBeCentered(true);
	result.addItem(item2);
	currentPage = result;
	
    }

    public void loadStartPage() {
	MenuPage result = new MenuPage(this);
	TextMenuItem item1 = new StartGameItem(this, "Starta spel");
	item1.setLocation(posx + 50, 300);
	item1.setWantsToBeCentered(true);
	item1.setEnabled(true);
	result.addItem(item1);
	TextMenuItem item2 = new ExitGameItem(this, "Avsluta spel");
	item2.setLocation(posx + 50, 350);
	item2.setWantsToBeCentered(true);
	result.addItem(item2);
	currentPage = result;
	
    }
    
    public void loadChooseCharacterPage() {
	MenuPage result = new MenuPage(this);
	ImageMenuItem item1 = new BoyMenuItem(this);
	item1.setLocation(posx + width/2 - item1.getWidth()/2, 300);
	item1.setEnabled(true);
	result.addItem(item1);
	ImageMenuItem item2 = new GirlMenuItem(this);
	item2.setLocation(posx + width/2 - item2.getWidth()/2, 400);
	result.addItem(item2);
	currentPage = result;
    }
    
    public void setVisible(boolean visible) {
	visible = true;
    }
    
    public boolean isVisible() {
	return visible;
    }
    
    public int getHeight() {
	return committed_y_position;
    }
    
    public int getWidth() {
	return width;
    }
    
    public int getLocationX() { return posx; }
    
    public Game getGame() { return game; }
    
    public synchronized void commitChanges() {
	committed_y_position = y_position;
    }
    
    public synchronized void setDown() {
	Toolkit.getDefaultToolkit().addAWTEventListener(keyCatcher, AWTEvent.KEY_EVENT_MASK);
	visible = true;
	y_position = y_max;
    }
    public synchronized void setUp() {
	Toolkit.getDefaultToolkit().removeAWTEventListener(keyCatcher);
    	visible = false;
	y_position = 0;
    }
    
    public void pullDown() {
	Toolkit.getDefaultToolkit().addAWTEventListener(keyCatcher, AWTEvent.KEY_EVENT_MASK);
	game.getPlayer().releaseAllKeys();
	synchronized(this) {
	    if(pullingDown)
		return;
	    else if(pullingUp)
		pullingUp = false;
	    pullingDown = true;
	}
	visible = true;
	while(y_position < y_max) {
	    synchronized(this) {
		if(!pullingDown)
		    break;
		y_position = y_position + 8;
		if(y_position > y_max)
		    y_position = y_max;
	    }
	    try { Thread.sleep(1); }
	    catch(Exception e) {}
	}
	synchronized(this) { pullingDown = false; }
    }
    
    public void pullUp() {
	Toolkit.getDefaultToolkit().removeAWTEventListener(keyCatcher);
	synchronized(this) {
	    if(pullingUp)
		return;
	    else if(pullingDown)
		pullingDown = false;
	    pullingUp = true;
	}
	while(y_position > 0) {
	    synchronized(this) {
		if(!pullingUp)
		    break;
		y_position = y_position - 8;
		if(y_position < 0)
		    y_position = 0;
	    }
	    try { Thread.sleep(1); /*synchronized(this) { wait(0, 50); }*/ }
	    catch(Exception e) {}
	}
	synchronized(this) { pullingUp = false; visible = false; }
	
    }
    
    
    
    public synchronized void redrawFully(Graphics g) {
	if(committed_y_position > 0)
	    g.drawImage(backgroundImage, posx, committed_y_position - backgroundImage.getHeight(null), null);
	//System.out.println(mainMenuItems.getComponent(0).getSize());
	//mainMenuItems.getComponent(0).paint(g);
	//System.out.println((committed_y_position-300) + " > 0  > 0 = " + (committed_y_position-300 > 0));
	g.drawImage(logoImage, posx + width/2 - logoImage.getWidth(null)/2, committed_y_position - y_max + 50, null);
	//System.out.println((posx + width/2 - logoImage.getWidth(null)/2) + "=" + posx + "?");
	/*for(int i = 0; i < currentPage.itemCount(); i++) {
	  mainMenuItems[i].show(g);
	  }*/
	if(currentPage != null)
	    currentPage.show(g);
    }
    
    public synchronized void show(Graphics g) {
	int backgroundImageHeight = backgroundImageFooter.getHeight(null);
	int current_y_position = committed_y_position;
	int linesToDraw = current_y_position - y_last_update;
	System.out.println("Showing");
	if(current_y_position > 0) {
	    System.out.println("Displaying footer");
	    g.drawImage(backgroundImageFooter, posx, committed_y_position-backgroundImageHeight, null);
	    game.dirtyRegions.setDirty(posx, current_y_position-backgroundImageHeight, width, backgroundImageHeight);
	    if(linesToDraw > 0 && current_y_position > backgroundImageHeight) {
		int startingPos = current_y_position - backgroundImageHeight -linesToDraw;
		while(linesToDraw > 0) {
		    System.out.println("Displaying segment. linesToDraw = " + linesToDraw);
		    g.drawImage(backgroundImageSegment, posx, 
				committed_y_position - backgroundImageHeight - linesToDraw-- , null);
		}
		    
	    
	    }
	    else if(linesToDraw < 0) {
		
	    }
	}
	//g.drawImage(backgroundImage, posx, committed_y_position-backgroundImageHeight, null);
	y_last_update = current_y_position;		
    }
    
    public void keyUp() { 
	currentPage.getItem(activeItem).setEnabled(false);
	if(currentPage.itemCount() == 1)
	    return;
	else if((activeItem-1) < 0)
	    activeItem = currentPage.itemCount()-1;
	else
	    activeItem--;
	currentPage.getItem(activeItem).setEnabled(true);	
    }
    public void keyDown() {
	currentPage.getItem(activeItem).setEnabled(false);
	if(currentPage.itemCount() == 1)
	    return;
	else if((activeItem+1) >= currentPage.itemCount())
	    activeItem = 0;	
	else
	    activeItem++;
	currentPage.getItem(activeItem).setEnabled(true);
    }
    public void keyLeft() { currentPage.getItem(activeItem).pressLeft(); }
    public void keyRight() { currentPage.getItem(activeItem).pressRight(); }
    public void keyEnter() { currentPage.getItem(activeItem).pressEnter(); }

    private class MainMenuKeyListener implements AWTEventListener {
	
	private MainMenu mainMenu;

	public MainMenuKeyListener(MainMenu imainMenu) {
	    mainMenu = imainMenu;
	}
	
	public void eventDispatched(AWTEvent event){
	    KeyEvent e = (KeyEvent) event;
	    if(event.getID() == KeyEvent.KEY_PRESSED){
		// keyPressed(KeyEvent e)
		switch(e.getKeyCode()){
		case KeyEvent.VK_UP:
		    mainMenu.keyUp();
		    //keyUpInMenu();
		    break;
		case KeyEvent.VK_DOWN:
		    mainMenu.keyDown();
		    //keyDownInMenu();
		    break;
		case KeyEvent.VK_LEFT:
		    mainMenu.keyLeft();
		    //keyLeftInMenu():
		    break;
		case KeyEvent.VK_RIGHT:
		    mainMenu.keyRight();
		    //keyLeftInMenu():
		    break;
		case KeyEvent.VK_ENTER:
		    mainMenu.keyEnter();
		    //The question has been answered
		    break;
		case KeyEvent.VK_ESCAPE:
		    game.toggleMainMenu();
		    break;
		default:
		    break;
		}
		    
	    }
	    e.consume();
	}
    }
}
class MenuPage {
    private MainMenu mainMenu;
    private ArrayList items;
	
    public MenuPage(MainMenu imainMenu) {
	mainMenu = imainMenu;
	items = new ArrayList();
    }

    public void addItem(MenuItem mi) {
	items.add(mi);
    }
	
    public MenuItem[] getItems() {
	Iterator li = items.iterator();
	MenuItem[] result = new MenuItem[items.size()];
	int i = 0;
	while(li.hasNext())
	    result[i++] = (MenuItem)li.next();
	return result;
    }
	
    public MenuItem getItem(int i) {
	return (MenuItem)items.get(i);
    }
	
    public Iterator getMenuItemIterator() {
	return items.iterator();
    }
	
    public int itemCount() {
	return items.size();
    }
	
    public void show(Graphics g) {
	for(int i = 0; i < items.size(); i++) {
	    MenuItem currentItem = (MenuItem)items.get(i);
	    if(currentItem instanceof TextMenuItem && ((TextMenuItem)currentItem).wantsToBeCentered() && !currentItem.centered()) {
		currentItem.setLocation(mainMenu.getLocationX() + mainMenu.getWidth()/2 - ((TextMenuItem)currentItem).getWidth()/2, currentItem.getLocationY());
	    }
	    currentItem.show(g);
	}
    }
}

abstract class MenuItem {
	
    //protected Image activeImage, idleImage;
    protected int x, y, width, height;
    protected boolean enabled, centered;
    protected MainMenu mainMenu;
	
    public abstract void pressLeft();
    public abstract void pressRight();
    public abstract void pressEnter();
    public void setEnabled(boolean b) { enabled = b; }
    public void setLocation(int ix, int iy) { x = ix; y = iy; }
    public void setLocation(Point p) { x = p.x; y = p.y; }
    public Point getLocation() { return new Point(x, y); }
    public int getLocationX() { return x; }
    public int getLocationY() { return y; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }
    public boolean centered() { return centered; }
    public abstract void show(Graphics g);
}
    
class TextMenuItem extends MenuItem {
    public String text;
    private boolean wantsToBeCentered;
    private Font font;
    private FontMetrics fm;
	
    public TextMenuItem(MainMenu imainMenu) {
	this(imainMenu, "");
    }
    public TextMenuItem(MainMenu imainMenu, String s) {
	mainMenu = imainMenu;
	centered = false;
	text = s;
	font = new Font("Dialog", Font.PLAIN, 20);
	width = 0; height = 0;
	/*Dimension preferredSize = getPreferredSize();
	  width = preferredSize.width;
	  height = preferredSize.height;*/
    }
	
    public boolean wantsToBeCentered() { return wantsToBeCentered; }
    public void setWantsToBeCentered(boolean b) { wantsToBeCentered = b; }
	
    public void pressLeft() {}
    public void pressRight() {}
    public void pressEnter() {}
	
    /*public void setWidth(int i) {
      if(i > 0)
      width = i;
      else throw new RuntimeException("Tried to set width to a negative value");
      }*/
	
    /**
     * Sets the width of the item to one that matches the length of the String.
     */
    public Dimension getPreferredSize() {
	Dimension result;
	if(fm != null) {
	    int width = fm.stringWidth(text) + 4;
	    int height = fm.getMaxAscent() + fm.getMaxDescent() + 4;
	    result = new Dimension(width, height);
	}
	else result = new Dimension(0, 0);
	return result;
    }
	
    private void adjustToPreferredSize() {
	if(fm != null) {
	    width = fm.stringWidth(text) + 4;
	    height = fm.getMaxAscent() + fm.getMaxDescent() + 4;
		
	}
    }
		
    public int getFontHeight() {
	if(fm != null) {
	    return fm.getMaxAscent();
	}
	else return 0;
    }
	
    public void oldShow(Graphics g) {
	fm = g.getFontMetrics(font);
	adjustToPreferredSize();
	//width = preferredSize.width;
	//height = preferredSize.height;
	//System.out.println("got new graphics");
	    
	Font originalFont = g.getFont();
	Color originalColor = g.getColor();
	//float fontHeight = (float)20.0;
	//g.setFont(g.getFont().deriveFont(fontHeight));
	//FontMetrics fm = g.getFontMetrics();
	Color backgroundColor = null;
	//int stringWidth = 0;
	/*if(width < 0) {
	  if(enabled) {
	  stringWidth = fm.stringWidth(text);
	  backgroundColor = Color.WHITE;
	  }
	  else {
	  stringWidth = fm.stringWidth(text);
	  backgroundColor = Color.LIGHT_GRAY;
	  }
	  g.setColor(backgroundColor);
	  g.fillRoundRect(x-2, y-(mainMenu.y_max-mainMenu.y_position)-2, stringWidth+4, (fm.getMaxAscent() + fm.getMaxDescent())+4, 4, 4);
	  g.setColor(Color.BLACK);
	  g.drawString(text, x, (int)(y+fontHeight)-(mainMenu.y_max-mainMenu.y_position));
	  g.setFont(originalFont);
	  g.setColor(originalColor);
	  }*/

	if(enabled)
	    backgroundColor = Color.WHITE;
	else
	    backgroundColor = Color.LIGHT_GRAY;
	    
	    
	g.setColor(backgroundColor);
	g.fillRoundRect(x, y - (mainMenu.y_max-mainMenu.y_position), width, height, 4, 4);
	g.setColor(Color.BLACK);
	g.setFont(font);
	g.drawString(text, x + 2, (y + getFontHeight() + 2)-(mainMenu.y_max-mainMenu.y_position));
	g.setFont(originalFont);
	g.setColor(originalColor);
	/*else {
	  if(enabled) {
	  backgroundColor = Color.WHITE;
	  }
	  else {
	  backgroundColor = Color.LIGHT_GRAY;
	  }
	  g.setColor(backgroundColor);
	  g.fillRoundRect(x-2, y-(mainMenu.y_max-mainMenu.y_position)-2, stringWidth+4, (fm.getMaxAscent() + fm.getMaxDescent())+4, 4, 4);
	  }*/
    }
    
    public void show(Graphics g) {
	fm = g.getFontMetrics(font);
	adjustToPreferredSize();
	Color originalColor = g.getColor();
	Font originalFont = g.getFont();
	if(enabled) {
	    g.setColor(Color.BLACK);
	    g.fillRoundRect(x, y-(mainMenu.y_max-mainMenu.y_position), width, height, 4, 4);
	    g.setColor(Color.WHITE);
	    g.fillRoundRect(x+1, y+1-(mainMenu.y_max-mainMenu.y_position), width-2, height-2, 4, 4);
	}
	else {
	    g.setColor(Color.WHITE);
	    g.fillRoundRect(x, y-(mainMenu.y_max-mainMenu.y_position), width, height, 4, 4);
	
	}
	g.setColor(Color.BLACK);
	g.setFont(font);
	g.drawString(text, x + 2, (y + getFontHeight() + 2)-(mainMenu.y_max-mainMenu.y_position));
	g.setFont(originalFont);
	g.setColor(originalColor);
    }

}
    
class ImageToggleValueItem extends MenuItem {
    protected Image[] valueImagesEnabled;
    protected Image[] valueImagesDisabled;
    protected int state, numberOfValues;

    public ImageToggleValueItem(MainMenu imainMenu) {
	mainMenu = imainMenu;
	numberOfValues = 0;
	state = 0;
	enabled = false;	    
    }

    public synchronized void setImages(Image[] active, Image[] passive) {
	if(active.length != passive.length)
	    throw new RuntimeException("length of image sequences not equal");
	valueImagesEnabled = active;
	valueImagesDisabled = passive;
	numberOfValues = valueImagesEnabled.length;	    
    }

    public synchronized void pressLeft() {
	if((state+1) < numberOfValues)
	    state++;
	else state = 0;
    }
    public synchronized void pressRight() {
	if((state-1) >= 0)
	    state--;
	else state = numberOfValues-1;
	    
    }
    public void pressEnter() {}
	
    public int getState() { return state; }
    public synchronized void setState(int i) { state = i; }
    public synchronized void show(Graphics g) {
	if(enabled) {
	    if(valueImagesEnabled != null && valueImagesEnabled[state] != null)
		g.drawImage(valueImagesEnabled[state], x, y-(mainMenu.y_max-mainMenu.y_position), null);
	    //else System.out.println("No images");
	}
	else {
	    if(valueImagesDisabled != null && valueImagesDisabled[state] != null)
		g.drawImage(valueImagesDisabled[state], x, y-(mainMenu.y_max-mainMenu.y_position), null);
	    //else System.out.println("No images");
	}
    }
	
}
/*private class ChangeSoundItem extends ImageToggleValueItem {
  private final URL SOUND_OFF_A_IMAGE = ClassLoader.getSystemResource("mathgame/common/spelbilder/mainmenu/soundoff_a.png"),
  SOUND_OFF_P_IMAGE = ClassLoader.getSystemResource("mathgame/common/spelbilder/mainmenu/soundoff_i.png"),
  SOUND_ON_A_IMAGE = ClassLoader.getSystemResource("mathgame/common/spelbilder/mainmenu/soundon_a.png"),
  SOUND_ON_P_IMAGE = ClassLoader.getSystemResource("mathgame/common/spelbilder/mainmenu/soundon_i.png");
  private final Image onActive = ImageArchive.getImage(SOUND_ON_A_IMAGE),
  onPassive  = ImageArchive.getImage(SOUND_ON_P_IMAGE),
  offActive = ImageArchive.getImage(SOUND_OFF_A_IMAGE),
  offPassive = ImageArchive.getImage(SOUND_OFF_P_IMAGE);
	
  public ChangeSoundItem(MainMenu imainMenu) {
  super(imainMenu);
  mainMenu = imainMenu;
  valueImagesEnabled = new Image[2];
  valueImagesEnabled[0] = onActive;
  valueImagesEnabled[1] = offActive;
  valueImagesDisabled = new Image[2];
  valueImagesDisabled[0] = onPassive;
  valueImagesDisabled[1] = offPassive;
  if(valueImagesEnabled.length != valueImagesDisabled.length)
  throw new RuntimeException("Length of image sequences not equal (Internal error. Can never happen :) )");
  numberOfValues = valueImagesEnabled.length;
  if(mainMenu.getGame().getSoundEnabled())
  state = 0;
  else
  state = 1;
  enabled = false;
  }
	
  public synchronized void setImages(Image[] a, Image[] b) {}
	
  public void pressLeft() {
  super.pressLeft();
  if(state == 0)
  mainMenu.getGame().setSoundEnabled(false);
  else
  mainMenu.getGame().setSoundEnabled(true);
  }
  public void pressRight() {
  super.pressLeft();
  if(state == 0)
  mainMenu.getGame().setSoundEnabled(false);
  else
  mainMenu.getGame().setSoundEnabled(true);
	    
  }
  }*/
class ChangeSoundItem extends TextMenuItem {
    private static final String soundOn = "Ljud p�", soundOff = "Ljud av";
    public ChangeSoundItem(MainMenu imainMenu) {
	super(imainMenu, imainMenu.getGame().getSoundEnabled()?soundOn:soundOff);
	if(mainMenu.getGame().getSoundEnabled())
	    text = soundOn;
	else
	    text = soundOff;

    }
    public void pressLeft() {
	super.pressLeft();
	if(text == soundOn) {
	    mainMenu.getGame().setSoundEnabled(false);
	    text = soundOff;
	}
	else {
	    mainMenu.getGame().setSoundEnabled(true);
	    text = soundOn;
	}
    }
    public void pressRight() {
	pressLeft();
	    
    }
    
    public void pressEnter() {
	pressLeft();
    }
}
    
class ExitGameItem extends TextMenuItem {
	
    public ExitGameItem(MainMenu imainMenu, String s) {
	super(imainMenu, s);
    }
    public void pressEnter() {
	mainMenu.getGame().exitGame();
    }
}
    
class StartGameItem extends TextMenuItem {
    public StartGameItem(MainMenu imainMenu, String s) {
	super(imainMenu, s);
    }
    public void pressEnter() {
	mainMenu.loadChooseCharacterPage();
    }
}
    
class ImageMenuItem extends MenuItem {
	
    private Image image;

    public ImageMenuItem(MainMenu imainMenu, Image i) {
	mainMenu = imainMenu;
	image = i;
	width = image.getWidth(null) + 4;
	height = image.getHeight(null) + 4;
    }
    public void pressLeft() {}
    public void pressRight() {}
    public void pressEnter() {}
	
    public void show(Graphics g) {
	Color originalColor = g.getColor();
	if(enabled) {
	    g.setColor(Color.BLACK);
	    g.fillRoundRect(x, y-(mainMenu.y_max-mainMenu.y_position), width, height, 4, 4);
	    g.setColor(Color.WHITE);
	    g.fillRoundRect(x+1, y+1-(mainMenu.y_max-mainMenu.y_position), width-2, height-2, 4, 4);
	}
	else {
	    g.setColor(Color.WHITE);
	    g.fillRoundRect(x, y-(mainMenu.y_max-mainMenu.y_position), width, height, 4, 4);
	
	}
	g.setColor(originalColor);
	g.drawImage(image, x+2, y+2-(mainMenu.y_max-mainMenu.y_position), null);
    }
}
    
class BoyMenuItem extends ImageMenuItem {
    private static final Image boyImage = ImageArchive.getImage("mathgame/common/figurer/kille/boyStandRight.png");
    public BoyMenuItem(MainMenu imainMenu) {
	super(imainMenu, boyImage);
    }	
    //public void pressLeft() { pressUp(); }
    //public void pressRight() { pressDown(); }
    public void pressEnter() {
	mainMenu.getGame().getPlayer().setPics(Main.BOY_PICS);
	mainMenu.setUp();
	mainMenu.loadIngamePage();
	mainMenu.getGame().startGame();
    }
}
class GirlMenuItem extends ImageMenuItem {
    private static final Image girlImage = ImageArchive.getImage("mathgame/common/figurer/tjej/girlStandRight.png");
    public GirlMenuItem(MainMenu imainMenu) {
	super(imainMenu, girlImage);
    }
    //public void pressLeft() { pressUp(); }
    //public void pressRight() { pressDown(); }
    public void pressEnter() {
	mainMenu.getGame().getPlayer().setPics(Main.GIRL_PICS);
	mainMenu.setUp();
	mainMenu.loadIngamePage();
	mainMenu.getGame().startGame();
    }
	
}
