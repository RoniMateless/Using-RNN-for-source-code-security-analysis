package mathgame.diagnos;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import java.sql.*;
import mathgame.common.*;

public class DiagnosShow extends JFrame implements ActionListener {

    private String userid, filename;
    private Container c;
    private Vector questions = new Vector();
    private QPanel[] panel;
    private JScrollPane scroll;
    private JPanel test =  new JPanel();
    private JLabel testLabel;
    private JPanel panel2 = new JPanel();
    private mathgame.game.MainWindow mainWindow;
    private JButton doneButton = new JButton("Klar");
    private DiagnosShow thisObject;
    
    public DiagnosShow(String iuserID) {
	this(iuserID, null);
    }
    
    public DiagnosShow(String iuserid, mathgame.game.MainWindow imainWindow){
	mainWindow = imainWindow;
	String[] tmp = Database.getDiagnosFil();
	int randomIndex = (int) (Math.random() * (tmp.length-1));
	filename = tmp[randomIndex];
	userid = iuserid;
	thisObject = this;
	c = getContentPane();
	//c.setLayout(new GridLayout(0,1));
	c.setLayout(new BorderLayout());

	panel2.setLayout(new GridLayout(0,1));
	panel2.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
	
	JPanel buttonPanel = new JPanel();
	buttonPanel.add(doneButton);
	doneButton.addActionListener(this);

	scroll = new JScrollPane(panel2);	    

	//scroll.setLayout(new GridLayout(0,1));
	c.add(scroll);
	c.add(buttonPanel, BorderLayout.SOUTH);
	

	load(filename);
	scroll.setVisible(true);

	((JComponent) c).setBorder(BorderFactory.createEmptyBorder(5, 5, 0, 5));
	addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent e) {
		    JOptionPane.showMessageDialog(thisObject, "Du m�ste svara p� alla fr�gor!", "Fel", JOptionPane.ERROR_MESSAGE);
		}
		/*public void windowClosed(WindowEvent e) {
		    setVisible(true);
		    }*/
	    });
	setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
	//setSize(200,200);
	pack();
	if(getHeight() > Toolkit.getDefaultToolkit().getScreenSize().height - 100)
	    setSize(getWidth(), Toolkit.getDefaultToolkit().getScreenSize().height-100);
	if(getWidth() < 200)
	    setSize(200, getHeight());
	setLocationRelativeTo(null);
	setTitle("Matematikspelet v" + mathgame.game.Main.VERSION + " - Diagnostiskt prov");
	//setVisible(true);
    }
    
    private void load(String filename){
	String q_name = null;
	String []answers; 
	try{
	    BufferedReader in
		= new BufferedReader(new FileReader(filename));
	    String rad;
	    while ( (rad=in.readLine())!= null){
		questions.add(rad);
	    }
	    	    
	    panel = new QPanel[questions.size()];
	    
	    for(int i=0; i<questions.size(); i++){
		
		Question q = QuestionToolbox.loadQuestion( (String)questions.elementAt(i));
				
		if(q instanceof TextQuestion){
		    q_name = ((TextQuestion) q).question;
		    answers = ((TextQuestion) q).answers;
		    //filename = 
		    panel[i] = new QPanel(""+(i+1) +". " +q_name, answers, (TextQuestion)q);
		    
		    panel2.add(panel[i]);
		}
	    }
	}catch(IOException e){
	    e.printStackTrace();
	}catch(Exception e){
	    e.printStackTrace();
	}
       
    }

    public void actionPerformed(ActionEvent e){
	if(e.getSource() == doneButton) {
	    for(int i = 0; i < panel.length; i++) {
		if(panel[i].anySelected())
		    continue;
		JOptionPane.showMessageDialog(thisObject, "Du m�ste svara p� alla fr�gor!", "Fel", JOptionPane.ERROR_MESSAGE);
		return;
	    }
	    int counter = 0;
	    boolean b;
	    for(int i = 0; i < panel.length; i++) {
		b = panel[i].isCorrect();
		if(b)
		    counter++;
		Database.insertDiagnosQuestionResult(b, (String)questions.get(i), filename, panel[i].q.question, userid);
	    }
	    Database.insertDiagnosResult(filename, userid, counter);
	    if(mainWindow != null)
		mainWindow.initGame();
	    dispose();
	}
    }
    
    private class QPanel extends JPanel{
	JLabel namn;
	String [] svar;
	JRadioButton []svarKnappar;
	public TextQuestion q;
	public QPanel(String inamn, String [] isvar, TextQuestion iq){
	    q = iq;
	    namn = new JLabel(inamn);
	    svar = isvar;
	    setLayout(new GridLayout(0,1));
	    add(namn);
	    svarKnappar = new JRadioButton[svar.length];
	    ButtonGroup bg = new ButtonGroup();
	    for(int i=0; i<svarKnappar.length; i++){
		svarKnappar[i] = new JRadioButton(svar[i]);
		bg.add(svarKnappar[i]);
		add(svarKnappar[i]);
	    }
	    
		      		
	}
	
	public boolean anySelected() {
	    for(int i = 0; i < svarKnappar.length; i++) {
		if(svarKnappar[i].isSelected())
		    return true;
	    }
	    return false;
	}
	
	public boolean isCorrect() {
	    return svarKnappar[q.correctAnswer].isSelected();
	}

    }

}
