package mathgame.game;

// Please do not use this class
public class SpriteData {

    private int x;
    private int y;
    private int width;
    private int height;
    private int layer;
    private String imageFilename;
    private String spriteName;

    public SpriteData(String spriteName, int x, int y, int width, int height, int layer, String imageFilename) 
	throws Exception {
	if(x < 0) throw new Exception("x coordinate < 0");
	if(y < 0) throw new Exception("y coordinate < 0");
	if(width <= 0) throw new Exception("Sprite width <= 0");
	if(height <= 0) throw new Exception("Sprite height <= 0");
	if(layer < 0 || layer > 4) throw new Exception("Illegal layer number");

	this.spriteName = spriteName;
	this.x = x;
	this.y = y;
	this.width = width;
	this.height = height;
	this.layer = layer;
	this.imageFilename = imageFilename;
    }

    public int getX(){
	return x;
    }

    public int getY(){
	return y;
    }

    public int getWidth(){
	return width;
    }

    public int getHeight(){
	return height;
    }

    public int getLayer(){
	return layer;
    }

    public String getImageFilename(){
	return imageFilename;
    }

    public String getSpriteName(){
	return spriteName;
    }

    public String getSpriteData(){
	return spriteName+" "+layer+" "+x+" "+y+" "+width+" "+height+" "+layer+" "+imageFilename;
    }

    public void setX(int x) throws Exception {
	if(x < 0) throw new Exception("x coordinate < 0");
	this.x = x;
    }

    public void setY(int y) throws Exception {
	if(y < 0) throw new Exception("y coordinate < 0");
	this.y = y;
    }
    
    public void setWidth(int width) throws Exception {
	if(width <= 0) throw new Exception("Sprite width <= 0");
	this.width = width;
    }

    public void setHeight(int height) throws Exception {
	if(height <= 0) throw new Exception("Sprite height <= 0");
	this.height = height;
    }

    public void setLayer(int layer) throws Exception {
	if(layer < 0 || layer > 4) throw new Exception("Illegal layer number");
	this.layer = layer;
    }

    public void setImageFilename(String imageFilename){
	this.imageFilename = imageFilename;
    }

    public void setSpriteName(String spriteName){
	this.spriteName = spriteName;
    }

}
