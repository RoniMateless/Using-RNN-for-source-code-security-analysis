package mathgame.database;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import mathgame.editor.*;
import mathgame.question.*;

public class ForstaLarare extends JFrame implements ActionListener {

  JPanel contentPane;
  GridLayout fl = new GridLayout(9,2);
  JPanel panelFrame;

  Connection conn;

  JLabel jLabelempty1 = new JLabel(" ");
  JLabel jLabelempty2 = new JLabel(" ");
  JLabel jLabelempty3 = new JLabel(" ");
  JLabel jLabelempty4 = new JLabel(" ");
  JLabel jLabelempty5 = new JLabel(" ");
  JLabel jLabelempty6 = new JLabel(" ");
  JLabel jLabelempty7 = new JLabel(" ");
  JLabel jLabelempty8 = new JLabel(" ");


  JLabel jLabelMoment = new JLabel("V�lj matematikmoment: ");

  JButton buttonSkapaB = new JButton("Skapa ny bana");
  JButton buttonSkapaD = new JButton("Skapa fr�ga");
  JButton buttonResultat = new JButton("Se resultat");

    SeResultat resultatWindow;

  //Skapar en ny fr�ga
  JTextField textFieldFraga = new JTextField(15);
  JTextField textFieldSvar = new JTextField(15);

  JLabel jLabelFraga = new JLabel("Fr�ga:");
  JLabel jLabelSvar = new JLabel("Svar:");
    
    Editor editor;
    QuestionEditor questionEditor;
    
  public String tFraga = textFieldFraga.getText(); //ny fr�ga
  public String tSvar= textFieldSvar.getText(); //svar till nya fr�gan


  /**Construct the frame*/
  public ForstaLarare() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  /**Component initialization*/
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(new FlowLayout(1,1,1));
    contentPane.setBackground(Color.white);
    this.setSize(new Dimension(500, 300));
    this.setTitle("Matematikspelet v" + mathgame.game.Main.VERSION + " - L�rare");
    createFrame();

  }


  private void createFrame(){
    panelFrame= new JPanel();
    panelFrame.setLayout(fl);
    panelFrame.setBackground(Color.white);

    //L�gger till actionlistener
    buttonSkapaB.addActionListener(this);
    buttonSkapaD.addActionListener(this);
    buttonResultat.addActionListener(this);

    buttonSkapaB.setBackground(Color.pink);
    buttonSkapaD.setBackground(Color.pink);
    buttonResultat.setBackground(Color.pink);



    panelFrame.add(jLabelempty7);
    panelFrame.add(jLabelempty8);

    panelFrame.add(buttonSkapaB);
    panelFrame.add(jLabelempty1);

    panelFrame.add(jLabelempty3);
    panelFrame.add(jLabelempty4);

    panelFrame.add(buttonSkapaD);
    panelFrame.add(jLabelempty2);

    panelFrame.add(jLabelempty5);
    panelFrame.add(jLabelempty6);

    panelFrame.add(buttonResultat);





    contentPane.add(panelFrame);
    contentPane.setVisible(true);

 }

 //**************************************************************************
 private void connectToDb(){

  try {

  //Ladda in databas driver
  Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
  //Connecta mot db
  conn = DriverManager.getConnection("jdbc:odbc:math-game");
  conn.setAutoCommit(true);
      // Print all warnings
      for( SQLWarning warn = conn.getWarnings(); warn != null; warn = warn.getNextWarning() )
         {
          System.out.println( "SQL Warning:" ) ;
          System.out.println( "State  : " + warn.getSQLState()  ) ;
          System.out.println( "Message: " + warn.getMessage()   ) ;
          System.out.println( "Error  : " + warn.getErrorCode() ) ;
         }
      // Get a statement from the connection

          conn.close() ;

      // Execute the query
      //ResultSet rs = stmt.executeQuery( "SELECT Personnummer, F�rnamn FROM Person" ) ;
     }


  catch( SQLException se )
     {
      System.out.println( "SQL Exception:" ) ;

      // Loop through the SQL Exceptions
      while( se != null )
         {
          System.out.println( "State  : " + se.getSQLState()  ) ;
          System.out.println( "Message: " + se.getMessage()   ) ;
          System.out.println( "Error  : " + se.getErrorCode() ) ;

          se = se.getNextException() ;
         }
     }
  catch( Exception e )
     {
      System.out.println( e ) ;
     }
 }


public void actionPerformed(ActionEvent e) {

  if(e.getSource()== buttonSkapaB){

      if(editor == null || !editor.isVisible()) {
	  editor = new Editor();
      }
      else JOptionPane.showMessageDialog(this, "Du har redan ett editorf�nster �ppet.", "FEL", JOptionPane.ERROR_MESSAGE);

      //this.dispose();

  }else if(e.getSource()== buttonSkapaD){

      if(questionEditor == null || !questionEditor.isVisible()) {
	  questionEditor = new QuestionEditor();
      }
      else JOptionPane.showMessageDialog(this, "Du har redan ett fr�geskapar-f�nster �ppet.", "FEL", JOptionPane.ERROR_MESSAGE);
     

      //this.dispose();

  }else if(e.getSource()== buttonResultat){
      if(resultatWindow == null || !resultatWindow.isVisible())
	  resultatWindow = new RunSeResultat().getWindow();
      else JOptionPane.showMessageDialog(this, "Du har redan ett \"Se resultat\"-f�nster �ppet.", "FEL", JOptionPane.ERROR_MESSAGE);

  //this.dispose();


}

}

  /**Overridden so we can exit when window is closed*/
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      System.exit(0);
    }
  }


}
