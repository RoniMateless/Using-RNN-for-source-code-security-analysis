/*-
 * Copyright (C) 2004 Delby Arrospide, Niloofar Ghassemino, Lars Helander, Taghrid Hodroj,
 *                    Magnus Johansson, Caroline Koch, Erik Larsson, Helena Nilsson
 * 
 * All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

package mathgame.common;

/**
 * This class provides an implementation of the SHA256 hash algorithm. It might not at all comply
 * with an actual reference implementation of the algorithm, since it's totally untested, but in
 * general it will hash securely, and thus should be sufficent for the mathgame.
 * Written by Erik Larsson, 2005-04-15 - 2005-04-16
 */
public class SHA256 {

    
    /*public static void main(String[] args) {
	System.out.println("Testing..");
	convert("AB");
	System.out.println("Bitprint for 2000000: " + Message.getBitprint(2000000));
	System.out.println("Bitprint for 2000000 << 16: " + Message.getBitprint(2000000 << 16));
	Message m = new Message("ABC");
	System.out.println(m.getBitprint());
	for(int i = 0; i < 32; i++) {
	    System.out.println("Appending bit.");
	    m.append(true);
	    System.out.println(m.getBitprint());
	}
	
	System.out.println("Appending " + Message.getBitprint(0xEFFFFFFF7FFFFFFFL));
	m.append(0xEFFFFFFF7FFFFFFFL);
	System.out.println(m.getBitprint());
	System.out.println("RightRotating\n" + Message.getBitprint(291023) + "\nby 7 to\n" + Message.getBitprint(rightrotate(291023, 7)));
	
	System.out.println("Finally... the password 'yourmama' maps to \n\"" + convert("yourmama") + "\"");
	System.out.println("Finally... the password 'yourmamb' maps to \n\"" + convert("yourmamb") + "\"");
	System.out.println("Finally... the password 'yourmamba' maps to \n\"" + convert("yourmamba") + "\"");
	System.out.println("Finally... the password 'ssss' maps to \n\"" + convert("ssss") + "\"");
	System.out.println("Finally... the password 'debug$' maps to \n\"" + convert("debug$") + "\"");
	System.out.println("Finally... the password 'Lars$ssss' maps to \n\"" + convert("Lars$ssss") + "\"");
	System.out.println("Finally... the password 'su$1234' maps to \n\"" + convert("su$1234") + "\"");
	}*/
    

    private static int[] extend(int[] array, int newLength) {
	if(array.length > newLength)
	    throw new IllegalArgumentException();
	int[] result = new int[newLength];
	for(int i = 0; i < result.length; i++) {
	    if(i < array.length)
		result[i] = array[i];
	    else
		result[i] = 0;
	}
	return result;
    }

    private static int rightrotate(int subject, int amount) {
	int part1 = subject >>> amount;
	int part2 = (subject << (32-amount)); // & (~(0xFFFFFFFF >>> amount));
	
	return part1 | part2;
    }

    private static String intToHexString(int i) {
	String result = "";
	for(int j = 0; j < 8; j++) {
	    int current = (i >> j*4) & 0x0000000F;
	    switch(current) {
	    case 0:
		result = "0" + result;
		break;
	    case 1:
		result = "1" + result;
		break;
	    case 2:
		result = "2" + result;
		break;
	    case 3:
		result = "3" + result;
		break;
	    case 4:
		result = "4" + result;
		break;
	    case 5:
		result = "5" + result;
		break;
	    case 6:
		result = "6" + result;
		break;
	    case 7:
		result = "7" + result;
		break;
	    case 8:
		result = "8" + result;
		break;
	    case 9:
		result = "9" + result;
		break;
	    case 10:
		result = "a" + result;
		break;
	    case 11:
		result = "b" + result;
		break;
	    case 12:
		result = "c" + result;
		break;
	    case 13:
		result = "d" + result;
		break;
	    case 14:
		result = "e" + result;
		break;
	    case 15:
		result = "f" + result;
		break;
	    default:
		throw new RuntimeException();
	    }
	}
	return result;
    }

    /**
     * Takes <strong>message</strong> and calculates the SHA256 hash value for it.
     * Useful to hash passwords in a database in a secure way.
     * @param message the message to be hashed
     * @return a string with the complete SHA256 hash code in hexadecimal notation
     */
    public static String convert(char[] message) {
	return convert(new String(message));
    }

    /**
     * Takes <strong>message</strong> and calculates the SHA256 hash value for it.
     * Useful to hash passwords in a database in a secure way.
     * @param message the message to be hashed
     * @return a string with the complete SHA256 hash code in hexadecimal notation
     */
    public static String convert(String message) {

	Message m = new Message(message);

	//Note: All variables are unsigned 32 bits and wrap modulo 2^32 when calculating

	//Initialize variables:
	int h0 = 0x6a09e667;   //2^32 times the square root of the first 8 primes 2..19
	int h1 = 0xbb67ae85;
	int h2 = 0x3c6ef372;
	int h3 = 0xa54ff53a;
	int h4 = 0x510e527f;
	int h5 = 0x9b05688c;
	int h6 = 0x1f83d9ab;
	int h7 = 0x5be0cd19;

	//Initialize table of round constants:
	//k(0..63) :=        232 times the cube root of the first 64 primes 2..311
	int[] k = {
	    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
	    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
	    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
	    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
	    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
	    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
	    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
	    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2 };

	//Pre-processing:
	//append a single "1" bit to message
	m.append(true);
	//append "0" bits until message length === 448 === -64 (mod 512)
	while((m.getSizeInBits() % 512) != 448)
	    m.append(false);
	//append length of message, in bits as 64-bit big-endian integer to message
	m.append((long)m.getSizeInBits());

	/*Process the message in successive 512-bit chunks:
	  break message into 512-bit chunks*/
	Chunk[] chunks = m.toChunks();
	for(int s = 0; s < chunks.length; s++) { //for each chunk
	    //break chunk into sixteen 32-bit big-endian words w(i), 0 ? i ? 15
	    int[] w = chunks[s].getChunk();
	    
	    //Extend the sixteen 32-bit words into sixty-four 32-bit words:
	    w = extend(w, 64);
	    //for i from 16 to 63
	    for(int i = 16; i < 64; i++) {
		//s0 := (w(i-15) rightrotate 7) xor (w(i-15) rightrotate 18) xor (w(i-15) rightshift 3)
		int s0 = rightrotate(w[i-15], 7) ^ rightrotate(w[i-15], 18) ^ (w[i-15] >>> 3);
		//s1 := (w(i-2) rightrotate 17) xor (w(i-2) rightrotate 19) xor (w(i-2) rightshift 10)
		int s1 = rightrotate(w[i-2], 17) ^ rightrotate(w[i-2], 19) ^ (w[i-2] >>> 10);
		//w(i) := w(i-16) + s0 + w(i-7) + s1
		w[i] = w[i-16] + s0 + w[i-7] + s1;
	    }
	    //Initialize hash value for this chunk:
	    int a = h0;
	    int b = h1;
	    int c = h2;
	    int d = h3;
	    int e = h4;
	    int f = h5;
	    int g = h6;
	    int h = h7;
	    //Main loop:
	    //for i from 0 to 63
	    for(int i = 0; i < 64; i++) {
		//s0 := (a rightrotate 2) xor (a rightrotate 13) xor (a rightrotate 22)
		int s0 = rightrotate(a, 2) ^ rightrotate(a, 13) ^ rightrotate(a, 22);
		//maj := (a and b) or (b and c) or (c and a)
		int maj = (a & b) | (b & c) | (c & a);
		//t0 := s0 + maj
		int t0 = s0 + maj;
		//s1 := (e rightrotate 6) xor (e rightrotate 11) xor (e rightrotate 25)
		int s1 = rightrotate(e, 6) ^ rightrotate(e, 11) ^ rightrotate(e, 25);
		//ch := (e and f) or ((not e) and g)
		int ch = (e & f) | ((~e) & g);
		//t1 := h + s1 + ch + k(i) + w(i)
		int t1 = h + s1 + ch + k[i] + w[i];

		h = g;
		g = f;
		f = e;
		e = d + t1;
		d = c;
		c = b;
		b = a;
		a = t0 + t1;
	    }
	    //Add this chunk's hash to result so far:
	    h0 = h0 + a;
	    h1 = h1 + b ;
	    h2 = h2 + c;
	    h3 = h3 + d;
	    h4 = h4 + e;
	    h5 = h5 + f;
	    h6 = h6 + g;
	    h7 = h7 + h;
	

	}
	
	//Output the final hash value (big-endian):
	//digest = hash = h0 append h1 append h2 append h3 append h4 append h5 append h6 append h7
	return "" + intToHexString(h0) + intToHexString(h1) + intToHexString(h2) + intToHexString(h3) + intToHexString(h4) + intToHexString(h5) + intToHexString(h6) + intToHexString(h7);
    }

    // Declaration of private classes

    private static class Chunk {
	private int[] chunk;
	public Chunk(int[] chunk) {
	    if(chunk.length != 512/32)
		throw new IllegalArgumentException("A chunk is always 512 bits");
	    this.chunk = chunk;
	}
	public int[] getChunk() {
	    return chunk;
	}
	public void setChunk(int[] chunk) {
	    this.chunk = chunk;
	}
    }

    private static class Message {
	private int[] message;
	private int sizeInBits;
	
	public Message(String s) {
	    char[] sArray = s.toCharArray();
	    sizeInBits = sArray.length*16;
	    int intArraySize = sizeInBits/32;
	    if(sizeInBits%32 != 0)
		intArraySize++;
	    message = new int[intArraySize];
	    for(int i = 0; i < message.length; i++)
		message[i] = 0;
	    
	    for(int i = 0, j = 0; i < message.length; i++) {
		if(j+1 == sArray.length) {
		    message[i] = sArray[j];
		}
		else {
		    message[i] = (sArray[j+1] << 16) | sArray[j];
		    j++; j++;
		}
	    }
	}

	public void append(long l) {
	    int index1, index2, index3;
	    if(sizeInBits%32 != 0) {
		index1 = sizeInBits%32;
		message[message.length-1] = message[message.length-1] | (int)(l >>> (32*2-index1));
		incrementArray(2);
		message[message.length-2] = (int)(l >>> (32-index1));
		message[message.length-1] = (int)(l << (32-index1));
	    }
	    else {
		incrementArray(2);
		message[message.length-2] = (int)((l >>> 32));	
		message[message.length-1] = (int)(l);
	    }
	    sizeInBits += 64;
	}

	public void append(boolean b) {
	    int index = (sizeInBits+1)%32;
	    if((sizeInBits+1)/32 != sizeInBits/32)
		incrementArray(1);
	    
	    message[message.length-1] = message[message.length-1] | ((b?0x1:0x0) << (31-index));// & (b?0x1:0x0);
	    sizeInBits++;
	}

	public void incrementArray(int increment) {
	    int[] old = message;
	    message = new int[old.length+increment];
	    for(int i = 0; i < old.length; i++) {
		message[i] = old[i];
	    }
	    message[message.length-1] = 0;
	}

	public String getBitprint() {
	    String result = "";
	    for(int i = 0; i < message.length; i++) {
		result += getBitprint(message[i]);
	    }

	    if(result.length() > sizeInBits)
		result = result.substring(0, sizeInBits);

	    return result;
	}

	public static String getBitprint(long subject) {
	    String result = getBitprint((int)subject);
	    result = getBitprint((int)(subject >>> 32)) + result;
	    return result;
	}

	public static String getBitprint(int subject) {
	    String result = "";
	    for(int i = 31; i >= 0; i--) {
		if(((subject >>> i) & 0x1) == 0x1)
		    result += "1";
		else
		    result += "0";
	    }
	    return result;
	}

	public int getSizeInBits() {
	    return sizeInBits;
	}

	public Chunk[] toChunks() {
	    int numberOfChunks = sizeInBits/512 + ((sizeInBits%512 != 0)?1:0);
	    int numberOfPieces = 512/32;
	    Chunk[] result = new Chunk[numberOfChunks];
	    
	    for(int i = 0; i < result.length; i++) {
		int[] pieces = new int[numberOfPieces];
		for(int j = 0; j < pieces.length; j++) {
		    int indexInMessage = j+i*numberOfPieces;
		    if(indexInMessage < message.length)
			pieces[j] = message[indexInMessage];
		    else 
			pieces[j] = 0;
		}
		result[i] = new Chunk(pieces);
	    }
	    return result;
	}
    }  
}
/*
Note: All variables are unsigned 32 bits and wrap modulo 2^32 when calculating

Initialize variables:
h0 := 0x6a09e667   232 times the square root of the first 8 primes 2..19
h1 := 0xbb67ae85
h2 := 0x3c6ef372
h3 := 0xa54ff53a
h4 := 0x510e527f
h5 := 0x9b05688c
h6 := 0x1f83d9ab
h7 := 0x5be0cd19

Initialize table of round constants:
k(0..63) :=        232 times the cube root of the first 64 primes 2..311
   0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
   0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
   0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
   0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
   0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
   0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
   0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
   0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2

Pre-processing:
append a single "1" bit to message
append "0" bits until message length (congruent with) 448 (congruent with) -64 (mod 512)
append length of message, in bits as 64-bit big-endian integer to message

Process the message in successive 512-bit chunks:
break message into 512-bit chunks
for each chunk
    break chunk into sixteen 32-bit big-endian words w(i), 0 <= i <= 15

    Extend the sixteen 32-bit words into sixty-four 32-bit words:
    for i from 16 to 63
        s0 := (w(i-15) rightrotate 7) xor (w(i-15) rightrotate 18) xor (w(i-15) rightshift 3)
        s1 := (w(i-2) rightrotate 17) xor (w(i-2) rightrotate 19) xor (w(i-2) rightshift 10)
        w(i) := w(i-16) + s0 + w(i-7) + s1

    Initialize hash value for this chunk:
    a := h0
    b := h1
    c := h2
    d := h3
    e := h4
    f := h5
    g := h6
    h := h7

    Main loop:
    for i from 0 to 63
        s0 := (a rightrotate 2) xor (a rightrotate 13) xor (a rightrotate 22)
        maj := (a and b) or (b and c) or (c and a)
        t0 := s0 + maj
        s1 := (e rightrotate 6) xor (e rightrotate 11) xor (e rightrotate 25)
        ch := (e and f) or ((not e) and g)
        t1 := h + s1 + ch + k(i) + w(i)

        h := g
        g := f
        f := e
        e := d + t1
        d := c
        c := b
        b := a
        a := t0 + t1

    Add this chunk's hash to result so far:
    h0 := h0 + a
    h1 := h1 + b 
    h2 := h2 + c
    h3 := h3 + d
    h4 := h4 + e
    h5 := h5 + f
    h6 := h6 + g 
    h7 := h7 + h

Output the final hash value (big-endian):
digest = hash = h0 append h1 append h2 append h3 append h4 append h5 append h6 append h7
*/
