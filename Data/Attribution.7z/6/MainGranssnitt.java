package mathgame.database;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class MainGranssnitt extends JFrame implements ActionListener {

    JPanel contentPane;
    GridLayout fl = new GridLayout(5,2);
    JPanel panelFrame;
    boolean flag=false;
    Connection conn;
    PreparedStatement pstmt1;
    PreparedStatement pstmt2, pstmt3;
    String query2;
    String query1, query3;
    ResultSet rs1;
    ResultSet rs2, rs3;
    static String p, a, l, lararePnr, elevPnr;


    JTextField textFieldpnr = new JTextField(15);
    JTextField textFieldanv = new JTextField(15);
    JTextField textFieldpwd = new JPasswordField(15);

    JLabel jLabelpnr = new JLabel("Login Nummer");
    JLabel jLabelanv = new JLabel("Anv�ndarnamn");
    JLabel jLabelpwd = new JLabel("L�senord");

    JLabel jLabelempty1 = new JLabel(" ");
    JLabel jLabelempty2 = new JLabel(" ");

    JButton buttonNyanv = new JButton("Ny Anv�ndare");
    JButton buttonLogIn = new JButton("Logga In");

    public String tpnr =  textFieldpnr.getText(); //den inloggade spelarens personnummer
    public String tanv= textFieldanv.getText(); //den inloggade spelarens anv�ndarnamn
    public String tpwd = textFieldpwd.getText(); //den inloggade spelarens l�senord

    /**Construct the frame*/
    public MainGranssnitt() {
	enableEvents(AWTEvent.WINDOW_EVENT_MASK);
	try {
	    jbInit();
	}
	catch(Exception e) {
	    e.printStackTrace();
	}
	setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
    /**Component initialization*/
    private void jbInit() throws Exception  {

	contentPane = (JPanel) this.getContentPane();
	contentPane.setLayout(new FlowLayout(1,1,1));
	contentPane.setBackground(Color.white);
	this.setSize(new Dimension(500, 300));
	this.setTitle("Matematikspelet v" + mathgame.game.Main.VERSION + " - Inloggning");
	createFrame();
    }
    

    private void createFrame(){
	panelFrame= new JPanel();
	panelFrame.setLayout(fl);
	panelFrame.setBackground(Color.white);

	//panelForm1.setSize(new Dimension(400, 400));

	//L�gger till actionlistener
	buttonNyanv.addActionListener(this);
	buttonLogIn.addActionListener(this);

	buttonLogIn.setBackground(Color.pink);
	buttonNyanv.setBackground(Color.pink);


	panelFrame.add(jLabelpnr);
	panelFrame.add(textFieldpnr);

	panelFrame.add(jLabelanv);
	panelFrame.add(textFieldanv);

	panelFrame.add(jLabelpwd);
	panelFrame.add(textFieldpwd);

	panelFrame.add(jLabelempty1);
	panelFrame.add(jLabelempty2);

	panelFrame.add(buttonNyanv);
	panelFrame.add(buttonLogIn);

	contentPane.add(panelFrame);
	contentPane.setVisible(true);

    }

    //**************************************************************************
    private void connectToDb(){



	try {

	    //Ladda in databas driver
	    Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	    //Connecta mot db
	    conn = DriverManager.getConnection("jdbc:odbc:math-game");
	    conn.setAutoCommit(true);
	    // Print all warnings
	    for( SQLWarning warn = conn.getWarnings(); warn != null; warn = warn.getNextWarning() )
		{
		    System.out.println( "SQL Warning:" ) ;
		    System.out.println( "State  : " + warn.getSQLState()  ) ;
		    System.out.println( "Message: " + warn.getMessage()   ) ;
		    System.out.println( "Error  : " + warn.getErrorCode() ) ;
		}
	    // Get a statement from the connection
	    query1= "SELECT personnummer, anv�ndarnamn, l�senord FROM Person WHERE personnummer = ?";
	    query2="SELECT personnummer FROM L�rare where personnummer = ?";
	    query3="SELECT personnummer FROM Elev where personnummer = ?";
	    pstmt1 = conn.prepareStatement(query1) ;
	    pstmt2 = conn.prepareStatement(query2) ;
	    pstmt3 = conn.prepareStatement(query3) ;


	    pstmt2.setString(1, tpnr);
	    pstmt1.setString(1, tpnr);
	    pstmt3.setString(1, tpnr);

	    rs1=pstmt1.executeQuery();
	    rs2=pstmt2.executeQuery();
	    rs3=pstmt3.executeQuery();

	    while( rs1.next() ){
		p=(String)(rs1.getString(1));
		a=rs1.getString(2);
		l=rs1.getString(3);
	    }

	    while( rs2.next() ){
		lararePnr=(String)(rs2.getString(1));

	    }

	    while( rs3.next() ){
		elevPnr=(String)(rs3.getString(1));

	    }

	    try{

		if(lararePnr != null && lararePnr.equals(p)){
		    flag=true;
		}else if(elevPnr != null && elevPnr.equals(p)){
		    flag=false;
		}
	    }catch(Exception ex){

	    }


	    rs1.close() ;
	    rs2.close();
	    rs3.close();
	    pstmt1.close() ;
	    pstmt2.close();
	    pstmt3.close();
	    conn.close() ;

	    // Execute the query
	    //ResultSet rs = stmt.executeQuery( "SELECT Personnummer, F�rnamn FROM Person" ) ;
	}


	catch( SQLException se )
	    {
		System.out.println( "SQL Exception:" ) ;

		// Loop through the SQL Exceptions
		while( se != null )
		    {
			System.out.println( "State  : " + se.getSQLState()  ) ;
			System.out.println( "Message: " + se.getMessage()   ) ;
			System.out.println( "Error  : " + se.getErrorCode() ) ;

			se = se.getNextException() ;
		    }
	    }
	catch( Exception e )
	    {
		System.out.println( e ) ;
	    }
    }


    public void actionPerformed(ActionEvent e) {

	tpnr = textFieldpnr.getText();
	tanv= textFieldanv.getText();
	tpwd = textFieldpwd.getText();

	if(e.getSource()== buttonNyanv ){
	    //Komma till formul�r, registrera ny anv�ndare
	    this.dispose();
	    new RunNyAnv();
	}

	if(e.getSource()== buttonLogIn ){
	    connectToDb();
	    if(tpnr.equals("") || tanv.equals("") || tpwd.equals("")){
		//if(tpnr.equals("") || tanv==null || tpwd==null){
		JOptionPane.showMessageDialog(this, "Du har inte fyllt i alla f�lt!", "OBS!", JOptionPane.ERROR_MESSAGE);

		// }else if (!p.equals(tpnr) || !a.equals(tanv) || !l.equals(tpwd) ){
	    }else if (p==null || a==null || l==null ){
		JOptionPane.showMessageDialog(this, "Du har fyllt i fel uppgifter!", "OBS!", JOptionPane.ERROR_MESSAGE);
		//System.out.println("Jag �r INTE inloggad!!!!!");

	    }


	    else if(p.equals(tpnr) && a.equals(tanv) && l.equals(tpwd) && flag==false) {
		this.dispose();
		new RunForstaElev(getLoginNr());
	    }else if (p.equals(tpnr) && a.equals(tanv) && l.equals(tpwd) && flag==true){
		this.dispose();
		new RunForstaLarare();


	    }else{

		JOptionPane.showMessageDialog(this, "FEL", "OBS!", JOptionPane.ERROR_MESSAGE);
	    }
	}
    }

    /**
     * Returnerar login-nummer f�r den som �r inloggad
     */
    public static String getLoginNr(){
	return p;
    }


    /**Overridden so we can exit when window is closed*/
    protected void processWindowEvent(WindowEvent e) {
	super.processWindowEvent(e);
	if (e.getID() == WindowEvent.WINDOW_CLOSING) {
	    //System.exit(0);
	}
    }


}
