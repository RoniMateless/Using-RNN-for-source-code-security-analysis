package mathgame.editor;

import mathgame.common.*;
import java.awt.*;
import java.awt.font.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.image.*;

public class PictureViewer extends JPanel  {

    private TitledPicture [] pictures;
    private LayeredPictureChooser listener;
    private int thumbNailsWidth;
    private int thumbNailsHeight;
    private int borderSize;
    private int selected = -1;

    public static final int DEFAULT_BORDER_SIZE = 20;

    public PictureViewer(Image [] pics, int thumbNailsWidth, int thumbNailsHeight){
	this.thumbNailsWidth = thumbNailsWidth;
	this.thumbNailsHeight = thumbNailsHeight;
	borderSize = DEFAULT_BORDER_SIZE;
	pictures = new TitledPicture[pics.length];	

	setSize((2*borderSize + thumbNailsWidth)*pics.length,
		2*borderSize + thumbNailsHeight); 

	for(int i=0; i<pics.length; i++){	    
	    int width = -1;
	    while(width == -1)
		width = pics[i].getWidth(null);
	    int height = -1;
	    while(height == -1)
		height = pics[i].getHeight(null);
	    if(width <= thumbNailsWidth && height <= thumbNailsHeight)
		pictures[i] = new TitledPicture(pics[i], ""+width+"x"+height);
	    else if(width > thumbNailsWidth && height > thumbNailsHeight){
		if(width / (double) thumbNailsWidth > height / (double) thumbNailsHeight)
		    pictures[i] = new TitledPicture(pics[i].getScaledInstance(thumbNailsWidth, 
									      (int) (height*(thumbNailsWidth/(double)width)), 
									  Image.SCALE_DEFAULT), ""+width+"x"+height);
		else 
		    pictures[i] = new TitledPicture(pics[i].getScaledInstance((int) (width*(thumbNailsHeight/(double)height)), thumbNailsHeight, Image.SCALE_DEFAULT), ""+width+"x"+height);
	    }
	    else if(width > thumbNailsWidth){
		double ratio = thumbNailsWidth / (double) width;
		pictures[i] = new TitledPicture(pics[i].getScaledInstance(thumbNailsWidth, (int) (height*ratio), 
									  Image.SCALE_DEFAULT), ""+width+"x"+height);
	    }
	    else {
		double ratio = thumbNailsHeight / (double) height;
		pictures[i] = new TitledPicture(pics[i].getScaledInstance((int) (width*ratio), thumbNailsHeight, 
									  Image.SCALE_DEFAULT), ""+width+"x"+height);
	    }
	}

	addMouseListener(new MouseAdapter (){
		public void mousePressed(MouseEvent e){
		    selectPicture(e);
		}
	    });
    }

    public Dimension getSize(){
	return new Dimension((2*borderSize + thumbNailsWidth)*pictures.length,
			     2*borderSize + thumbNailsHeight);
    }

    public void setListener(LayeredPictureChooser listener){
	this.listener = listener;
    }

    protected void paintComponent(Graphics g){
	super.paintComponent(g);
	for(int i=0; i<pictures.length; i++){
	    if(i % 2 == 0)
		g.setColor(Color.white);
	    else g.setColor(new Color(240, 240, 240));
	    	    g.fillRect(i*(2*borderSize + thumbNailsWidth), 0, 2*borderSize + thumbNailsWidth,
		       2*borderSize + thumbNailsHeight);
    	    pictures[i].render(g, i*(2*borderSize + thumbNailsWidth), 0);
	}
	if(selected != -1){
	    g.setColor(new Color(100,100,255,100));
	    int elementWidth = 2*borderSize + thumbNailsWidth;
	    int elementHeight = 2*borderSize + thumbNailsHeight;
	    g.fillRect(selected*elementWidth, 0, elementWidth, elementHeight);
	}
    }

    public int getBorderSize(){
	return borderSize;
    }

    public void setBorderSize(int borderSize){
	this.borderSize = borderSize;
    }

    public int getSelected(){
	return selected;
    }

    public void deselect(){
	selected = -1;
	repaint();
    }

    public Dimension getPreferredSize(){
	return getSize();
    }

    private void selectPicture(MouseEvent e){
	if(e.getY() < 0 || e.getY() > getSize().getHeight()
	   || e.getX() < 0 || e.getX() > getSize().getWidth()){
	    selected = -1;
	    return;
	}
	int newSelect = (int) Math.floor(e.getX() / (2*borderSize + thumbNailsWidth));
	if(selected == newSelect) selected = -1;
	else {
	    selected = newSelect;
	    listener.notify(selected); // Notify our listener
	}
	repaint(); 
    }

    private class TitledPicture {

	public static final int TITLE_ABOVE = 0;
	public static final int TITLE_BELOW = 1;
	public static final int DEFAULT_GAP = 3;

	private Image picture;
	private int width;
	private int height;
	private String title;
	private int titlePolicy;
	private int hGap;

	public TitledPicture(Image picture, String title){
	    this.picture = picture;
	    this.title = title; 
	    width = -1;
	    while(width == -1)
		width = picture.getWidth(null);
	    height = -1;
	    while(height == -1)
		height = picture.getHeight(null);
	    titlePolicy = TITLE_BELOW;
	    hGap = DEFAULT_GAP;		
	}

	public void render(Graphics g, int offsetX, int offsetY){
	    if(titlePolicy == TITLE_ABOVE) return; //Not implemented yet
	    else if(titlePolicy == TITLE_BELOW){
		g.drawImage(picture, offsetX + borderSize + (thumbNailsWidth - width)/2, 
			    offsetY + borderSize + (thumbNailsHeight - height)/2, null);
		int titleWidth = g.getFontMetrics().stringWidth(title);
		int titleHeight = g.getFontMetrics().getHeight();
		g.setColor(Color.black);
		g.drawString(title, offsetX + borderSize + (thumbNailsWidth - titleWidth)/2, 
			     offsetY + borderSize + thumbNailsHeight + hGap + titleHeight/2);
	    }
	}

    }


}
