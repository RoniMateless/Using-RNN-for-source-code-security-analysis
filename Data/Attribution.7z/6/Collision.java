package mathgame.game;
import mathgame.common.*;

public class Collision {

    public static final int NONE = 0;
    public static final int LEFT = 1;
    public static final int RIGHT = 2;
    public static final int UP = 4;
    public static final int DOWN = 8;
    public boolean left = false;
    public boolean right = false;
    public boolean up = false;
    public boolean down = false;
    private LevelObject target;
    private int type;
    
    public Collision(LevelObject itarget) {
	target = itarget;
    }

    public Collision(LevelObject itarget, int itype) {
	target = itarget;
	setType(itype);
    }
    
    public LevelObject getTarget() {
	return target;
    }

    public void setTarget(LevelObject itarget){
	target = itarget;
    }

    public int getType() {
	return type;
    }
    
    public void setType(int i) {
	type = i;	
	if(i >= DOWN) {
	    i -= DOWN;
	    down = true;
	}
	if(i >= UP) {
	    i -= UP;
	    up = true;
	}
	if(i >= RIGHT) {
	    i -= RIGHT;
	    right = true;
	}
	if(i >= LEFT) {
	    i -= LEFT;
	    left = true;
	}
	if(i != NONE)
	    throw new IllegalArgumentException("Incorrect type specification");
    }
}
