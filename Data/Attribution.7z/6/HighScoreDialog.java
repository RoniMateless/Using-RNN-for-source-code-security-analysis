/*-
 * Copyright (C) 2004 Delby Arrospide, Niloofar Ghassemino, Lars Helander, Taghrid Hodroj,
 *                    Magnus Johansson, Caroline Koch, Erik Larsson, Helena Nilsson
 * 
 * All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

/*
 * Created on den 3 maj 2005, 23:18
 */

package mathgame.login;

import mathgame.common.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
/**
 *
 * @author  Erik Larsson
 */

public class HighScoreDialog extends JDialog {
    
    private JButton closeButton;
    private JPanel closeButtonPanel;
    private JTable highscoreTable;
    private DisplayHighscorePanel displayHighscorePanel;
    
    public HighScoreDialog(JFrame parent) {
	super(parent, true);
	displayHighscorePanel = new DisplayHighscorePanel(this);
	setTitle("Highscorelista");
	getContentPane().add(displayHighscorePanel);
	pack();
 	setResizable(false);
	setLocation(parent.getSize().width/2-getSize().width/2,
		    parent.getSize().height/2-getSize().height/2);
	setLocationRelativeTo(parent);
   }

    public void reset() {
	displayHighscorePanel.refreshList();
    }

    private class DisplayHighscorePanel extends JPanel {
	private HighScoreDialog parent;
	private DefaultTableModel tableModel;
	private Vector<String> columnNames = new Vector<String>(2);

	/** Creates a new DisplayHighscorePanel */
	public DisplayHighscorePanel(HighScoreDialog parent) {
	    this.parent = parent;
	    initComponents();
	    //refreshList();
	}
    
	private void initComponents() {
	    highscoreTable = new JTable();
	    closeButtonPanel = new JPanel();
	    closeButton = new JButton();

	    setLayout(new BorderLayout());

	    setBorder(new TitledBorder("Highscore"));

	    columnNames.add("Namn");
	    columnNames.add("Po�ng");

	    tableModel = new DefaultTableModel(0, 6) {
		    public boolean isCellEditable(int row, int col) {
			return false;
			//return col > 0;
		    }
		};
	    highscoreTable = new JTable(tableModel);
	    highscoreTable.setCellSelectionEnabled(false);
	    highscoreTable.setColumnSelectionAllowed(false);
	    highscoreTable.setRowSelectionAllowed(true);

	    add(new JScrollPane(highscoreTable), BorderLayout.CENTER);

	    closeButton.setText("St\u00e4ng");
	    closeButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent evt) {
			parent.dispose();
		    }
		});
	    closeButtonPanel.add(closeButton);

	    add(closeButtonPanel, BorderLayout.SOUTH);
	}
    
	public void refreshList() {
	    Database.Highscore[] infos = Common.getHighscoresFromFile();
	    Vector<Vector<String>> rowData = new Vector<Vector<String>>();
	    for(int i = 0; i < (infos.length > 10?10:infos.length); i++) { //We only want the 10 highest
		Database.Highscore info = infos[i];
		Vector<String> newItems = new Vector<String>();
		newItems.add(info.alias);
		newItems.add(info.score+"");
		rowData.add(newItems);
	    }
	    tableModel.setDataVector(rowData, columnNames);
	}
    }
}
