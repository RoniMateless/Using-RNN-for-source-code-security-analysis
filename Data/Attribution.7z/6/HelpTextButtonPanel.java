/*-
 * Copyright (C) 2004 Delby Arrospide, Niloofar Ghassemino, Lars Helander, Taghrid Hodroj,
 *                    Magnus Johansson, Caroline Koch, Erik Larsson, Helena Nilsson
 * 
 * All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

package mathgame.game.helptext;

import mathgame.common.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

public class HelpTextButtonPanel extends JPanel {
    
    private HelpTextViewer owner;

    private ArrayList<HelpTextButton> buttons;
    private HelpTextButton back;
    private HelpTextButton forward; 	
    private HelpTextButton close;

    public HelpTextButtonPanel(HelpTextViewer owner, Rectangle bounds) {
	this.owner = owner;

	buttons = new ArrayList<HelpTextButton>(3);

	setLayout(null);

	back = 
	    new HelpTextButton(this, 
			       ImageArchive.getImage(ResourceConstants.HELPTEXTBUTTONPANEL_LEFTARROW, false),
			       ImageArchive.getImage(ResourceConstants.HELPTEXTBUTTONPANEL_LEFTARROWPRESSED, false),
			       "Bak�t", true, new Rectangle(20, 7, 100, 26));

	forward = 
	    new HelpTextButton(this,
			       ImageArchive.getImage(ResourceConstants.HELPTEXTBUTTONPANEL_RIGHTARROW, false),
			       ImageArchive.getImage(ResourceConstants.HELPTEXTBUTTONPANEL_RIGHTARROWPRESSED, false),
			       "Fram�t", false, new Rectangle(130, 7, 100, 26));
	
	close =
	    new HelpTextButton(this,
			       ImageArchive.getImage(ResourceConstants.HELPTEXTBUTTONPANEL_CROSS, false),
			       ImageArchive.getImage(ResourceConstants.HELPTEXTBUTTONPANEL_CROSSPRESSED, false),
			       "St�ng", false, new Rectangle(bounds.width-120, 7, 100, 26));
	/*
	String dir = Common.IMAGEDIR + "/icons/";
	back = 
	    new HelpTextButton(this, 
			       ImageArchive.getImage(dir + "leftArrow.PNG"),
			       ImageArchive.getImage(dir + "leftArrowPressed.PNG"),
			       "Bak�t", true, new Rectangle(20, 7, 100, 26));

	forward = 
	    new HelpTextButton(this,
			       ImageArchive.getImage(dir + "rightArrow.PNG"),
			       ImageArchive.getImage(dir + "rightArrowPressed.PNG"),
			       "Fram�t", false, new Rectangle(130, 7, 100, 26));
	
	close =
	    new HelpTextButton(this,
			       ImageArchive.getImage(dir + "cross.PNG"),
			       ImageArchive.getImage(dir + "crossPressed.PNG"),
			       "St�ng", false, new Rectangle(bounds.width-120, 7, 100, 26));
	*/
	add(back);
	add(forward);
	add(close);
	buttons.add(back);
	buttons.add(forward);
	buttons.add(close);

	setBounds(bounds);
	setVisible(true);
    }

    public void paint(Graphics g) {}
    public void repaint() {}

    public void show(Graphics g) {
	drawBackground(g);
	drawBorder(g);
	for(HelpTextButton b : buttons) {
	    Point loc = b.getLocation();
	    g.translate(loc.x, loc.y);
	    //g.setClip(b.getBounds());
	    b.show(g);
	    g.translate(-loc.x, -loc.y);
	    //g.setClip(getBounds());
	}
    }

    public void buttonClicked(HelpTextButton b) {
	if(b == back) {
	    owner.goBack();
	}
	else if(b == forward) {
	    owner.goForward();
	}
	else if(b == close) {
	    owner.close();
	}
    }

    private void drawBackground(Graphics g) {
	g.setColor(Color.WHITE);
	g.fillRect(0, 0, getWidth(), getHeight());
    }

    private void drawBorder(Graphics g) {
	g.setColor(Color.BLACK);
	g.drawRect(0, 0, getWidth()-1, getHeight()-1);
	g.drawRect(1, 1, getWidth()-3, getHeight()-3);
    }

}
