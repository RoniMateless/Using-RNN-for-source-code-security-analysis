/*-
 * Copyright (C) 2004 Delby Arrospide, Niloofar Ghassemino, Lars Helander, Taghrid Hodroj,
 *                    Magnus Johansson, Caroline Koch, Erik Larsson, Helena Nilsson
 * 
 * All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

package mathgame.editor;

import mathgame.common.*;
import java.util.EventObject;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class LevelPropertiesDialog extends JDialog implements ActionListener {

    private JButton okButton;
    private JButton cancelButton;
    private JButton browseButton;
    private JTextField timeField;
    private JTextField musicField;
    private JTextField[] parts;
    private JTextField keyLimitField;
    private JTextField forceLimitField;
    private JTextField forceIntervalField;
    private JTextField backgroundImageField;
    private SimpleFileFilter fileFilter;
    private JFileChooser fileChooser;

    private JCheckBox selectAll;
    private JCheckBox[] subjects;
    private JRadioButton[][] subjWeights;
    private JSlider levelSlider;
    private LevelEditorPane lep;

    public LevelPropertiesDialog(LevelEditorPane lep) {
	super(lep.parent, true);
	this.lep = lep;
	okButton = new JButton("OK");
	cancelButton = new JButton("Avbryt");
	browseButton = new JButton("Bl�ddra");
	timeField = new JTextField(5);
	musicField = new JTextField(25);
	parts = new JTextField[lep.parts.length];
	keyLimitField = new JTextField(3);

	JPanel backgroundPanel = new JPanel();
	backgroundPanel.setLayout(null);
	int gap = 22;
	int smallgap = 5;
	int x1 = smallgap;
	int x2 = 270;
	int y = smallgap;

	fileChooser = new JFileChooser(System.getProperty("user.dir"));
	fileFilter = new SimpleFileFilter();
	fileFilter.addExtension("mid");
	fileFilter.setDescription("MIDI-fil (*.mid)");
	fileChooser.addChoosableFileFilter(fileFilter);

	
	JLabel timeLimitLabel = new JLabel("Ange tidsgr�ns i sekunder:");
	backgroundPanel.add(timeLimitLabel);
	timeLimitLabel.setLocation(x1, y);
	timeLimitLabel.setSize(timeLimitLabel.getPreferredSize());
	backgroundPanel.add(timeField);
	timeField.setLocation(x2, y);
	timeField.setSize(timeField.getPreferredSize());
	timeField.setText("" + lep.time);
	int xmax = x2 + timeField.getWidth();
	y += timeField.getHeight() + smallgap;
     
	JLabel musicPathLabel = new JLabel("Ange s�kv�g till musikstycke:");
	musicPathLabel.setLocation(x1, y);
	musicPathLabel.setSize(musicPathLabel.getPreferredSize());
	backgroundPanel.add(musicPathLabel);
	musicField.setLocation(x2, y);
	musicField.setSize(musicField.getPreferredSize());
	backgroundPanel.add(musicField);
	browseButton.setLocation(x2 + musicField.getWidth()+3, y);
	browseButton.setSize(browseButton.getPreferredSize());
	xmax = Math.max(xmax, x2 + musicField.getWidth() + browseButton.getWidth());
	backgroundPanel.add(browseButton);
	browseButton.addActionListener(this);
	musicField.setText(lep.tune);
	y += musicField.getHeight() + smallgap;
	
	JLabel selectSubjectsLabel = new JLabel("Ange vilka moment som banan ska behandla:");
	selectSubjectsLabel.setLocation(x1, y);
	selectSubjectsLabel.setSize(selectSubjectsLabel.getPreferredSize());
	backgroundPanel.add(selectSubjectsLabel);
	JLabel subjectsTipLabel = 
	    new JLabel("(H�ll muspekaren ovanf�r momentnamnet f�r en beskrivning)");
	Font labelFont = subjectsTipLabel.getFont();
	subjectsTipLabel.setFont(labelFont.deriveFont(labelFont.getSize2D() * 0.85f));
	subjectsTipLabel.setLocation(x1, y + selectSubjectsLabel.getHeight()+2);
	subjectsTipLabel.setSize(subjectsTipLabel.getPreferredSize());
	backgroundPanel.add(subjectsTipLabel);
	selectAll = new JCheckBox("Markera/avmarkera alla");
	selectAll.setLocation(x1 + 2*smallgap, y + 2*gap);
	selectAll.setSize(selectAll.getPreferredSize());
	selectAll.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent ae) {
		    boolean select = selectAll.isSelected();
		    for(int i = 0; i < subjects.length; i++) {
			subjects[i].setSelected(select);
			if(select) {
			    boolean noneSelected = true;
			    for(int j = 0; j < subjWeights[i].length; j++) {
				if(subjWeights[i][j].isSelected()) noneSelected = false;
			    }
			    if(noneSelected) {
				subjWeights[i][0].setSelected(true);
			    }
			}
		    }
		}
	    });
							  
	backgroundPanel.add(selectAll);

	JPanel checkBoxPanel = new JPanel();
	checkBoxPanel.setLayout(null);
	int ylocal = smallgap;
	String[] subj = LevelEditorPane.databaseSubjectsSorted;
	subjects = new JCheckBox[subj.length];
	subjWeights = new JRadioButton[subj.length][LevelEditorPane.NUMBER_OF_SUBJECT_WEIGHTS];
	int yBackup = ylocal;
	int localXmax = 0;
	    
	ActionListener subjListener = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    for(int i = 0; i < subjects.length; i++) {
			if(e.getSource() == subjects[i]) {
			    if(subjects[i].isSelected()) {
				boolean noneSelected = true;
				for(int j = 0; j < subjWeights[i].length; j++) {
				    if(subjWeights[i][j].isSelected()) noneSelected = false;
				}
				if(noneSelected) {
				    subjWeights[i][0].setSelected(true);
				}
			    }
			}
		    }
		}
	    };

	for(int i = 0; i < subj.length; i++) {
	    subjects[i] = new JCheckBox(subj[i]);
	    subjects[i].setToolTipText(Database.getInstance().getSubjectDescription(subj[i]));

	    subjects[i].addActionListener(subjListener);

	    checkBoxPanel.add(subjects[i]);
	    subjects[i].setLocation(smallgap, ylocal); 
	    subjects[i].setSize(subjects[i].getPreferredSize());
	    subjects[i].setSelected(lep.subjSelected[i] > 0);
		
	    localXmax = Math.max(subjects[i].getWidth()+smallgap, localXmax);
		
	    ylocal += subjects[i].getHeight()+smallgap;
	}
	int yStep = (ylocal - yBackup) / subj.length;
	int checkBoxPanelXMax = localXmax;
	for(int i = 0; i < subj.length; i++) {
	    int localx = localXmax + (int) (gap * 0.7);

	    JLabel weightLabel = new JLabel("vikt:");
	    checkBoxPanel.add(weightLabel);
	    weightLabel.setLocation(localx, yBackup+smallgap);
	    weightLabel.setSize(weightLabel.getPreferredSize());
	    localx += weightLabel.getWidth()+smallgap;
		
	    ButtonGroup bg = new ButtonGroup();


	    for(int j=0; j < subjWeights[i].length; j++) {
		subjWeights[i][j] = new JRadioButton(""+(j+1));
		    
		bg.add(subjWeights[i][j]);

		checkBoxPanel.add(subjWeights[i][j]); 
		subjWeights[i][j].setLocation(localx, yBackup);
		subjWeights[i][j].setSize(subjWeights[i][j].getPreferredSize());
		subjWeights[i][j].setSelected(lep.subjSelected[i] == j+1);

		localx += subjWeights[i][j].getWidth()+smallgap;
		checkBoxPanelXMax = Math.max(localx, checkBoxPanelXMax);
	    }
	    yBackup += yStep;
	}

	checkBoxPanel.setLocation(0, 0);
	checkBoxPanel.setSize(Math.max(xmax-x2-30, checkBoxPanelXMax-smallgap), ylocal);
	checkBoxPanel.setPreferredSize(checkBoxPanel.getSize());
	checkBoxPanel.setMinimumSize(checkBoxPanel.getSize());
	checkBoxPanel.setMaximumSize(checkBoxPanel.getSize());
	JScrollPane scrollPane = new JScrollPane(checkBoxPanel, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
						 JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	scrollPane.getVerticalScrollBar().setUnitIncrement(10);
						     
	backgroundPanel.add(scrollPane);
	scrollPane.setLocation(x2, y);
	int spheight = 120;
	int spwidth = checkBoxPanelXMax+(int)scrollPane.getVerticalScrollBar().getPreferredSize().getWidth();
	scrollPane.setSize(Math.max(xmax-x2-10, spwidth), spheight);
	y += spheight;
	y += smallgap;

	xmax = Math.max(xmax, scrollPane.getWidth()+x2);
	
	JLabel difficultyLevelLabel = new JLabel("Ange sv�righetsgrad p� fr�gorna:");
	difficultyLevelLabel.setLocation(x1, y);
	difficultyLevelLabel.setSize(difficultyLevelLabel.getPreferredSize());
	backgroundPanel.add(difficultyLevelLabel);

	String[] levels = Database.getInstance().getLevels();
	try {
	    levelSlider = new JSlider(Integer.parseInt(levels[0]), Integer.parseInt(levels[levels.length-1]));
	} catch(Exception e) {
	    levelSlider = new JSlider(1, 2);
	}
	if(lep.level != -1) levelSlider.setValue(lep.level);

	levelSlider.setSize(levelSlider.getPreferredSize());
	levelSlider.setMinorTickSpacing(1);
	levelSlider.setMajorTickSpacing(1);
	levelSlider.setPaintTicks(true);
	levelSlider.setSnapToTicks(true);

	JLabel easyLabel = new JLabel("L�tta");
	JLabel difficultLabel = new JLabel("Sv�ra");
	easyLabel.setLocation(x2, y);
	easyLabel.setSize(easyLabel.getPreferredSize());
	difficultLabel.setSize(difficultLabel.getPreferredSize());
	difficultLabel.setLocation(x2 + levelSlider.getWidth() - difficultLabel.getWidth(), y);
	backgroundPanel.add(easyLabel);
	backgroundPanel.add(difficultLabel);
	y += easyLabel.getHeight() + smallgap;
	    
	levelSlider.setLocation(x2, y);
	backgroundPanel.add(levelSlider);
	xmax = Math.max(xmax, x2+levelSlider.getWidth());
	y += levelSlider.getHeight() + 2*smallgap;

	JLabel[] l5_ = new JLabel[3];
	l5_[0] = new JLabel("% fr�gor");
	l5_[1] = new JLabel("% po�ng");
	l5_[2] = new JLabel("% extraliv");

	int xpos = x2;
	TextFieldListener tfl = new TextFieldListener(); 
	for(int i = 0; i < parts.length && i < l5_.length; i++) {
	    parts[i] = new JTextField(3);
	    parts[i].setSize(parts[i].getPreferredSize());
	    parts[i].setLocation(xpos, y);
	    parts[i].setText("" + lep.parts[i]);
	    parts[i].addCaretListener(tfl);
	    parts[i].addFocusListener(tfl);
	    xpos += parts[i].getWidth() + smallgap;
	    l5_[i].setSize(l5_[i].getPreferredSize());
	    l5_[i].setLocation(xpos, y);
	    xpos += l5_[i].getWidth() + 2*smallgap;
	    backgroundPanel.add(parts[i]);
	    backgroundPanel.add(l5_[i]);
	}
	xmax = Math.max(xmax, xpos);

	JLabel l5 = new JLabel("Ange f�rdelning av l�dor:");
	l5.setLocation(x1, y);
	l5.setSize(l5.getPreferredSize());
	backgroundPanel.add(l5);
	y += parts[0].getHeight() + smallgap;
    
	JLabel l6 = new JLabel("Ange hur stor andel av fr�gorna som m�ste");
	JLabel l7 = new JLabel("besvaras korrekt f�r att nyckeln skall erh�llas:");
	l6.setLocation(x1, y);
	l6.setSize(l6.getPreferredSize());
	backgroundPanel.add(l6);
	y += l6.getHeight();
	l7.setLocation(x1, y);
	l7.setSize(l7.getPreferredSize());
	backgroundPanel.add(l7);
	keyLimitField.setLocation(x2, y);
	keyLimitField.setSize(keyLimitField.getPreferredSize());
	keyLimitField.setText("" + lep.keyLimit);
	backgroundPanel.add(keyLimitField);
	JLabel l8 = new JLabel("%");
	l8.setLocation(x2 + keyLimitField.getWidth() + smallgap, y);
	l8.setSize(l8.getPreferredSize());
	backgroundPanel.add(l8);
	xmax = Math.max(xmax, x2 + keyLimitField.getWidth() + smallgap + l8.getWidth());
	y += keyLimitField.getHeight() + smallgap;
	
	JLabel forceLimitLabel = new JLabel("Force limit:");//"Ange hur m�nga fr�gor som kr�vs f�r att f� Kraften:");
	forceLimitLabel.setLocation(x1, y);
	forceLimitLabel.setSize(forceLimitLabel.getPreferredSize());
	backgroundPanel.add(forceLimitLabel);
	forceLimitField = new JTextField(3);
	forceLimitField.setText("" + lep.forceLimit);
	forceLimitField.setLocation(x2, y);
	forceLimitField.setSize(forceLimitField.getPreferredSize());
	backgroundPanel.add(forceLimitField);
	JLabel forceLimitTipLabel = new JLabel("(-1 = disable force)");
	forceLimitTipLabel.setLocation(forceLimitField.getLocation().x+forceLimitField.getSize().width+smallgap, y);
	forceLimitTipLabel.setSize(forceLimitTipLabel.getPreferredSize());
	backgroundPanel.add(forceLimitTipLabel);
	xmax = Math.max(xmax, x2 + forceLimitField.getWidth() + smallgap);	
	y += forceLimitField.getHeight() + smallgap;

	JLabel forceIntervalLabel = new JLabel("Force interval:");//"Ange hur m�nga fr�gor som d�refter kr�vs f�r att �terf� Kraften:");
	forceIntervalLabel.setLocation(x1, y);
	forceIntervalLabel.setSize(forceIntervalLabel.getPreferredSize());
	backgroundPanel.add(forceIntervalLabel);
	forceIntervalField = new JTextField(3);
	forceIntervalField.setText("" + lep.forceInterval);
	forceIntervalField.setLocation(x2, y);
	forceIntervalField.setSize(forceIntervalField.getPreferredSize());
	backgroundPanel.add(forceIntervalField);
	xmax = Math.max(xmax, x2 + forceIntervalField.getWidth() + smallgap);	
 	y += forceIntervalField.getHeight();

// 	y += forceIntervalField.getHeight() + 2*smallgap;
	
// 	JLabel backgroundImageLabel = new JLabel("Bakgrundsbild:");//"Ange hur m�nga fr�gor som d�refter kr�vs f�r att �terf� Kraften:");
// 	backgroundImageLabel.setLocation(x1, y);
// 	backgroundImageLabel.setSize(backgroundImageLabel.getPreferredSize());
// 	backgroundPanel.add(backgroundImageLabel);
// 	backgroundImageField = new JTextField(30);
// 	backgroundImageField.setText("" + lep.backgroundImagePath);
// 	backgroundImageField.setLocation(x2, y);
// 	backgroundImageField.setSize(backgroundImageField.getPreferredSize());
// 	backgroundPanel.add(backgroundImageField);
// 	xmax = Math.max(xmax, x2 + backgroundImageField.getWidth() + smallgap);	
// 	y += backgroundImageField.getHeight();

	JPanel buttonPanel = new JPanel();
	buttonPanel.add(okButton);
	buttonPanel.add(cancelButton);
	okButton.addActionListener(this);
	getRootPane().setDefaultButton(okButton);
	cancelButton.addActionListener(this);
	    
	Container cont = getContentPane();
	cont.setLayout(new BorderLayout());
	cont.add(backgroundPanel);
	cont.add(buttonPanel, BorderLayout.SOUTH);
	    

	setSize(xmax+2*smallgap, y + (int) okButton.getPreferredSize().getHeight() + 10*smallgap);
	setLocationRelativeTo(lep.parent);
	setResizable(false);
	setTitle("Banans egenskaper");
	setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
	if(e.getSource() == okButton) {
	    try {
		lep.time = Integer.parseInt(timeField.getText());
	    } catch(Exception err) {
		JOptionPane.showMessageDialog(lep.parent, "Felaktig tid angiven.", "Fel", 
					      JOptionPane.ERROR_MESSAGE);
		return;
	    }
	    lep.tune = musicField.getText();
	    try {
		int tmp0 = Integer.parseInt(parts[0].getText());
		int tmp1 = Integer.parseInt(parts[1].getText());
		int tmp2 = Integer.parseInt(parts[2].getText());
		if(tmp0 + tmp1 + tmp2 != 100) {
		    JOptionPane.showMessageDialog(lep.parent, "F�rdelningen summerar inte till\n100 procent.", "Fel", 
						  JOptionPane.ERROR_MESSAGE);
		    return;
		}
		else {
		    lep.parts[0] = tmp0;
		    lep.parts[1] = tmp1;
		    lep.parts[2] = tmp2;
		}
	    }
	    catch(Exception err) {
		JOptionPane.showMessageDialog(lep.parent, "Felaktig procentsiffra angiven.\n(Decimalv�rden �r inte till�tna.)", "Fel", 
					      JOptionPane.ERROR_MESSAGE);
		return;
	    }
	    for(int i = 0; i < lep.subjSelected.length; i++) {
		if(subjects[i].isSelected()) {
		    for(int j = 0; j < subjWeights[i].length; j++) {
			if(subjWeights[i][j].isSelected()) {
			    lep.subjSelected[i] = j+1;
			}
		    } 
		}
		else {
		    lep.subjSelected[i] = 0;
		}
	    }
	    lep.level = levelSlider.getValue();
	    try {
		lep.keyLimit = Integer.parseInt(keyLimitField.getText());
	    } catch(Exception err) {
		JOptionPane.showMessageDialog(lep.parent, "Felaktig procentsiffra angiven.\n(Decimalv�rden �r inte till�tna.)", "Fel", 
					      JOptionPane.ERROR_MESSAGE);
		return;
	    }
	    try {
		int i = Integer.parseInt(forceLimitField.getText());
		if(i < -1)
		    throw new RuntimeException();
		lep.forceLimit = i;
	    } catch(Exception err) {
		JOptionPane.showMessageDialog(lep.parent, "Felaktig Force limit angiven.", "Fel", 
					      JOptionPane.ERROR_MESSAGE);
		return;
	    }
	    try {
		int i = Integer.parseInt(forceIntervalField.getText());
		if(i < 0)
		    throw new RuntimeException();
		lep.forceInterval = i;
	    } catch(Exception err) {
		JOptionPane.showMessageDialog(lep.parent, "Felaktigt Force interval angivet.", "Fel", 
					      JOptionPane.ERROR_MESSAGE);
		return;
	    }

	    String backgroundImage = backgroundImageField.getText().trim();
	    if(!backgroundImage.equals("")) {
		lep.backgroundImagePath = backgroundImage;
	    }
	}			
	else if(e.getSource() == browseButton) {
	    if(fileChooser.showOpenDialog(lep.parent) == JFileChooser.APPROVE_OPTION) {
		String musicpath = Common.getCompatiblePath(fileChooser.getSelectedFile());
		String resourceDir = ResourceConstants.EXTERNAL_RESOURCEDIR + "/";
		int index;
		if(musicpath != null && (index = musicpath.indexOf(resourceDir)) != -1) {
		    musicpath = musicpath.substring(index+resourceDir.length());
		    musicField.setText(musicpath);
		}
		else {
		    JOptionPane.showMessageDialog(this, 
						  "Musikstycket ligger inte under spelets \"resource\"-katalog!\n" + 
						  "Om du har valt en fil som ligger p� en annan plats �n i \n" + 
						  "Matematikspelets \"resource\"-katalog m�ste du kopiera den dit f�rst.\n" + 
						  "Om s� inte �r fallet, kontakta utvecklarna.", 
						  "Fel", JOptionPane.ERROR_MESSAGE);
		}
		/*
		  String userdir = fileChooser.getName(new File(System.getProperty("user.dir"))).toLowerCase();
		  String abspath = fileChooser.getSelectedFile().getAbsolutePath().toLowerCase(); 
		  int index = abspath.indexOf(userdir);
		  if(index != -1) {
		  String finalpath = abspath.substring(index+userdir.length());
		  String fileSep = System.getProperty("file.separator");
		  if(finalpath.charAt(0) == fileSep.charAt(fileSep.length()-1))
		  finalpath = finalpath.substring(1);
		  musicField.setText(finalpath);
		  }
		  else musicField.setText(abspath);
		*/
	    }
	    return;
	}
	    
	// We are done..
	setVisible(false);
	dispose();
    }
	
	
    private class TextFieldListener implements CaretListener, FocusListener {

	int gotOne = -1;
	int gotTwo = -1;

	int current = -1;

	public void caretUpdate(CaretEvent e) {
	    if(gotOne == -1)
		gotOne = current;
	    else if(gotTwo == -1 && current != gotOne) {
		gotTwo = current;
	    }
	    process(e);
	} 

	public void focusGained(FocusEvent e) {
	    if(e.getSource() == parts[0])
		current = 0;
	    else if(e.getSource() == parts[1])
		current = 1;
	    else 
		current = 2;	
	}

	public void focusLost(FocusEvent e) {
	    if(gotOne == -1)
		gotOne = current;
	    else if(gotTwo == -1 && current != gotOne) {
		gotTwo = current;
	    }
	    process(e);
	}

	private void process(EventObject e) {
	    if(e.getSource() == parts[0])
		validate(0);
	    else if(e.getSource() == parts[1])
		validate(1);
	    else 
		validate(2);
	}

	private void validate(int i) {
	    int j = 0, k = 0;
	    if(gotOne != -1 && gotTwo != -1) {
		j = gotOne;
		k = gotTwo;
	    } else return;
	    if(j + k == 1) i = 2;
	    if(j + k == 2) i = 1;
	    if(j + k == 3) i = 0;
	    try {
		int left = 100-(Integer.parseInt(parts[j].getText())+Integer.parseInt(parts[k].getText()));
		parts[i].setText(""+left);
	    } catch(Exception e) {}
	}
    }
}
