//package prom03;
package mathgame.database;


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

import java.io.*;

public class H�mtaResultatDiagnos {
static Connection conn;


public static void main(String[] args) {
writeResultDiagnos("5789" ) ;
}



  public H�mtaResultatDiagnos() {
  }

  public static void writeResultDiagnos(String loginnr ) {



      try {

  //Ladda in databas driver
  Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
  //Connecta mot db
  conn = DriverManager.getConnection("jdbc:odbc:math-game");
  conn.setAutoCommit(true);
      // Print all warnings
      for( SQLWarning warn = conn.getWarnings(); warn != null; warn = warn.getNextWarning() )
         {
          System.out.println( "SQL Warning:" ) ;
          System.out.println( "State  : " + warn.getSQLState()  ) ;
          System.out.println( "Message: " + warn.getMessage()   ) ;
          System.out.println( "Error  : " + warn.getErrorCode() ) ;
         }

      // Get a statement from the connection
          int elevID=0;
          int fraga=0;
          String dnamn, datum, tid, resultat, fraganamn, moment;
          //String loginnr=textFieldLoginNr.getText();
          //String loginnr= "5789";
          String fornamn, efternamn, personnummer, filnamn, fragetext;
          int maxpo�ng, po�ng, sv�righetsgrad;


          PreparedStatement pstmtGElev;
          PreparedStatement pstmtGName;
          PreparedStatement pstmtDiagnos;
          PreparedStatement pstmtMax;
          PreparedStatement pstmtFraga;
          PreparedStatement pstmtFragaNamn;
          ResultSet rsElev;
          ResultSet rsName;
          ResultSet rsDiagnos;
          ResultSet rsMax;
          ResultSet rsFraga;
          ResultSet rsFragaNamn;


          //H�mta ElevID f�r eleven man vill se resultat f�r
          String queryGetElevid=" Select ElevID FROM Elev WHERE Personnummer=?";
          //H�mta personuppgifter f�r eleven man vill se resultat f�r
          String queryGetName="Select F�rnamn, Efternamn, Personnummer FROM PERSON WHERE Personnummer=?";
          //H�mta po�ng etc f�r de spel eleven spelat
          String queryGetDiagnos = "SELECT DiagnosFil, Po�ng, Datum from DiagnosResultat where ElevID=?";
          String queryGetSpelMaxp = "SELECT Maxpo�ng from Diagnos where DiagnosFil=?";

          String queryGetFraga="Select Fr�geID, Resultat, Fr�geText from Fr�gorDiagnos where DiagnosFil=? AND ElevID=?";
          String queryGetFragaNamn="Select Fr�ga, Sv�righetsgrad, MomentNamn from Fr�ga where Fr�geID=?";






          pstmtGElev= conn.prepareStatement(queryGetElevid);
          pstmtGName= conn.prepareStatement(queryGetName);
          pstmtDiagnos= conn.prepareStatement(queryGetDiagnos);
          pstmtMax= conn.prepareStatement(queryGetSpelMaxp);
          pstmtFraga= conn.prepareStatement(queryGetFraga);
          pstmtFragaNamn= conn.prepareStatement(queryGetFragaNamn);

          pstmtGElev.setString(1, loginnr);
          pstmtGName.setString(1, loginnr);

          rsElev=pstmtGElev.executeQuery();
          rsName=pstmtGName.executeQuery();//H�mtar namn


            while(rsElev.next()){
              elevID=rsElev.getInt(1);

            }

          pstmtDiagnos.setInt(1, elevID);
          rsDiagnos=pstmtDiagnos.executeQuery(); //Alla prov f�r den eleven
          //Skriver till filen 'filnamn'
          try {
          BufferedWriter out;
          String s1, s2, s3,s4, line;
          while(rsName.next()){
              fornamn=rsName.getString(1);
              efternamn=rsName.getString(2);
              personnummer=rsName.getString(3);
              filnamn="DiagnosResultat_f�r_"+personnummer+".txt";
              out = new BufferedWriter(new FileWriter(new File(filnamn)));

                String s = "F�rnamn: " + fornamn.trim() +"\t\t" +"Efteramn: " + efternamn+"\t"+"Loginnr: " + personnummer.trim();
                out.write(s, 0, s.length());
                out.newLine();


              while(rsDiagnos.next()){
                dnamn=rsDiagnos.getString(1);

                po�ng=rsDiagnos.getInt(2);

                datum=rsDiagnos.getString(3);



                s1 = "DiagnosNamn"  +"\t\t" + "Po�ng/Maxpo�ng" +"\t\t" + "Datum";
                s1=s1.trim();
                line="-----------------------------------------------------------";
                out.write(s1, 0, s1.length());
                out.newLine();
                ;
                out.write(line, 0, line.length());
                out.newLine();




                    if(dnamn.length()< 10){
                    dnamn=dnamn+"    ";
                    }


                    pstmtMax.setString(1, dnamn);
                    rsMax=pstmtMax.executeQuery();
                  while(rsMax.next()){
                    maxpo�ng=rsMax.getInt(1);
                    if(dnamn.length()< 10){
                    dnamn=dnamn+"    ";
                    }


                   s2=dnamn +"\t\t" + po�ng+"/"+maxpo�ng+"\t\t\t"+datum.substring(0,10);
                   out.write(s2, 0, s2.length());
                   out.newLine();
                    pstmtFraga.setString(1, dnamn);
                    pstmtFraga.setInt(2, elevID);
                    rsFraga=pstmtFraga.executeQuery();
                      while(rsFraga.next()){
                        fraga=rsFraga.getInt(1);
                        resultat=rsFraga.getString(2);
                        fragetext=rsFraga.getString(3);

                        pstmtFragaNamn.setInt(1, fraga);
                        rsFragaNamn=pstmtFragaNamn.executeQuery();

                          while(rsFragaNamn.next()){
                            fraganamn=rsFragaNamn.getString(1);
                            s3="\t"+"Fr�gans fil: " + fraganamn + "      " + fragetext;
                            out.write(s3, 0, s3.length());
                            out.newLine();
                            sv�righetsgrad=rsFragaNamn.getInt(2);
                            moment=rsFragaNamn.getString(3);
                            if(moment.length()< 6){
                              moment=moment+"   ";
                            }
                            s4="\t"+"Sv�righetsgrad: " + sv�righetsgrad +"\t"+"Fr�gans moment: " + moment+"\t"+"Resultat: " + resultat;
                            out.write(s4, 0, s4.length());
                            out.newLine();


                            }
                            rsFragaNamn.close();
                        }
                        rsFraga.close();
                    }
                rsMax.close();

              }
              rsDiagnos.close();
              out.close();


            }

          }catch(Exception e){
          System.out.println(e);
          System.out.println("Fel i filskrivning!");
          }




          rsElev.close();
          rsName.close();
          conn.close() ;


  }


  catch( SQLException se )
     {
      System.out.println( "SQL Exception:" ) ;

      // Loop through the SQL Exceptions
      while( se != null )
         {
          System.out.println( "State  : " + se.getSQLState()  ) ;
          System.out.println( "Message: " + se.getMessage()   ) ;
          System.out.println( "Error  : " + se.getErrorCode() ) ;

          se = se.getNextException() ;
         }
     }
  catch( Exception e )
     {
      System.out.println( e ) ;




      }
    }




}

