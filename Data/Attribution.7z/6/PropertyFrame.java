package mathgame.editor;

import mathgame.common.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;

public class PropertyFrame extends JInternalFrame implements ActionListener {

    private JTextField questionField = new JTextField(20);
    private JTextField[] answerField;
    private JTextField correctAnswerField = new JTextField(5);
    
    private JButton okButton = new JButton("OK");
    private JButton cancelButton = new JButton("Avbryt");

    private LevelEditorPane user;
    public SpriteBoxData object;

    public PropertyFrame(LevelEditorPane user, SpriteData iobject, String title){
	super(title, false, true);
	this.user = user;
	
	if(!(iobject instanceof SpriteBoxData)){
	    System.err.println("Box: " +iobject +" not instance of SpriteBoxData.java!");
	    System.exit(1);
	}
	this.object = (SpriteBoxData) iobject;
	okButton.addActionListener(this);
	cancelButton.addActionListener(this);

	JPanel buttonPanel = new JPanel();
	buttonPanel.add(okButton);
	buttonPanel.add(cancelButton);

	answerField = new JTextField[3];

	Container cont = getContentPane();

	JPanel[] panels = new JPanel[answerField.length+3];
	for(int i=0; i<panels.length; i++){
	    panels[i] = new JPanel();
	    panels[i].setLayout(new BorderLayout());
	}

	JLabel question = new JLabel("Fr�ga:");
	
	panels[0].add(question, BorderLayout.NORTH);
	panels[0].add(questionField);
	
	for(int i=1; i<answerField.length+1; i++){
	    answerField[i-1] = new JTextField(20);
	    JLabel answer = new JLabel("Svar #" +i +":");
	    panels[i].add(answer, BorderLayout.NORTH);
	    panels[i].add(answerField[i-1]);
	}

	JLabel correct = new JLabel("R�tt svarsalternativ #:");
	panels[panels.length-2].add(correct, BorderLayout.NORTH);
	//correctAnswerField.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 50));
	panels[panels.length-2].add(correctAnswerField);
	panels[panels.length-1].add(buttonPanel);
	
	cont.setLayout(new GridLayout(0,1));
	for(int i=0; i<panels.length; i++)
	    cont.add(panels[i]);

	((JComponent) cont).setBorder(BorderFactory.createEmptyBorder(5, 5, 0, 5));

	if(object.question != null)
	    questionField.setText(object.question);
	if(object.answers != null){
	    for(int i=0; i<object.answers.length && i<answerField.length; i++){
		if(object.answers[i] != null){
		    answerField[i].setText(object.answers[i]);
		}
	    }
	}
	if(object.correctAnswer >= 0){
	    correctAnswerField.setText(""+(object.correctAnswer+1));
	}

	pack();
    }

    public void fitInPane(){
	Rectangle visRect = user.getVisibleRect();
	Rectangle bounds = getBounds();	
	if(bounds.x < visRect.x) bounds.x = visRect.x;
	if(bounds.y < visRect.y) bounds.y = visRect.y;
	if(bounds.x + bounds.width > visRect.x + visRect.width)
	    bounds.x = visRect.x + visRect.width - bounds.width;
	if(bounds.y + bounds.height > visRect.y + visRect.height)
	    bounds.y = visRect.y + visRect.height - bounds.height;
	setBounds(bounds);
    }

    public void actionPerformed(ActionEvent e){
	if(e.getSource() == okButton){
	    object.question = questionField.getText();
	    object.answers = new String[answerField.length];
	    for(int i=0; i<object.answers.length && i<answerField.length; i++){
		object.answers[i] = answerField[i].getText();
	    }
	    try {
		int ca = Integer.parseInt(correctAnswerField.getText());
		if(ca >= 1 && ca <= 3)
		    object.correctAnswer = ca-1;
	    } catch(Exception err){}
	}
	toBack();
	user.removePropertyFrame();
    }

}
