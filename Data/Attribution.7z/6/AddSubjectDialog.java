/*-
 * Copyright (C) 2005 Lars Helander, Erik Larsson
 * 
 * All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

package mathgame.question.reader;

import mathgame.common.*;
import java.io.File;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class AddSubjectDialog extends JDialog {
    private JPanel backgroundPanel;
    private JLabel nameLabel;
    private JLabel descriptionLabel;
    private JLabel helpFileLabel;
    private JTextField nameTextField;
    private JTextField descriptionTextField;
    private JTextField helpFileTextField;
    private JButton browseHelpFileButton;
    private JButton addButton;
    private JButton closeButton;

    public AddSubjectDialog(Frame owner, boolean modal) {
	super(owner, "L�gg till moment", modal);
	backgroundPanel = new JPanel();
	nameLabel = new JLabel("Namn:");
	descriptionLabel = new JLabel("Beskrivning:");
	helpFileLabel = new JLabel("Hj�lptext:");
	nameTextField = new JTextField(30);
	descriptionTextField = new JTextField(30);
	helpFileTextField = new JTextField(30);
	browseHelpFileButton = new JButton("Bl�ddra...");
	addButton = new JButton("L�gg till");
	closeButton = new JButton("St�ng");
	    
	backgroundPanel.setLayout(new GridBagLayout());
	GridBagConstraints c = new GridBagConstraints();
	c.insets = new Insets(5, 5, 5, 5);

	c.gridx = 0;
	c.gridy = 0;
	backgroundPanel.add(nameLabel, c);
	    
	c.gridx = 1;
	c.gridy = 0;
	backgroundPanel.add(nameTextField, c);
	    
	c.gridx = 0;
	c.gridy = 1;
	backgroundPanel.add(descriptionLabel, c);
	    
	c.gridx = 1;
	c.gridy = 1;
	backgroundPanel.add(descriptionTextField, c);
	    
	c.gridx = 0;
	c.gridy = 2;
	backgroundPanel.add(helpFileLabel, c);
	    
	c.gridx = 1;
	c.gridy = 2;
	helpFileTextField.setEditable(false);
	backgroundPanel.add(helpFileTextField, c);
	    
	c.gridx = 2;
	c.gridy = 2;
	browseHelpFileButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    browseHelpFileButtonActionPerformed(e);
		}
	    });
	backgroundPanel.add(browseHelpFileButton, c);
	    
	c.gridx = 0;
	c.gridy = 3;
	addButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    addButtonActionPerformed(e);
		}
	    });
	backgroundPanel.add(addButton, c);

	c.gridx = 2;
	c.gridy = 3;
	closeButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    closeButtonActionPerformed(e);
		}
	    });
	backgroundPanel.add(closeButton, c);

	getContentPane().add(backgroundPanel);
	pack();
	setLocationRelativeTo(null);
    }

    public void browseHelpFileButtonActionPerformed(ActionEvent e) {
	JFileChooser fileChooser = new JFileChooser(Common.HELPTEXT_DIR);
	fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
	fileChooser.setMultiSelectionEnabled(false);
	SimpleFileFilter fileFilter = new SimpleFileFilter();
	fileFilter.addExtension("pdf");
	fileFilter.setDescription("Portable Document Format (*.pdf)");
	fileChooser.addChoosableFileFilter(fileFilter);
	if(fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
	    File selectedFile = fileChooser.getSelectedFile();
	    String compatiblePath = Common.getCompatiblePathRelative(selectedFile, Common.HELPTEXT_DIR);
	    if(compatiblePath != null)
		helpFileTextField.setText(compatiblePath);
	    else
		JOptionPane.showMessageDialog(this, "Filen m�ste ligga n�gonstans under matematikspelets hj�lptext-katalog (" + Common.HELPTEXT_DIR + ").", "Fel", JOptionPane.ERROR_MESSAGE);
	}
    }
    public void addButtonActionPerformed(ActionEvent e) {
	String subjectName = nameTextField.getText().trim();
	String description = descriptionTextField.getText().trim();
	String helpTextRelativeFilename = helpFileTextField.getText().trim();
	if(subjectName.equals("")) {
	    JOptionPane.showMessageDialog(this, "F�ltet \"Namn\" f�r inte vara tomt!", "Fel", JOptionPane.ERROR_MESSAGE);
	    return;
	}
	    
	String message = null;
	if(description.equals("") && helpTextRelativeFilename.equals(""))
	    message = "Du har inte angett varken beskrivning eller referens till hj�lpfil, �r du s�ker p� att du vill forts�tta?";
	else if(description.equals(""))
	    message = "Du har inte angett en beskrivning till momentet, �r du s�ker p� att du vill forts�tta?";
	else if(helpTextRelativeFilename.equals(""))
	    message = "Du har inte angett n�gon referens till en hj�lpfil, �r du s�ker p� att du vill forts�tta?";
	    
	boolean proceed = false;
	if(message != null) {
	    if(JOptionPane.showConfirmDialog(this, message, "Varning", JOptionPane.YES_NO_OPTION,
					     JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION)
		proceed = true;
	}
	else
	    proceed = true;

	if(proceed) {
	    Database.getInstance().addSubject(subjectName, description, helpTextRelativeFilename);
	    JOptionPane.showMessageDialog(this, "Momentet lades till!", "Information", JOptionPane.INFORMATION_MESSAGE);
	}
    }
    public void closeButtonActionPerformed(ActionEvent e) {
	setVisible(false);
    }
}
