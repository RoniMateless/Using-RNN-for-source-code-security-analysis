/*-
 * Copyright (C) 2004 Delby Arrospide, Niloofar Ghassemino, Lars Helander, Taghrid Hodroj,
 *                    Magnus Johansson, Caroline Koch, Erik Larsson, Helena Nilsson
 * 
 * All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

package mathgame.login;

import mathgame.common.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class TeacherPanel extends MenuPanel {
    
    private JPanel editorsTab;
    private JPanel gameTab;
    private JPanel toolsTab;
    private JPanel userInfoTab;
    private JPanel subjectManagerTab;
    private JPanel userManagementTab;
    private String username;
    private MainWindow currentWindow;

    public TeacherPanel(MainWindow currentWindow, String username) {
	this.currentWindow = currentWindow;
	this.username = username;
        editorsTab = new SuperuserMainTab();
	gameTab = new StudentMainTab(this, Common.DEBUG_USER);
	toolsTab = new ToolsTab();
	userManagementTab = new UserManagementTab(currentWindow);
	subjectManagerTab = new SubjectManager();
        userInfoTab = new UserInfoTab(currentWindow, username);
	
	addTab("Editorer", editorsTab);
	addTab("Spel", gameTab);
	addTab("Verktyg", toolsTab);
	addTab("Anv\u00e4ndarhantering", userManagementTab);
	addTab("Momenthanteraren", subjectManagerTab);
	addTab("Mitt anv\u00e4ndarkonto", userInfoTab);
    }

    public MainWindow getCurrentWindow() {
	return currentWindow;
    }
}
