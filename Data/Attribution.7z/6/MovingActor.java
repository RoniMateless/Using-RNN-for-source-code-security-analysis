package mathgame.game;
import mathgame.common.*;

public abstract class MovingActor extends Actor {
    
    public Game game;
    
    //Declaration of direction constants
    /*public final short LEFT = 1, UP = 2;
      public final short RIGHT = 3, DOWN = 4;*/

    //Declaration of state constants
    /*public final short STANDING = 0;
    public final short WALKING = 1;
    public final short RUNNING = 2;
    public final short JUMPING = 3;
    public final short CLIMBING = 4;
    public final short WALKING_OUT_A_DOOR = 5;*/
    
    /*protected short currentState = WALKING;
    protected short previousState;
    protected short direction;*/

    public double speedX = 0.0;
    public double speedY = 0.0;
    
    protected int groundLevel = -1;
    protected LevelObject standsOn;
    protected LevelObject downLimiting, upLimiting, leftLimiting, rightLimiting;
    protected int downLimit = 1000000, upLimit = -1, leftLimit = -1, rightLimit = 1000000;

    public void attemptMove(){
	updateActor();
    }
    
    public void updateActor() {
	updateSpeed();
	updatePosition();
	this.hitArea.x = x;
	this.hitArea.y = y;
    }
    
    protected void updateSpeed() {
	if(speedY > 0)
	    speedY += 0.7;
    }

    protected void updatePosition2(){
	int newx = (int) (x+speedX);
	int newy = (int) (y+speedY);

	if(game.ctb.fastCheckForCollision(this, newx, newy)){
		    
	    speedX = 0;
	    speedY = 0;
	}
    }

    protected void updatePosition() {
	final boolean debug = false; //�ndra till true f�r debug-meddelanden i konsol
	if(speedX == 0 && speedY == 0) return;
	
	int newx = (int)(x + speedX);
	int newy = (int)(y + speedY);
	
	Collision[] c;
	if(debug)
	    c = game.ctb.checkForCollisionsDebug(this, newx, newy);
	else
	    c = game.ctb.checkForCollisions(this, newx, newy);
	/*if(c[0].getTarget() != null)
	  System.out.println("We had a collision");*/
	if(c != null && c.length > 0) {
	    for(int i = 0; i < c.length; i++) {
		LevelObject current = c[i].getTarget();
		if(current == null) break;

		if(c[i].getType() == Collision.UP) {
		    if(debug) System.out.println("c nr: (" + i + ") " + current + ":Collision.UP"); //DEBUG
		    newy = current.y + current.height;
		    speedY = 0.7;
		    upLimit = newy;
		    upLimiting = current;
		}
		else if(c[i].getType() == Collision.DOWN) {
		    if(debug) System.out.println("c nr: (" + i + ") " + current + ":Collision.DOWN"); //DEBUG
		    newy = current.y - height;
		    speedY = 0.0;//7;
		    downLimit = newy;
		    downLimiting = current;
		}
		else if(c[i].getType() == Collision.LEFT) {
		    if(debug) System.out.println("c nr: (" + i + ") " + current + ":Collision.LEFT"); //DEBUG
		    newx = current.x + current.width;
		    speedX = -speedX;
		    leftLimit = newx;
		    leftLimiting = current;
		}
		else if(c[i].getType() == Collision.RIGHT) {
		    if(debug) System.out.println("c nr: (" + i + ") " + current + ":Collision.RIGHT"); //DEBUG
		    newx = current.x - width;
		    speedX = -speedX;
		    rightLimit = newx;
		    rightLimiting = current;
		}
	    }
	}
	
	if(newy == downLimit) {
	    if(downLimiting != null && !inHorizontalLineWith(downLimiting, newx)) {
		downLimit = 10000000;
		downLimiting = null;
		speedY = 0.7;
	    }
	}
	
	
	synchronized(this) {
	    x = newx;
	    y = newy;
	}

    }

    public boolean inHorizontalLineWith(LevelObject lo, int newx) {
	if(lo == null) return false;
	if(((newx + width) > lo.x) &&
	   (newx < (lo.x + lo.width))) {
	    //System.out.println((y+height) + " " + lo.y);
	    return true;
	}
	else
	    return false;
    }
    
    public boolean inVerticalLineWith(LevelObject lo) {
	if(lo == null) return false;
	if(((y + height) >= lo.y) &&
	   (y <= (lo.y + lo.height))) {
	    //System.out.println((y+height) + " " + lo.y);
	    return true;
	}
	else
	    return false;
	
    }

}
