/*-
 * Copyright (C) 2005 Erik Larsson
 * 
 * All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

package mathgame.game.popuppane;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.FontMetrics;
import java.awt.Rectangle;
import java.awt.Transparency;
import java.awt.image.BufferedImage;
import java.awt.geom.Rectangle2D;
import java.awt.font.FontRenderContext;
import java.awt.font.TextLayout;

public class TextItem extends DisplayItem {
    private static final BufferedImage testImage = new BufferedImage(1, 1, BufferedImage.TYPE_INT_RGB);
//     private final Dimension dimensions;
//     private final Dimension outDimensions;
    private final BufferedImage buffer;
    private final ImageItem internalItem;

    public TextItem(int answerIndex, String text, int maxWidth, GraphicsConfiguration gc) {
	this(answerIndex, text, maxWidth, gc, true);
    }
    public TextItem(String text, int maxWidth, GraphicsConfiguration gc) {
	this(null, text, maxWidth, gc, true);
    }
	
    private TextItem(Integer answerIndex, String text, int maxWidth, GraphicsConfiguration gc, boolean dummy) {
	//Graphics testg = testImage.getGraphics();
	Graphics2D tempg = testImage.createGraphics();
	tempg.setFont(STANDARD_FONT);
// 	FontMetrics fm = tempg.getFontMetrics();
// 	String prefix = null;
// 	Rectangle2D prefixBounds = null;
// 	if(answerIndex != null) {
// 	    prefix = answerIndex + ".";
// 	    prefixBounds = fm.getStringBounds(prefix, tempg);
// 	}
// 	Rectangle2D textBounds = fm.getStringBounds(text, tempg);

	FormattedString fs = format(text, maxWidth, 0, 0, tempg);
	tempg.dispose();

	//System.out.println("creating buffer... w: " + maxWidth + "h: " + fs.getHeight());
	buffer = gc.createCompatibleImage(maxWidth, 
					  fs.getHeight(), 
					  Transparency.BITMASK);
	System.out.println("buffer created w:" + buffer.getWidth() + " h:" + buffer.getHeight());
// 	buffer = gc.createCompatibleImage((int)textBounds.getWidth(), 
// 					  fm.getMaxAscent()+fm.getMaxDescent(), 
// 					  Transparency.BITMASK);
// 	    buffer = new BufferedImage((int)textBounds.getWidth(), (int)textBounds.getHeight(), BufferedImage.TYPE_INT_RGB);
	Graphics2D bufferg = buffer.createGraphics();
	bufferg.setColor(java.awt.Color.BLACK);
	bufferg.fillRect(0, 0, buffer.getWidth(), buffer.getHeight());
 	bufferg.setFont(STANDARD_FONT);
	bufferg.setColor(TEXT_COLOR);
// 	bufferg.drawString(text, 0, fm.getMaxAscent());
	fs.drawString(bufferg, 0, 0);
// 	dimensions = new Dimension(buffer.getWidth(), buffer.getHeight());
// 	outDimensions = new Dimension(dimensions);
	bufferg.dispose();
	
	if(answerIndex != null)
	    internalItem = new ImageItem(answerIndex.intValue(), buffer, gc);
	else
	    internalItem = new ImageItem(buffer);
    }

    public void paint(Graphics g, int x, int y) {
	//g.drawImage(buffer, x, y, null);
	internalItem.paint(g, x, y);
    }
	
    public Dimension getSize() {
// 	outDimensions.setSize(dimensions);
// 	return outDimensions;
	return internalItem.getSize();
    }
    public void setHighlighted(boolean b) {}

    // ATT G�RA: Antag tokens[i].width > dimensions.width!!
    protected static FormattedString format(String us, int layoutWidth, int leftGap, int rightGap, Graphics2D gg) {
	if(containsSpecialChars(us))
	    return formatSpecialChars(us, layoutWidth, leftGap, rightGap, gg);

	FontMetrics metrics = gg.getFontMetrics();
	String[] tokens = us.split("\\s");
	String fs = "";
	String currentLine = "";
	int numberOfLines = 1;
	int ascent = metrics.getMaxAscent();//-1;
// 	TextLayout tl = null;
	int lineHeight = metrics.getMaxAscent()+metrics.getMaxDescent();//0;//test.getBounds().getBounds().height;
	
	/* This loop iterates through all the tokens and makes them fit within the specified width
	   (currently represented by dimensions.width) by splitting the original string, us, into
	   the required number of lines. Width is constant, height is variable. */
	for(int i = 0; i < tokens.length; i++) {
// 	    String oldLine = currentLine;
	    currentLine += tokens[i];
// 	    tl = new TextLayout(currentLine, STANDARD_FONT, frc);
// 	    Rectangle tlBounds = tl.getBounds().getBounds();
	    Rectangle stringBounds = metrics.getStringBounds(currentLine, gg).getBounds();
	    if(stringBounds.width + leftGap + rightGap <= layoutWidth) {
		fs += tokens[i] + " ";
		currentLine += " ";
	    }
	    else {
// 		TextLayout otl = new TextLayout(oldLine, STANDARD_FONT, frc);
// 		if(ascent == -1)
// 		    ascent = (int)otl.getAscent();
// 		int currentLineHeight = otl.getBounds().getBounds().height;
// 		if(currentLineHeight > lineHeight) {
// 		    System.err.println("New line height: " + currentLineHeight);
// 		    lineHeight = currentLineHeight;
// 		}
		
		fs += "\n" + tokens[i] + " ";
		currentLine = tokens[i] + " ";
		numberOfLines++;
	    }
	}
// 	if(tl != null) {
// 	    if(ascent == -1)
// 		ascent = (int)tl.getAscent();
	    
// 	    int currentLineHeight = tl.getBounds().getBounds().height;
// 	    if(currentLineHeight > lineHeight) {
// 		System.err.println("New line height: " + currentLineHeight);
// 		lineHeight = currentLineHeight;
// 	    }
// 	}
	/* This TextLayout, test, is created with the string "fj" as argument to represent the maximum
	   ascent and descent of normal western characters (f for the ascent, j for descent). This
	   could be done more cleanly by getting a FontMetrics object for a certain font and calling
	   getMaxAscent() and getMaxDescent() for that specific font. (There are no rules in the font
	   world preventing that for a specific font F may be ascending higher than f, so using a
	   FontMetrics object is safer.) However, I'm not changing anything now, as it works ok. */
// 	TextLayout test = new TextLayout("fj", STANDARD_FONT, frc);
	//int ascent = (int)test.getAscent();
	final int lineSpacing = 5; //...representing the number of pixels to add between the lines (y-wise) as padding to make the text layout look less "packed".
	int totalHeight = (lineHeight+lineSpacing)*numberOfLines; // Shouldn't the number of line spaces be numberOfLines-1?
	return new FormattedString(fs, lineHeight, ascent, totalHeight);
    }
    
    /** Checks if the string <code>s</code> contains special characters indicating that
	special formatting is required. (For example "\#" should be formatted as a fraction
	with numerator and denominator.) */
    private static boolean containsSpecialChars(String s) {
	for(int i = 0; i < s.length(); i++) {
	    // \# = fraction (division)
	    if(s.charAt(i) == '\\' && i+1 < s.length() && s.charAt(i+1) == '#')
		return true;
	    // * = multiplication
	    else if(s.charAt(i) == '*')
		return true;
	    // != = inequality
	    else if(s.charAt(i) == '!' && i+1 < s.length() && s.charAt(i+1) == '=')
		return true;
	}
	return false;
    }

    /** Does special formatting that <code>format(String, int, int, FontRenderContext)</code>
	does not do. For example, when encountering the special code "\#" the string should
	be formatted as a fraction with numerator and denominator. */
    private static FormattedString formatSpecialChars(String s, int layoutWidth, int leftGap, int rightGap, Graphics2D gg) {
// 	Graphics2D transparentSurfaceG = (Graphics2D) transparentSurface.getGraphics();
// 	transparentSurfaceG.setFont(STANDARD_FONT);
// 	FontRenderContext frc = transparentSurfaceG.getFontRenderContext();	
// 	TextLayout test = new TextLayout("fj", STANDARD_FONT, frc);
// 	int height = test.getBounds().getBounds().height;	
	//FontRenderContext frc = gg.getFontRenderContext();
	FontMetrics metrics = gg.getFontMetrics();
	int lineHeight = metrics.getMaxAscent()+metrics.getMaxDescent();

	FormattedMathematicalString res = new FormattedMathematicalString(layoutWidth-leftGap-rightGap, 
									  0, lineHeight);
	/* StringBuilder is more efficient than StringBuffer and should be used in thread
	   safe environments. */
	StringBuilder acc = new StringBuilder();
	String firstLine = null;

	for(int i = 0; i < s.length(); i++) {
	    if(s.charAt(i) == '\\' && i+1 < s.length() &&
	       s.charAt(i+1) == '#') {
		int j;
		for(j = i; j >= 0; j--) {
		    if(s.charAt(j) == '(') break;
		    acc.deleteCharAt(acc.length()-1);
		}
		
		// Add the prefix string
		if(acc.length() > 0) {
		    addString(acc.toString(), res, STANDARD_FONT, gg);
		    if(firstLine == null)
			firstLine = acc.toString();
		    acc.setLength(0);
		}

		for(j++; j < s.length(); j++) {
		    if(s.charAt(j) == '\\') {
			j = j+2;
			break;
		    }
		    acc.append(s.charAt(j));
		} 
		String nominator = acc.toString(); 
		//TextLayout tl1 = new TextLayout(nominator, STANDARD_FONT, frc);
		//Rectangle nominatorBounds = tl2.getBounds().getBounds();
		Rectangle nominatorBounds = metrics.getStringBounds(nominator, gg).getBounds();
		acc.setLength(0);
		for( ; j < s.length(); j++) {
		    if(s.charAt(j) == ')') break;
		    acc.append(s.charAt(j));
		}
		String denominator = acc.toString();
// 		TextLayout tl2 = new TextLayout(denominator, STANDARD_FONT, frc);
// 		Rectangle denominatorBounds = tl2.getBounds().getBounds();
		Rectangle denominatorBounds = metrics.getStringBounds(denominator, gg).getBounds();
		acc.setLength(0);
		res.addFraction(nominator, denominator, nominatorBounds.width,
				denominatorBounds.width);
		i = j;
	    }
	    else if(s.charAt(i) == '!' && i+1 < s.length() &&
		    s.charAt(i+1) == '=') {

		if(acc.length() > 0) {
		    addString(acc.toString(), res, STANDARD_FONT, gg);
		    if(firstLine == null)
			firstLine = acc.toString();
		    acc.setLength(0);
		}

// 		Rectangle equalsBounds = new TextLayout("=", STANDARD_FONT, frc).getBounds().getBounds();
		Rectangle equalsBounds = metrics.getStringBounds("=", gg).getBounds();
		res.addNotEquals(equalsBounds.width);

		i++;
	    }
	    else if(s.charAt(i) == '*') {
		if(acc.length() > 0) {
		    addString(acc.toString(), res, STANDARD_FONT, gg);
		    if(firstLine == null)
			firstLine = acc.toString();
		    acc.setLength(0);
		}

		//Rectangle timesBounds = new TextLayout("*", STANDARD_FONT, frc).getBounds().getBounds();
		Rectangle timesBounds = metrics.getStringBounds("*", gg).getBounds();
		res.addTimesOperator(timesBounds.width);

	    }
	    else {
		acc.append(s.charAt(i));
	    }
	}
	if(acc.length() > 0) {
	    if(firstLine == null)
		firstLine = acc.toString();
	    addString(acc.toString(), res, STANDARD_FONT, gg);
	}
	res.computeTotalHeight();
	res.setFirstLineAscent(metrics.getMaxAscent());//(int)new TextLayout(firstLine, STANDARD_FONT, frc).getAscent());
	
	return res;
    }

    private static void addString(String s, FormattedMathematicalString res, Font font, Graphics2D gg) {
	//FontRenderContext frc = gg.getFontRenderContext();
	FontMetrics metrics = gg.getFontMetrics();
	int count = 0;
	for(int i = 0; i < s.length(); i++) {
	    if(s.charAt(i) == '\n') { 
		if(count > 0) {
		    if(i - count >= 0) {		
			String toAdd = s.substring(i - count, i);
// 			Rectangle stringBounds = new TextLayout(toAdd, font, frc).getBounds().getBounds();
			Rectangle stringBounds = metrics.getStringBounds(toAdd, gg).getBounds();
			res.addString(toAdd, stringBounds.width); 
		    }
		    count = 0;
		}
		res.addNewline();
	    }
	    else {
		count++;
	    }
	}
	if(count > 0 && s.length()-count >= 0) {
	    String toAdd = s.substring(s.length() - count, s.length());
// 	    Rectangle stringBounds = new TextLayout(toAdd, font, frc).getBounds().getBounds();
	    Rectangle stringBounds = metrics.getStringBounds(toAdd, gg).getBounds();
	    res.addString(toAdd, stringBounds.width); 
	}
	
	/*
	while(s.charAt(0) == '\n') {
	    res.addNewline();
	    if(s.length() > 1) {
		s = s.substring(1);
	    }
	    else {
		return;
	    }
	}
	int nl = 0;
	for(int i=s.length()-1; i >= 0; i--) {
	    if(s.charAt(i) == '\n') nl++;
	    else break;
	}
	String[] toAdd = s.split("\n");
	for(int k=0; k < toAdd.length; k++) {
	    if(toAdd[k].length() > 0) {
		TextLayout tl = new TextLayout(toAdd[k], font, frc);
		res.addString(toAdd[k], tl.getBounds().getBounds().width);
		if(k != toAdd.length-1) {
		    res.addNewline();
		}
	    }
	}
	for(int i=0; i < nl; i++) {
	    res.addNewline();
	}
	*/
    }
}
