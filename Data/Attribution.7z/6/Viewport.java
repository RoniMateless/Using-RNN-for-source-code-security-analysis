package mathgame.game;

import java.awt.Rectangle;

public class Viewport {

    public int x;
    public int y;
    public int width;
    public int height;
    private Player toFollow;
    private Rectangle bounds;

    private int maxWidth;
    private int maxHeight;

    public Viewport(Player player, int startX, int startY, int width, int height, int maxWidth, int maxHeight){
	toFollow = player;
	x = startX;
	y = startY;
	this.width = width;
	this.height = height;
	this.maxWidth = maxWidth;
	this.maxHeight = maxHeight;
	this.bounds = new Rectangle(x, y, width, height);
    }

    public void scroll(){
	//	x = toFollow.committedx + (toFollow.width / 2) - (width / 2);
	// y = toFollow.committedy + (toFollow.height / 2) - (height / 2);
	x = toFollow.committedx + (toFollow.width / 2) - (width / 2);
	y = toFollow.committedy + (toFollow.height / 2) - (height / 2);

	if(x < 0) x = 0;
	if(y < 0) y = 0;
	if(x + width > maxWidth) x = maxWidth - width;
	if(y + height > maxHeight) y = maxHeight - height;
	//System.out.println("y = " +y);
    }

    public Rectangle getBounds(){
	bounds.x = x;
	bounds.y = y;
	bounds.width = width;
	bounds.height = height;
	return bounds;
    }

}
