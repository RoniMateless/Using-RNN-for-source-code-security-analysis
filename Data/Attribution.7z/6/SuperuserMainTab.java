/*-
 * Copyright (C) 2004 Delby Arrospide, Niloofar Ghassemino, Lars Helander, Taghrid Hodroj,
 *                    Magnus Johansson, Caroline Koch, Erik Larsson, Helena Nilsson
 * 
 * All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

package mathgame.login;

import mathgame.common.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class SuperuserMainTab extends JPanel implements RootTab {
    
//     private boolean diagnosticTestCreatorLoading = false;
    private boolean questionEditorLoading = false;
    private JPanel startEditorPanel;
    private JPanel startQuestionEditorPanel;
    //private JPanel startQuestionReaderPanel;
//     private GeneralDescriptionButtonPanel startDiagnosticTestCreatorPanel;
    private mathgame.editor.Editor editor = null;
    private mathgame.question.editor.QuestionEditor questionEditor = null;
    //private mathgame.diagnosis.Diagnos diagnosticTestCreator = null; //Lousy program... skipit.
    public SuperuserMainTab() {
        startEditorPanel = new StartEditorPanel(this);
        startQuestionEditorPanel = new StartQuestionEditorPanel(this);
	//startQuestionReaderPanel = new JPanel();
	//startDiagnosticTestCreatorPanel = new GeneralDescriptionButtonPanel(this, "Provskaparen", "H�r kan du skapa diagnostiska prov och l�gga dem i databasen.", "Starta provskaparen");
// 	startDiagnosticTestCreatorPanel.addButtonListener(new ActionListener() {
// 		public void actionPerformed(ActionEvent evt) {
// 		    startDiagnosticTestActionPerformed(evt);
// 		}
// 	    });
	
        setLayout(null);

        add(startEditorPanel);
        add(startQuestionEditorPanel);
        //add(startQuestionReaderPanel);
	//add(startDiagnosticTestCreatorPanel);
	
	startEditorPanel.setSize(startEditorPanel.getPreferredSize());
	startQuestionEditorPanel.setSize(startQuestionEditorPanel.getPreferredSize());
// 	startQuestionReaderPanel.setSize(0, 0);
//  	startDiagnosticTestCreatorPanel.setSize(startDiagnosticTestCreatorPanel.getPreferredSize());

	startEditorPanel.setLocation(LEFT_INSETS, TOP_INSETS);
	startQuestionEditorPanel.setLocation(startEditorPanel.getLocation().x,
					     startEditorPanel.getLocation().y+startEditorPanel.getSize().height);
// 	startQuestionReaderPanel.setLocation(startQuestionEditorPanel.getLocation().x,
// 					     startQuestionEditorPanel.getLocation().y+startQuestionEditorPanel.getSize().height);
// 	startDiagnosticTestCreatorPanel.setLocation(startQuestionEditorPanel.getLocation().x,
// 						    startQuestionEditorPanel.getLocation().y+startQuestionEditorPanel.getSize().height);
	
	Component limitingX = startEditorPanel;
	Component limitingY = startQuestionEditorPanel;
	int minSizeX = LEFT_INSETS+getInsets().left+limitingX.getSize().width+RIGHT_INSETS+getInsets().right;
	int minSizeY = TOP_INSETS+getInsets().top+limitingY.getLocation().y+limitingY.getSize().height+BOTTOM_INSETS+getInsets().bottom;
	Dimension preferredSize = new Dimension(getPreferredSize().width+minSizeX, getPreferredSize().height+minSizeY);
	setPreferredSize(preferredSize);
	setMinimumSize(preferredSize);
    }
    
    private void startEditorButtonActionPerformed(ActionEvent evt) {
	if(editor == null || editor.hasExited()) {
	    // The Editor must be launched in a separate thread
	    // for the ProgressBar to show properly.
	    // (The Editor cannot be launched from the AWT Event Thread,
	    // because then the repaints are never considered!)
	    editor = null; // for the gc
	    editor = new mathgame.editor.Editor(false);
	    
	    (new SwingWorker() {
		    public Object construct() {
			editor.initialize();
			return null;
		    }
		}).start();
	}
	// Problem that needs to be fixed: You can now launch many Editor windows
	// before the first one has become visible and editor != null...
	// Possible solution: Use boolean flags... (I leave this to YOU.. ;)) //Lars
	// Yeah yeah, we prata much english h�r don't vi? Flaggan hasExited i Editor
	// talar om ifall editor har avslutats. S�tts vid windowClosing. Borde duga.
	// Var tvungen att se till att Editor-objektet skapades i event-tr�den, men
	// initierades i separata tr�den. �ndrade lite i Editor.java d�.
	// //Erik (08:30 050504, tired and grumpy)
	else JOptionPane.showMessageDialog(this, "Du har redan ett editorf�nster �ppet", "Fel", JOptionPane.ERROR_MESSAGE);
    }
    private void startQuestionEditorButtonActionPerformed(ActionEvent evt) {
	if(!questionEditorLoading && (questionEditor == null || !questionEditor.isVisible())) {
	    questionEditorLoading = true;
	    questionEditor = null; //An attempt to make the garbage collector realize that the old object is garbage.
	    (new SwingWorker() {
		    public Object construct() {
			questionEditor = new mathgame.question.editor.QuestionEditor();
			questionEditorLoading = false;
			return false;
		    }
		}).start();
	}
	else if(questionEditorLoading)
	    JOptionPane.showMessageDialog(this, "Det fr�geskaparf�nster du redan har �ppnat h�ller p� och laddar. Var god v�nta...", "Fel", JOptionPane.ERROR_MESSAGE);
	else JOptionPane.showMessageDialog(this, "Du har redan ett fr�geskapar-f�nster �ppet", "Fel", JOptionPane.ERROR_MESSAGE);
    }

//     private void startDiagnosticTestActionPerformed(ActionEvent evt) {
// 	if(!diagnosticTestCreatorLoading && (diagnosticTestCreator == null || !diagnosticTestCreator.isVisible())) {
// 	    diagnosticTestCreatorLoading = true;
// 	    diagnosticTestCreator = null; //An attempt to make the garbage collector realize that the old object is garbage.
// 	    (new SwingWorker() {
// 		    public Object construct() {
// 			diagnosticTestCreator = new mathgame.diagnosis.Diagnos(SuperuserMainTab.this);
// 			diagnosticTestCreatorLoading = false;
// 			return null;
// 		    }
// 		}).start();
// 	}
// 	else if(diagnosticTestCreatorLoading)
// 	    JOptionPane.showMessageDialog(this, "Det provskaparf�nster du redan har �ppnat h�ller p� och laddar. Var god v�nta...", "Fel", JOptionPane.ERROR_MESSAGE);
// 	else JOptionPane.showMessageDialog(this, "Du har redan ett provskapar-f�nster �ppet", "Fel", JOptionPane.ERROR_MESSAGE);
//     }

    private class StartEditorPanel extends JPanel {
	public static final int LEFT_INSETS = 5;
	public static final int RIGHT_INSETS = 5;
	public static final int TOP_INSETS = 0;
	public static final int BOTTOM_INSETS = 0;
	private FixedWidthTextArea editorDescriptionArea;
	private JButton startEditorButton;
	private SuperuserMainTab creator;
	
	public StartEditorPanel(SuperuserMainTab creator) {
	    this.creator = creator;
	    int width = SuperuserMainTab.PREFERRED_WIDTH - SuperuserMainTab.LEFT_INSETS - SuperuserMainTab.RIGHT_INSETS;

	    setLayout(null);
	    setBorder(new TitledBorder("Banredigeraren"));	    

	    editorDescriptionArea = new FixedWidthTextArea(width-getInsets().left-getInsets().right-LEFT_INSETS-RIGHT_INSETS);
	    startEditorButton = new JButton();
	    
	    editorDescriptionArea.setText("Banredigeringsverktyget �r sj�lva nyckeln till att bygga upp Matematikspelet. H�r kan du bygga banor, provk�ra dem och l�nka ihop dem med andra banor.");
	    editorDescriptionArea.setOpaque(false);
	    add(editorDescriptionArea);
	    editorDescriptionArea.setSize(editorDescriptionArea.getPreferredSize());
	    editorDescriptionArea.setLocation(getInsets().left+LEFT_INSETS, getInsets().top+TOP_INSETS);

	    startEditorButton.setText("Starta banredigeringsverktyget");
	    startEditorButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent evt) {
			startEditorButtonActionPerformed(evt);
		    }
		});
	    add(startEditorButton);
	    startEditorButton.setSize(startEditorButton.getPreferredSize());
	    startEditorButton.setLocation(editorDescriptionArea.getLocation().x,
					  editorDescriptionArea.getLocation().y+editorDescriptionArea.getSize().height+10);

	    setPreferredSize(new Dimension(width, startEditorButton.getLocation().y+startEditorButton.getSize().height+BOTTOM_INSETS+getInsets().bottom));
	}
    }

    private class StartQuestionEditorPanel extends JPanel {
	public static final int LEFT_INSETS = 5;
	public static final int RIGHT_INSETS = 5;
	public static final int TOP_INSETS = 0;
	public static final int BOTTOM_INSETS = 0;
	private FixedWidthTextArea questionEditorDescriptionArea;
	private JButton startQuestionEditorButton;
	
	public StartQuestionEditorPanel(SuperuserMainTab creator) {
	    int width = SuperuserMainTab.PREFERRED_WIDTH - SuperuserMainTab.LEFT_INSETS - SuperuserMainTab.RIGHT_INSETS;
	    
	    setLayout(null);
	    setBorder(new TitledBorder("Fr\u00e5geskaparen"));

	    questionEditorDescriptionArea = new FixedWidthTextArea(width-getInsets().left-getInsets().right-LEFT_INSETS-RIGHT_INSETS);
	    startQuestionEditorButton = new JButton();

	    questionEditorDescriptionArea.setText("Fr�geskaparen anv�nder du f�r att skapa fr�gor som skall integreras i Matematikspelet.");
	    questionEditorDescriptionArea.setOpaque(false);
	    add(questionEditorDescriptionArea);
	    questionEditorDescriptionArea.setSize(questionEditorDescriptionArea.getPreferredSize());
	    questionEditorDescriptionArea.setLocation(getInsets().left+LEFT_INSETS, getInsets().top+TOP_INSETS);

	    startQuestionEditorButton.setText("Starta fr�geskaparen");
	    startQuestionEditorButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent evt) {
			startQuestionEditorButtonActionPerformed(evt);
		    }
		});
	    add(startQuestionEditorButton);
	    startQuestionEditorButton.setSize(startQuestionEditorButton.getPreferredSize());
	    startQuestionEditorButton.setLocation(questionEditorDescriptionArea.getLocation().x,
						  (questionEditorDescriptionArea.getLocation().y+
						   questionEditorDescriptionArea.getSize().height+10));
	    
	    setPreferredSize(new Dimension(width, startQuestionEditorButton.getLocation().y+startQuestionEditorButton.getSize().height+BOTTOM_INSETS+getInsets().bottom));
	}
    }
}
