/*-
 * Copyright (C) 2005 Lars Helander, Erik Larsson
 * 
 * All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

package mathgame.question.reader;

import mathgame.common.*;
import java.util.Random;
import java.io.OutputStream;
import java.io.DataOutputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.BufferedReader;
import java.io.IOException;

public abstract class QuestionSourceFileDecoder {
    
    /**
     * Decodes the question source file from <code>in</code>, creates all question
     * data, and adds it to <code>mgsWriter</code>.
     * @param in the reader from which the source data can be read
     * @param sourceFilename the filename of the file containing the source data
     * @param subjectName the name of the subject to which this question belongs
     * @param level the difficulty level of the question (1-5)
     * @param mgsWriter an <code>MGSv1Writer</code> set up to output to the mgs file
     *                  where the questions will be stored
     * @return the number of questions decoded.
     * @throws IOException if there is some problem with the source data
     */
    public abstract int decode(BufferedReader in, String sourceFilename, String subjectName, 
			       int level, MGSv1Writer mgsWriter) throws IOException;
    
    protected static void commitQuestion(String subjectName, String sourceFilename, int number,
					 MGSv1Writer mgsWriter, String[] answers, String question,
					 int correctAnswer, String momentName, int questionLevel) throws IOException {
	String identifier = removeSwedishLetters(subjectName.toLowerCase()+"["+sourceFilename.toLowerCase()+"]_"+number);
	String contentType = "mgq";
	ByteArrayOutputStream baos = new ByteArrayOutputStream();
	saveQuestion(baos, answers, question, correctAnswer);
	MGSv1Frame currentFrame = new MGSv1Frame(baos.toByteArray(), 0, identifier, contentType);
	mgsWriter.addFrame(currentFrame);
    }

    protected static void saveQuestion(OutputStream os, String[] answers, String question,
				       int correctAnswer) throws IOException {
	DataOutputStream out = new DataOutputStream(new BufferedOutputStream(os));

	out.writeInt(QuestionToolbox.HEADER);
	out.writeInt(QuestionToolbox.TEXT);
	out.writeInt(answers.length);
	out.writeInt(correctAnswer);
	out.writeInt(QuestionToolbox.FOOTER);

	char[] questionData = question.toCharArray();
	out.writeInt(questionData.length);
	for(int i = 0; i < questionData.length; i++)
	    out.writeChar(questionData[i]);
	
	for(int i = 0; i < answers.length; i++){
	    char[] answerData = answers[i].toCharArray();
	    out.writeInt(answerData.length);
	    for(int j = 0; j < answerData.length; j++)
		out.writeChar(answerData[j]);
	}
	
	out.flush();
    }
    
    protected static int doCommonFormatting(BufferedReader in, String sName, String first, String second, String sourceFilename, String subjectName, int level, MGSv1Writer mgsWriter) throws IOException {
	int numQuestions = 0;

	for(int line = 0; in.ready(); line++) {
	    String[] answers = new String[2];
	    String[] tokens = in.readLine().split(" & ");
	    
	    if(tokens.length >= 3) {
		String[] t1 = tokens[0].split("\\s");
		String[] t2 = tokens[1].split("\\s");
		int correctAnswer = tokens[2].equalsIgnoreCase("t") ? 0 : 1;
		
		if(t1.length > 0 && t2.length > 0) {
		    
		    StringBuffer ans = new StringBuffer();
		    String[] noms; //Franska?
		    if(t1.length >= 2) {
			ans.append(t1[0]);
			noms = t1[1].split("/");
		    }
		    else {
			noms = t1[0].split("/");
		    }
		    if(noms.length == 2) {
			ans.append("("+noms[0]+"\\#"+noms[1]+") "+first +" ");
		    }
		    else {
			ans.append(noms[0] +" "+first +" ");
		    }
		    if(t2.length >= 2) {
			ans.append(t2[0]);
			noms = t2[1].split("/");
		    }
		    else {
			noms = t2[0].split("/");
		    }
		    if(noms.length == 2) {
			ans.append("("+noms[0]+"\\#"+noms[1]+")");
		    }
		    else {
			ans.append(noms[0]);
		    }
		    answers[0] = ans.toString();
		    answers[1] = ans.toString().replace(first, second);

		    commitQuestion(sName.toLowerCase(), sourceFilename, line, mgsWriter,
				   answers, sName, correctAnswer, subjectName,
				   level);
		    numQuestions++;
		}
	    }
	} 
	return numQuestions;
// 	JOptionPane.showMessageDialog(this, numQuestions + " fr�gor har skapats och lagts\ntill i databasen!", 
// 				      "Information", JOptionPane.INFORMATION_MESSAGE);
    }
    protected static int randomizeAnswers(String[] answers, int correctAnswer) {
	Random rnd = new Random();
	for(int i=answers.length; i > 1; i--) {
	    int randomPos = rnd.nextInt(i);
	    String tmp = answers[i-1];
	    answers[i-1] = answers[randomPos];
	    answers[randomPos] = tmp;
	    if(correctAnswer == randomPos) {
		correctAnswer = i-1;
	    }
	    else if(correctAnswer == i-1) {
		correctAnswer = randomPos;
	    }
	}
	return correctAnswer;
    }

    protected static String createFraction(String uf) {
	String[] tokens = uf.split("\\s");
	String[] noms;

	switch(tokens.length) {
	case 1:
	    noms = tokens[0].split("/");
	    if(noms.length == 2) {
		return "(" + noms[0] + "\\#" + noms[1] + ")";
	    }
	    else {
		return tokens[0];
	    }
	case 2: 
	    noms = tokens[1].split("/");
	    if(noms.length == 2) {
		return tokens[0] + "(" + noms[0] + "\\#" + noms[1] +")";
	    }
	    else if(noms.length == 1) {
		return tokens[0] + noms[0];
	    }
	    break;
	default:
	    break;
	}
	
	return "";
    } 

    private static String removeSwedishLetters(String s) {
	s = s.replace('�', 'a');
	s = s.replace('�', 'a');
	s = s.replace('�', 'o');
	s = s.replace('�', 'A');
	s = s.replace('�', 'A');
	s = s.replace('�', 'O');
	return s;
    }

    /***** DECODER CLASSES ******/
    
    public static class Heltalsproblem extends QuestionSourceFileDecoder {
	public int decode(BufferedReader in, String sourceFilename, String subjectName, int level, MGSv1Writer mgsWriter) throws IOException {
	    int numQuestions = 0;

	    for(int line=0; in.ready(); line++) {
		String[] answers = new String[11];
		String[] tokens = in.readLine().split("\\s");

		if(tokens.length >= 3) {
		    String[] noms = tokens[0].split("/");
		    int correctAnswer = Integer.parseInt(tokens[2]);

		    if(noms.length == 2) {
			for(int i=0; i < answers.length; i++) {
			    answers[i] = "("+noms[0]+"\\#"+noms[1]+") = "+i;
			}
			commitQuestion("heltalsproblem", sourceFilename, line, mgsWriter,
				       answers, "Heltalsproblem", correctAnswer, subjectName, 
				       level);
			numQuestions++;
		    }
		}
	    } 
	
	    return numQuestions;
	}
    }
    
    public static class Rakneproblem extends QuestionSourceFileDecoder {
	public int decode(BufferedReader in, String sourceFilename, String subjectName, int level, MGSv1Writer mgsWriter) throws IOException {
	    int numQuestions = 0;

	    for(int line = 0; in.ready(); ++line) {
		String[] tokens = in.readLine().split(" & ");
		String[] answers = new String[tokens.length-3];
		String question = "R�kneproblem\n\n";
	    
		if(tokens.length >= 6) {
		
		    question += createFraction(tokens[0]) + " " + tokens[2] + " " + 
			createFraction(tokens[1]) + " = ?";
		
		    for(int i=3; i < tokens.length; i++) {
			answers[i-3] = createFraction(tokens[i]);
		    }

		    int correctAnswer = randomizeAnswers(answers, 0);

		    commitQuestion("rakneproblem", sourceFilename, line, mgsWriter,
				   answers, question, correctAnswer, subjectName,
				   level);
		    numQuestions++;
		}
	    }

	    return numQuestions;
	    // 	JOptionPane.showMessageDialog(this, numQuestions +" fr�gor har skapats och lagts\ntill i databasen!", 
	    // 				      "Information", JOptionPane.INFORMATION_MESSAGE);
	
	}
    }
   
    public static class Likhetsproblem extends QuestionSourceFileDecoder {
	public int decode(BufferedReader in, String sourceFilename, String subjectName, int level, MGSv1Writer mgsWriter) throws IOException {
	    return doCommonFormatting(in, "Likhetsproblem", "=", "!=", sourceFilename, subjectName, level, mgsWriter);
	}
    }
    public static class Jamforelseproblem extends QuestionSourceFileDecoder {
	public int decode(BufferedReader in, String sourceFilename, String subjectName, int level, MGSv1Writer mgsWriter) throws IOException {
	    return doCommonFormatting(in, "Storleksproblem", "<", ">", sourceFilename, subjectName, level, mgsWriter);
	}
    }

    public static class Brakapproximering extends QuestionSourceFileDecoder {
	/* exempel1:
	 * 1/4 & 0.32 & 0.25 & 0.1 & 2 =>
	 *  Br�kapproximering
	 *  1. 1/4 = 0.32
	 *  2. 1/4 = 0.25 <- r�tt svar
	 *  3. 1/4 = 0.1
	 *
	 * exempel2:
	 * 1/3 & 0.33 & 0.15 & 0.7 & 1 =>
	 *  Br�kapproximering
	 *  1. 1/4 ~ 0.33 <- r�tt svar
	 *  2. 1/4 ~ 0.15
	 *  3. 1/4 ~ 0.7
	 */

	public int decode(BufferedReader in, String sourceFilename, String subjectName, int level, MGSv1Writer mgsWriter) throws IOException {
	    int numQuestions = 0;

	    for(int line = 0; in.ready(); line++) {
		String[] tokens = in.readLine().split(" & ");
	   	    
		if(tokens.length >= 4) {
		    String[] answers = new String[tokens.length-2];
		    String question = "Br�kapproximering";
		    int correctAnswer = Integer.parseInt(tokens[tokens.length-1]) - 1;
		
		    double fractionValue = evalFraction(tokens[0]); 
		    double correctAnswerValue = evalAnswer(tokens[correctAnswer+1]);
		    String fraction = createFraction(tokens[0]);
		    String equals = fractionValue == correctAnswerValue ? "=" : "\u2248";
		
		    for(int i = 0; i < answers.length; i++)
			answers[i] = fraction +" " +equals +" " +tokens[i+1];
		
		    commitQuestion("brakapprox", sourceFilename, line, mgsWriter,
				   answers, question, correctAnswer, subjectName,
				   level);
		    numQuestions++;
		}
	    }
	    return numQuestions;
	}
	protected static double evalFraction(String uf) {
	    String[] tokens = uf.split("\\s");
	    String[] noms;

	    switch(tokens.length) {
	    case 1:
		noms = tokens[0].split("/");
		if(noms.length == 2) {
		    return Double.parseDouble(noms[0]) / Double.parseDouble(noms[1]);
		}
		else {
		    return Double.parseDouble(tokens[0]);
		}
	    case 2: 
		noms = tokens[1].split("/");
		if(noms.length == 2) {
		    return Double.parseDouble(tokens[0]) + 
			Double.parseDouble(noms[0]) / Double.parseDouble(noms[1]);
		}
		else if(noms.length == 1) {
		    return Double.parseDouble(tokens[0]) + Double.parseDouble(noms[0]);
		}
		break;
	    default:
		break;
	    }
	
	    return 0;
	}

	protected static double evalAnswer(String uf) {
	    uf = uf.replace(",", ".");

	    if(uf.contains("%")) {
		return Double.parseDouble(uf.replaceAll("%", " ").trim()) / 100.0;
	    }
	    else {
		return Double.parseDouble(uf);
	    }
	}

    }

    public static class DecimalOchProcentrakning extends QuestionSourceFileDecoder {
	/*
	 * x & y & op & alt1 & ... & altn
	 *
	 * => "Vad �r x op y?"
	 *
	 * R�tt svar �r alt1.
	 */ 
	public int decode(BufferedReader in, String sourceFilename, String subjectName, int level, MGSv1Writer mgsWriter) throws IOException {
	    int numQuestions = 0;

	    for(int line = 0; in.ready(); ++line) {
		String[] tokens = in.readLine().split("&");
	   	    
		if(tokens.length >= 5) {
		    String[] answers = new String[tokens.length-3];
		    String question = "Vad �r\n\n" + tokens[0].trim() +
			" " + tokens[2].trim() + " " + tokens[1].trim() +" ?";
				
		    for(int i = 0; i < answers.length; i++) {
			answers[i] = tokens[i+3].trim();
		    }

		    int correctAnswer = randomizeAnswers(answers, 0);

		    commitQuestion("decprocrakning", sourceFilename, line, mgsWriter,
				   answers, question, correctAnswer, subjectName, level);
		    numQuestions++;
		}
	    }
	    return numQuestions;
	}
    }
}
