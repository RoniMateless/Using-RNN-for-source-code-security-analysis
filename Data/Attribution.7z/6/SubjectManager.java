/*-
 * Copyright (C) 2004 Delby Arrospide, Niloofar Ghassemino, Lars Helander, Taghrid Hodroj,
 *                    Magnus Johansson, Caroline Koch, Erik Larsson, Helena Nilsson
 * 
 * All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

package mathgame.login;

import mathgame.common.Database;
import mathgame.common.Common;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;


/**
 * This class has functionality for editing the properties of subjects
 * (moment) in the database.
 */ 
public class SubjectManager extends JPanel implements ActionListener {
    
    public static final int LEFT_INSETS = 10;
    public static final int RIGHT_INSETS = 10;
    public static final int TOP_INSETS = 5;
    public static final int BOTTOM_INSETS = 5;
    public static final int PREFERRED_WIDTH = 510;

    private static final int COLUMNS = 3;
  
    public static boolean LAUNCHED_STANDALONE = false;
  
    protected static final String[] columnToolTips = 
    { null,
      "Dubbelklicka i en cell f�r att �ndra dess v�rde...",
      "Dubbelklicka i en cell f�r att �ndra dess v�rde..." };

    private DefaultTableModel tableModel;
    private JTable table;

    private Vector<String> removedSubjects = new Vector<String>();
    private Hashtable<String, String> addedSubjects = 
	new Hashtable<String, String>();
    private Hashtable<String, String> changedSubjects = 
	new Hashtable<String, String>();

    private JPanel mainPanel;
    private JButton addButton = new JButton("L�gg till moment");
    private JButton removeButton = new JButton("Ta bort markerade moment");
    private JButton changeButton = new JButton("Byt namn p� moment");
    private JButton saveButton = new JButton("Spara till databasen");
    private JButton loadButton = new JButton("Uppdatera fr�n databasen");

    public SubjectManager() {
	setLayout(null);
	mainPanel = new JPanel();
	mainPanel.setLayout(new BorderLayout());
	mainPanel.setBorder(new TitledBorder("Momenthanteraren"));

	String[] subjects = getSubjects();
	String[] descriptions = getDescriptions(subjects);
	String[] helptexts = getHelpTexts(subjects);

	Vector<String> colNames = new Vector<String>(COLUMNS);
	colNames.add("Moment");
	colNames.add("Beskrivning");
	colNames.add("Hj�lptext");

	Vector<Vector<String>> rowData = new Vector<Vector<String>>(subjects.length);
	for(int i=0; i < subjects.length; i++) {
	    Vector<String> row = new Vector<String>(colNames.size());
	    row.add(subjects[i]);
	    row.add(descriptions[i]);
	    row.add(helptexts[i]);
	    rowData.add(row);
	}

	tableModel = new DefaultTableModel(rowData, colNames) {
		public boolean isCellEditable(int row, int col) {
		    return col > 0;
		}
	    };
	table = new JTable(tableModel) {
		//Implement table header tool tips.
		protected JTableHeader createDefaultTableHeader() {
		    return new JTableHeader(columnModel) {
			    public String getToolTipText(MouseEvent e) {
				String tip = null;
				java.awt.Point p = e.getPoint();
				int index = columnModel.getColumnIndexAtX(p.x);
				int realIndex = 
				    columnModel.getColumn(index).getModelIndex();
				return columnToolTips[realIndex];
			    }
			};
		}
	    };

	JScrollPane scrollPane = new JScrollPane(table);

	addButton.addActionListener(this);
	removeButton.addActionListener(this);
	changeButton.addActionListener(this);
	saveButton.addActionListener(this);
	loadButton.addActionListener(this);

	JPanel buttonPanel = new JPanel();
	buttonPanel.add(addButton);
	buttonPanel.add(removeButton);
	buttonPanel.add(changeButton);
	buttonPanel.add(saveButton);
	buttonPanel.add(loadButton);

	scrollPane.setPreferredSize(new Dimension(0, 0));
	buttonPanel.setPreferredSize(new Dimension(0, buttonPanel.getPreferredSize().height+addButton.getPreferredSize().height));
	//buttonPanel.setPreferredSize(new Dimension(0, buttonPanel.getPreferredSize().height));

	
	mainPanel.add(scrollPane, BorderLayout.CENTER);
	mainPanel.add(buttonPanel, BorderLayout.SOUTH);

	add(mainPanel);
	mainPanel.setSize(PREFERRED_WIDTH-LEFT_INSETS-RIGHT_INSETS-getInsets().left-getInsets().right,
			  350);
	mainPanel.setLocation(LEFT_INSETS + getInsets().left,
			      TOP_INSETS + getInsets().top);
    }


    public void actionPerformed(ActionEvent e) {
	if(e.getSource() == addButton) {
	    addRow();
	}
	else if(e.getSource() == removeButton) {
	    removeRows();
	}
	else if(e.getSource() == changeButton) {
	    changeSubjectNames();
	}
	else if(e.getSource() == saveButton) {
	    saveToDatabase();
	}
	else if(e.getSource() == loadButton) {
	    loadFromDatabase();
	}
    }

    public void addRow() {
	Vector<String> row = new Vector<String>(COLUMNS);
	String subject = JOptionPane.showInputDialog(this, "Skriv in momentnamnet", 
						     "Nytt moment", 
						     JOptionPane.QUESTION_MESSAGE);
	if(subject != null && subject.length() > 0) {
	    row.add(subject);
	    row.add("Ingen beskrivning finns �n!");
	    row.add("hj�lptexter/default.pdf");
	    addedSubjects.put(subject, subject);
	    tableModel.addRow(row);
	}
    }

    public void removeRows() {
	int[] rows = table.getSelectedRows(); 
	StringBuffer subjects = new StringBuffer(rows.length * 4);
	for(int i=0; i < rows.length; i++) {
	    subjects.append(tableModel.getValueAt(rows[i], 0) + "\n");
	}
	if(JOptionPane.YES_OPTION == 
	   JOptionPane.
	   showConfirmDialog(this, "�r du s�ker p� att du vill\n" +
			     "ta bort f�ljande moment?\n\n" + 
			     subjects.toString() +
			     "\n(T�nk p� att en borttagning av ett moment tar\n" +
			     "bort alla fr�gor som �r relaterade till momentet!)\n", 
			     "Bekr�fta borttagning",
			     JOptionPane.YES_NO_CANCEL_OPTION)) {

	    int row;
	    while((row = table.getSelectedRow()) != -1) {
		removedSubjects.add((String) tableModel.getValueAt(row, 0));
		tableModel.removeRow(row);
	    }
	}
    }

    public void changeSubjectNames() {
	int[] rows = table.getSelectedRows(); 
	for(int i=0; i < rows.length; i++) {
	    String oldName = (String) tableModel.getValueAt(rows[i], 0);
	    String newName = 
		JOptionPane.showInputDialog(this, "Skriv in ett nytt namn f�r \"" +
					    oldName +"\"", 
					    "�ndring av momentnamn", 
					    JOptionPane.QUESTION_MESSAGE);
	    if(newName == null) {
		break;
	    }
	    // else...
	    if(newName.length() > 0) {
		tableModel.setValueAt(newName, rows[i], 0);
		changedSubjects.put(newName, oldName);
	    }
	}
    }

    public void saveToDatabase() {
	// First remove from database...
	for(String subject : removedSubjects) {
	    Database.getInstance().removeSubject(subject);
	}

	// Then add and update to database
	Vector rowData = tableModel.getDataVector();
	for(int i=0; i < rowData.size(); i++) {
	    Vector row = (Vector) rowData.elementAt(i);
	    String subject = (String) row.elementAt(0);
	    String description = (String) row.elementAt(1);
	    String helptext = (String) row.elementAt(2);

	    if(changedSubjects.containsKey(subject)) {
		Database.getInstance().changeSubjectName(changedSubjects.get(subject), subject);
	    }
	    else if(addedSubjects.containsKey(subject)) {
		Database.getInstance().addSubject(subject);
	    }
	    Database.getInstance().setSubjectDescription(subject, description);
	    Database.getInstance().setHelpTextFile(subject, helptext);
	}

	JOptionPane.
	    showMessageDialog(this, "Dina �ndringar har nu blivit sparade i databasen!",
			      "Kvitto", JOptionPane.INFORMATION_MESSAGE);

	addedSubjects.clear();
	removedSubjects.clear();
	changedSubjects.clear();
    }

    public void loadFromDatabase() {
	String[] subjects = getSubjects();
	String[] descriptions = getDescriptions(subjects);
	String[] helptexts = getHelpTexts(subjects);

	Vector<String> colNames = new Vector<String>(COLUMNS);
	colNames.add("Moment");
	colNames.add("Beskrivning");
	colNames.add("Hj�lptext");

	Vector<Vector<String>> rowData = new Vector<Vector<String>>(subjects.length);
	for(int i=0; i < subjects.length; i++) {
	    Vector<String> row = new Vector<String>(colNames.size());
	    row.add(subjects[i]);
	    row.add(descriptions[i]);
	    row.add(helptexts[i]);
	    rowData.add(row);
	}

	tableModel.setDataVector(rowData, colNames);

	addedSubjects.clear();
	removedSubjects.clear();
	changedSubjects.clear();
    }

    private String[] getSubjects() {
	String[] subjects = Database.getInstance().getSubjects();
	ArrayList<String> v = new ArrayList<String>(subjects.length);
	for(int i=0; i < subjects.length; i++) v.add(subjects[i]);
	Collections.sort(v);
	subjects = v.toArray(subjects);
	return subjects;
    }

    private String[] getDescriptions(String[] subjects) {
	String[] result = new String[subjects.length];
	for(int i=0; i < result.length; i++) {
	    result[i] = Database.getInstance().getSubjectDescription(subjects[i]);
	}
	return result;
    }

    private String[] getHelpTexts(String[] subjects) {
	String[] result = new String[subjects.length];
	for(int i=0; i < result.length; i++) {
	    result[i] = Database.getInstance().getHelpTextFile(subjects[i]);
	}
	return result;
    }

}
