/*-
 * Copyright (C) 2004 Delby Arrospide, Niloofar Ghassemino, Lars Helander, Taghrid Hodroj,
 *                    Magnus Johansson, Caroline Koch, Erik Larsson, Helena Nilsson
 * 
 * All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

package mathgame.login;

import mathgame.common.*;
import java.net.URL;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class EditUserInfoDialog extends JDialog {

    private Frame parent;
    //private EditUserInfoPanel editUserInfoPanel;
    private ChangeUserInfoPanel changeUserInfoPanel;
    private ArrayList<Database.UserInfo> userInfos;

    public EditUserInfoDialog(Frame parent, UserManagementTab userManagementTab) {
	super(parent, true);
	this.parent = parent;
	
	userInfos = new ArrayList<Database.UserInfo>();
	//editUserInfoPanel = new EditUserInfoPanel(this);
	changeUserInfoPanel = new ChangeUserInfoPanel(this, userManagementTab);

	setTitle("Editera anv�ndarinformation");
	setDefaultCloseOperation(DISPOSE_ON_CLOSE);

	//getContentPane().add(editUserInfoPanel, BorderLayout.CENTER);
	getContentPane().add(changeUserInfoPanel, BorderLayout.CENTER);
	pack();
	setResizable(false);
	setLocation(parent.getSize().width/2-getSize().width/2,
		    parent.getSize().height/2-getSize().height/2);
	setLocationRelativeTo(parent);
    }

    public void setUsers(String[] usernames) {
	userInfos.clear();
	for(String currentUser : usernames) {
	    userInfos.add(Database.getInstance().getUserInfo(currentUser));
	}
	setTitle("Editera anv�ndarinformation (1/" + usernames.length + ")");
    }
    
    public void reset() {
	changeUserInfoPanel.setUserInfos(userInfos);
	changeUserInfoPanel.reset();
	setLocation(parent.getSize().width/2-getSize().width/2,
		    parent.getSize().height/2-getSize().height/2);
	setLocationRelativeTo(parent);
    }
}
