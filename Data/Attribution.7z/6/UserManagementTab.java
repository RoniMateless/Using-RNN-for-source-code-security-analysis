/*-
 * Copyright (C) 2005 Erik Larsson, Lars Helander
 * 
 * All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

package mathgame.login;

import mathgame.common.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class UserManagementTab extends JPanel {
    public static final int LEFT_INSETS = 10;
    public static final int RIGHT_INSETS = 10;
    public static final int TOP_INSETS = 5;
    public static final int BOTTOM_INSETS = 5;
    public static final int PREFERRED_WIDTH = 510;

    private JPanel addUserPanel;
    private UserListPanel userListPanel;


    public UserManagementTab(Frame parent) {
        addUserPanel = new AddUserPanel(parent);
        userListPanel = new UserListPanel(parent, this);
	
        setLayout(null);

        add(addUserPanel);
        add(userListPanel);

	//addUserPanel.setSize(510, 90);
	addUserPanel.setSize(addUserPanel.getPreferredSize());
	userListPanel.setSize(userListPanel.getPreferredSize());
	
	addUserPanel.setLocation(LEFT_INSETS+getInsets().left, TOP_INSETS+getInsets().top);
	userListPanel.setLocation(addUserPanel.getLocation().x,
				  addUserPanel.getLocation().y+addUserPanel.getSize().height);

	Component limitingX = addUserPanel;
	Component limitingY = userListPanel;
	int minSizeX = LEFT_INSETS+getInsets().left+limitingX.getSize().width+RIGHT_INSETS+getInsets().right;
	int minSizeY = TOP_INSETS+getInsets().top+limitingY.getLocation().y+limitingY.getSize().height+BOTTOM_INSETS+getInsets().bottom;
	Dimension preferredSize = new Dimension(getPreferredSize().width+minSizeX, getPreferredSize().height+minSizeY);
	setPreferredSize(preferredSize);
	setMinimumSize(preferredSize);
    }
    public void updateUserlist() {
	userListPanel.updateUserlist();
    }

    private class AddUserPanel extends JPanel {
	public static final int LEFT_INSETS = 5;
	public static final int RIGHT_INSETS = 5;
	public static final int TOP_INSETS = 0;
	public static final int BOTTOM_INSETS = 0;
	/* addUserPanel */
	private NewUserDialog addStudentDialog;
	private NewUserDialog addTeacherDialog;
	private FixedWidthTextArea addUserDescriptionPane;
	private JButton addStudentButton;
	private JButton addTeacherButton;
	
	public AddUserPanel(Frame parent) {
	    int width = UserManagementTab.PREFERRED_WIDTH - UserManagementTab.LEFT_INSETS - UserManagementTab.RIGHT_INSETS;
	    
	    setLayout(null);
	    setBorder(new TitledBorder("L\u00e4gg till/Ta bort anv\u00e4ndare"));

	    addUserDescriptionPane = new FixedWidthTextArea(width-getInsets().left-getInsets().right-LEFT_INSETS-RIGHT_INSETS);
	    addStudentButton = new JButton();
	    addTeacherButton = new JButton();
	    addStudentDialog = new NewUserDialog(parent, false);
	    addTeacherDialog = new NewUserDialog(parent, true);
	    
	    addStudentButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent evt) {
			addStudentButtonActionPerformed(evt);
		    }
		});
	    addStudentButton.setText("L\u00e4gg till elev...");
	    add(addStudentButton);
	    addStudentButton.setSize(addStudentButton.getPreferredSize());
	    addStudentButton.setLocation(10, 60);
	    
	    addTeacherButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent evt) {
			addTeacherButtonActionPerformed(evt);
		    }
		});
	    addTeacherButton.setText("L\u00e4gg till l\u00e4rare...");
	    add(addTeacherButton);
	    addTeacherButton.setSize(addTeacherButton.getPreferredSize());
	    addTeacherButton.setLocation(120, 60);
	    
	    addUserDescriptionPane.setText("H\u00e4r kan du l\u00e4gga till nya anv\u00e4ndare till databasen. Endast Superuser kan l\u00e4gga till nya l\u00e4rare, medan l\u00e4rare endast kan l\u00e4gga till elever.");
	    addUserDescriptionPane.setOpaque(false);
	    add(addUserDescriptionPane);
	    addUserDescriptionPane.setSize(addUserDescriptionPane.getPreferredSize());
	    addUserDescriptionPane.setLocation(getInsets().left+LEFT_INSETS, getInsets().top+TOP_INSETS);
	    setPreferredSize(new Dimension(width, addTeacherButton.getLocation().y+addTeacherButton.getSize().height+BOTTOM_INSETS+getInsets().bottom));
	}

	private void addStudentButtonActionPerformed(ActionEvent evt) {
	    addStudentDialog.reset();
	    addStudentDialog.setVisible(true);
	    updateUserlist();
	}
	private void addTeacherButtonActionPerformed(ActionEvent evt) {
	    addTeacherDialog.reset();
	    addTeacherDialog.setVisible(true);	    
	    updateUserlist();
	}
    }
    
    private class UserListPanel extends JPanel {
	public static final int LEFT_INSETS = 5;
	public static final int RIGHT_INSETS = 5;
	public static final int TOP_INSETS = 0;
	public static final int BOTTOM_INSETS = 0;
	/* userListPanel */
	private JPanel buttonsPanel;
	private JButton updateUserlistButton;
	private JButton editUserInfoButton;
	private JButton removeUserButton;
	private UserList userList;
	private Frame parent;
	private EditUserInfoDialog editUserInfoDialog;

	public UserListPanel(Frame parent, UserManagementTab userManagementTab) {
	    this.parent = parent;

	    int width = UserManagementTab.PREFERRED_WIDTH - UserManagementTab.LEFT_INSETS - UserManagementTab.RIGHT_INSETS;

	    buttonsPanel = new JPanel();
	    updateUserlistButton = new JButton();
	    editUserInfoButton = new JButton();
	    removeUserButton = new JButton();
	    userList = new UserList();
	    editUserInfoDialog = new EditUserInfoDialog(parent, userManagementTab);
	    
	    setLayout(new BorderLayout());

	    setBorder(new TitledBorder("Anv\u00e4ndarlista"));

	    
	    add(userList, BorderLayout.CENTER);
	    //userList.setSize(490, 180);
	    //userList.setLocation(10, 20);
	    
	    buttonsPanel.setLayout(new FlowLayout());

	    updateUserlistButton.setText("Uppdatera anv\u00e4ndarlista");
	    updateUserlistButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent evt) {
			updateUserlist();
		    }
		});
	    buttonsPanel.add(updateUserlistButton);
	    //updateUserlistButton.setSize(updateUserlistButton.getPreferredSize());
	    //updateUserlistButton.setLocation(10, 210);

	    removeUserButton.setText("Ta bort anv\u00e4ndare");
	    removeUserButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent evt) {
			removeUser();
		    }
		});
	    buttonsPanel.add(removeUserButton);
	    //removeUserButton.setSize(removeUserButton.getPreferredSize());
	    //removeUserButton.setLocation(170, 210);

	    editUserInfoButton.setText("Editera anv\u00e4ndarinformation...");
	    editUserInfoButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent evt) {
			editUserInfo();
		    }
		});
	    buttonsPanel.add(editUserInfoButton);
	    //editUserInfoButton.setSize(editUserInfoButton.getPreferredSize());
	    //editUserInfoButton.setLocation(300, 210);
	    //setPreferredSize(new Dimension(width, getPreferredSize().height));//editUserInfoButton.getLocation().y+editUserInfoButton.getSize().height+BOTTOM_INSETS+getInsets().bottom));
	    
	    add(buttonsPanel, BorderLayout.SOUTH);
	}
	public void updateUserlist() {
	    userList.refreshList();
	}
	public void removeUser() {
	    /*System.out.println("Selected usernames:");
	    for(String s : userList.getSelectedUsernames())
	    System.out.println("  " + s);*/
	    String[] usernames = userList.getSelectedUsernames();
	    if(usernames.length < 1)
		JOptionPane.showMessageDialog(parent, "Du har inte valt n�gon anv�ndare", "Fel", JOptionPane.ERROR_MESSAGE);
	    else {
		String message = "Vill du verkligen ta bort " + (usernames.length == 1?"\"" + usernames[0] + "\"":"dessa " + usernames.length + " anv�ndare") + "?";
		if(JOptionPane.showConfirmDialog(parent, message, "Bekr�fta borttagande", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION) {
		    for(String currentUser : usernames) {
			System.out.println("Removing " + currentUser);
			Database.getInstance().removeUser(currentUser);
		    }
		    updateUserlist();
		}
	    }
	}
	public void editUserInfo() {
	    String[] usernames = userList.getSelectedUsernames();
	    if(usernames.length > 0) {
		editUserInfoDialog.setUsers(userList.getSelectedUsernames());
		editUserInfoDialog.reset();
		editUserInfoDialog.setVisible(true);
	    }
	    else
		JOptionPane.showMessageDialog(parent, "Du har inte valt n�gra anv�ndare att �ndra information f�r", "Fel", JOptionPane.ERROR_MESSAGE);
	}
    }
}
