/*-
 * Copyright (C) 2004 Delby Arrospide, Niloofar Ghassemino, Lars Helander, Taghrid Hodroj,
 *                    Magnus Johansson, Caroline Koch, Erik Larsson, Helena Nilsson
 * 
 * All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

package mathgame.common;

import java.awt.*;
import javax.swing.*;

/* 
 * Test program for the TextSign class.
 */
public class DrawArbitraryTextSign {
    public static void main(String[] args) {
 	JComponent jc = new JComponent() {
		TextSign signToDraw;
		{
		    signToDraw = new TextSign(0, 0, "Hej, det h�r �r en skylt!");
		    setPreferredSize(new Dimension(signToDraw.width, signToDraw.height));
		    setMinimumSize(new Dimension(signToDraw.width, signToDraw.height));
		    setMaximumSize(new Dimension(signToDraw.width, signToDraw.height));
		}
		
 		public void paintComponent(Graphics g) {
 		    super.paintComponent(g);
 		    signToDraw.show(g, 0, 0);
 		}
 	    };
	JFrame frame = new JFrame();
	
	frame.getContentPane().add(jc);
	frame.pack();
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.setVisible(true);
    }
}
