package mathgame.common;

public class SpriteType {

    public static final int BACKGROUND = 10;
    public static final int TILE = 20;
    public static final int MONSTER1 = 31;
    public static final int MONSTER2 = 32;
    public static final int CANDY1 = 41;
    public static final int CANDY2 = 42;
    public static final int CANDY3 = 43;
    public static final int CANDY4 = 44;
    public static final int CANDY5 = 45;
    public static final int CANDY6 = 46;
    public static final int CANDY7 = 47;
    public static final int CANDY8 = 48;
    public static final int CANDY9 = 49;
    public static final int BOX_QUESTION = 90;
    public static final int BOX_100P = 91;
    public static final int BOX_HEART = 92;
    public static final int RANDOM_BOX = 93;
    public static final int DOOR = 110;
    public static final int CLOSED_DOOR = 111;
    public static final int LADDER = 120;

    public String imageFilename;
    public int type;
    
    public SpriteType(String imageFilename, int type){
	this.imageFilename = imageFilename;
	this.type = type;
    }

    public int getPreferredLayer(){
	return getPreferredLayer(type);
    }

    public static int getPreferredLayer(int type){
	switch(type){
	case BACKGROUND:
	    return 0;
	case LADDER:
	case DOOR:
	case CLOSED_DOOR:
	    return 1;
	default:
	    return 2; // Default layer is in level with player
     	}
    }

}
