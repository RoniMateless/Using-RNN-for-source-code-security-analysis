package mathgame.game;

import mathgame.common.*;
import java.awt.*;

public class StatusBar {

    public static final int maxHealth = 10;
    public static final int maxLives = 3;

    private long score = 0;
    private int time = 500;
    private int lives = 3; 
    private int health = 10;
    private int questionsCorrect = 0;
    private int maxQuestions = 3;
    private int key = 0;  // 0 = no key, 1 = key 

    private long oldscore = -1;
    private int oldtime = -1;
    private int oldlives = -1;
    private int oldhealth = -1;
    private int oldquestionsCorrect = -1;
    private int oldkey = -1;

    private Rectangle timeRect = new Rectangle();
    private Rectangle scoreRect = new Rectangle();
    private Rectangle questionsRect = new Rectangle();

    private boolean paused = false;
    private boolean paintBorder = true;
    private static final int insets = 10;

    private long prevTime = System.currentTimeMillis();


    /// OFFSETS in x-direction ///
    private int heartsOffsetX;
    private int healthBarsOffsetX;
    private int questionsOffsetX;
    private int keyOffsetX;
    private int timeOffsetX;
    private int scoreOffsetX;

    private Image[] numbers;
    private Image[] numbers2;
    private Image[] hearts;
    private Image[] healthBars;
    private Image[] questionMark;
    private Image[] cross;
    private Image[] slash;
    private Image[] keys;
    
    private Game game;
    int width, height;

    public StatusBar(Game game, int width, int height){
	this.game = game;
	this.width = width;
	this.height = height;
	initPics();
	computeOffsets();
    }

    public void pause(boolean paused){
	this.paused = paused;
    }

    public void addScore(int iscore){
	oldscore = score;
	score += iscore;
    }
    
    public int getHealth() { return health; }

    public int getLives() { return lives; }

    public boolean hasKey() { return key == 1; } 

    public void addHealth(int ihealth){
	oldhealth = health;
	health += ihealth;
	if(health > maxHealth) {
	    health = maxHealth;
	    
	}
	else if(health <= 0) {
	    if(lives > 0) {
		health = maxHealth;
		addLives(-1);
		SwingWorker sw = new SwingWorker() {
			public Object construct() {
			    game.signalDeath();
			    return null;
			}
		    };
		sw.start();
	    }
	    else {
		SwingWorker sw = new SwingWorker() {
			public Object construct() {
			    game.signalGameOver();
			    return null;
			}
		    };
		sw.start();
	    }
	}
    }

    public void addLives(int ilives){
	oldlives = lives;
        lives += ilives;
	if(lives > maxLives){
	    lives = maxLives;
	    health = maxHealth;
	}
	else if(lives <= 0){
	    lives = 0;
	}
    }

    public void addQuestionCorrect(){
	oldquestionsCorrect = questionsCorrect;
	questionsCorrect++;
	if(questionsCorrect >= maxQuestions){
	    key = 1;  // We have the key
	}
    }

    public void resetQuestions(int maxQuestions){
	this.maxQuestions = maxQuestions;
	oldquestionsCorrect = -1;
	questionsCorrect = 0;
	oldkey = -1;
	if(maxQuestions == 0) 
	    key = 1;
	else
	    key = 0;
    }

    public void setTime(int itime){
	if(itime >= 0){
	    oldtime = time;
	    time = itime;
	}
    }

    private boolean paintBackground = true;

    public void show(Graphics newg, int viewPortWidth, int viewPortHeight){
	//Graphics newg = g.create(viewPortWidth-width, viewPortHeight, width, height);
	if(paintBackground){
	    paintBackground(newg);
	    paintBackground = false;
	}
	if(oldscore != score){
	    drawInt(newg, score, scoreOffsetX, insets, scoreRect);
	    oldscore = score;
	}
	long tmp;
	if(!paused && (tmp = System.currentTimeMillis()) - prevTime >= 1000){
	    prevTime = tmp;
	    oldtime = time;
	    time--;
	    if(time <= 0 && health > 0){
	        addHealth(-1);
	    }
	}
	if(oldtime != time){
	    drawInt(newg, time, timeOffsetX, insets, timeRect);
	    oldtime = time;
	}
	if(oldlives != lives){
	    drawLives(newg);
	    oldlives = lives;
	}
	if(oldhealth != health){
	    drawHealth(newg);
	    oldhealth = health;
	}
	if(oldquestionsCorrect != questionsCorrect){
	    drawQuestions(newg);
	    oldquestionsCorrect = questionsCorrect;
	}
	if(oldkey != key){
	    drawKey(newg);
	    oldkey = key;
	}
    }

    private void paintBackground(Graphics g){
	g.setColor(Color.white);
	g.fillRect(0, 0, width, height);
	if(paintBorder){
	    g.setColor(Color.blue);
	    g.drawLine(0, 0, width, 0);
	    g.drawLine(0, 1, width, 1);
	}

    }

    private void paintWhite(Graphics g, Rectangle r){
	Color oldcolor = g.getColor();
	g.setColor(Color.white);
	g.fillRect(r.x, r.y, r.width, r.height);
	g.setColor(oldcolor);
    }

    private void drawInt(Graphics g, long num, int x, int y, Rectangle clipRect){
	paintWhite(g, clipRect);
	clipRect.y = y;
	clipRect.height = numbers[0].getHeight(null);
	int x2 = x + numbers[0].getWidth(null);
	if(num < 0) num = 0;
	String s = ""+num; //Cast num to a String
	for(int i=s.length()-1; i >= 0; i--){
	    Image toDraw = numbers[s.charAt(i) - '0'];
	    g.drawImage(toDraw, x, y, null);
	    x -= toDraw.getWidth(null);
	}
	clipRect.x = x;
	clipRect.width = x2-x;
    }

    private void drawLives(Graphics g){
	if(lives < 0) lives = 0;
	if(lives > 3) lives = 3;
	g.drawImage(hearts[lives], heartsOffsetX, (int) (1.5*insets), null);
    }

    private void drawHealth(Graphics g){
	if(health < 0) health = 0;
	if(health > 10) health = 10;
	g.drawImage(healthBars[health], healthBarsOffsetX, insets, null); 
    }

    private void drawQuestions(Graphics g){
	paintWhite(g, questionsRect);
	int offsetY = (int) (1.5*insets);
     	int offsetX = questionsOffsetX;
	int startOffsetX = offsetX;
	g.drawImage(questionMark[0], offsetX, offsetY, null);
	offsetX += questionMark[0].getWidth(null);
	g.drawImage(cross[0], offsetX, offsetY, null);
	offsetX += cross[0].getWidth(null);
	if(questionsCorrect < 0) questionsCorrect = 0;
	String s = ""+questionsCorrect;
	for(int i=0; i < s.length(); i++){
	    Image toDraw = numbers2[s.charAt(i) - '0'];
	    g.drawImage(toDraw, offsetX, offsetY, null);
	    offsetX += toDraw.getWidth(null);
	}
	g.drawImage(slash[0], offsetX, offsetY, null);
	offsetX += slash[0].getWidth(null);
	if(maxQuestions < 0) maxQuestions = 0;
	s = ""+maxQuestions;
	for(int i=0; i < s.length(); i++){
	    Image toDraw = numbers2[s.charAt(i) - '0'];
	    g.drawImage(toDraw, offsetX, offsetY, null);
	    offsetX += toDraw.getWidth(null);
	}
	int endOffsetX = offsetX;
	questionsRect.x = startOffsetX;
	questionsRect.y = offsetY;
	questionsRect.width = endOffsetX - startOffsetX;
	questionsRect.height = height-offsetY;
    }

    private void drawKey(Graphics g){
	g.drawImage(keys[key], keyOffsetX, (int) (0.5*insets), null);
    }

    private void initPics(){
	numbers = new Image[10];
	String path = "mathgame/common/mbilder/status_score_";
	for(int i=0; i<numbers.length; i++)
	    numbers[i] = ImageArchive.getImage(path +i +".png");

	numbers2 = new Image[10];
	path = "mathgame/common/mbilder/status_questions_";
	for(int i=0; i<numbers2.length; i++)
	    numbers2[i] = ImageArchive.getImage(path +i +".png");

	hearts = new Image[4];
	path = "mathgame/common/mbilder/status_hearts_";
	for(int i=0; i<hearts.length; i++)
	    hearts[i] = ImageArchive.getImage(path +i +"_full.png");

	healthBars = new Image[11];
	path = "mathgame/common/mbilder/status_health_";
	for(int i=0; i<healthBars.length; i++)
	    healthBars[i] = ImageArchive.getImage(path +i +"_full.png");

	path = "mathgame/common/mbilder/status_questions_";

	questionMark = new Image[1];
	questionMark[0] = ImageArchive.getImage(path +"questionmark.png");
	
	cross = new Image[1];
	cross[0] = ImageArchive.getImage(path +"cross.png");

	slash = new Image[1];
	slash[0] = ImageArchive.getImage(path +"slash.png");
       
	keys = new Image[2];
	path = "mathgame/common/key/";
	keys[0] = ImageArchive.getImage(path +"key_grey.png");
	keys[1] = ImageArchive.getImage(path +"key.png");

	scalePics(numbers, height - 2*insets);
	scalePics(numbers2, height - 3*insets);
	scalePics(hearts,  height - 3*insets);
	scalePics(healthBars, height - 2*insets);
	scalePics(keys, height - insets);
	scalePics(questionMark, height - 3*insets);
	scalePics(cross, height - 3*insets);
	scalePics(slash, height - 3*insets);
    }

    private void computeOffsets(){
	heartsOffsetX = insets;
	healthBarsOffsetX = heartsOffsetX + hearts[0].getWidth(null) + 3*insets;
	questionsOffsetX = healthBarsOffsetX + healthBars[0].getWidth(null) + 3*insets;
	keyOffsetX = questionsOffsetX + questionMark[0].getWidth(null) + cross[0].getWidth(null) +
	    slash[0].getWidth(null) + 4*numbers2[0].getWidth(null) + 2*insets;
	timeOffsetX = keyOffsetX + keys[0].getWidth(null) + 5*numbers[0].getWidth(null) + insets;
	scoreOffsetX = width - insets - numbers[0].getWidth(null);
    }
    
    private void scalePics(Image[] pics, int newheight){
	int oldheight = -1;
	while(oldheight == -1)
	    oldheight = pics[0].getHeight(null);
	int oldwidth = -1;
	while(oldwidth == -1)
	    oldwidth = pics[0].getWidth(null);
	for(int i=0; i<pics.length; i++)
	    pics[i] = pics[i].getScaledInstance(oldwidth*newheight/oldheight, newheight, 
						      Image.SCALE_DEFAULT);
    }

}
