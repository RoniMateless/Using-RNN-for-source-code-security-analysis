/*-
 * Copyright (C) 2004 Delby Arrospide, Niloofar Ghassemino, Lars Helander, Taghrid Hodroj,
 *                    Magnus Johansson, Caroline Koch, Erik Larsson, Helena Nilsson
 * 
 * All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

package mathgame.common;
import java.io.DataInputStream;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.File;
import java.io.EOFException;
import java.io.IOException;
import java.net.URL;
import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;

public class MGSv1Parser {
    private URL mgsUrl;
    private boolean hasRead;
    private Vector<MGSv1Frame> frames;
    private Hashtable<String, MGSv1Frame> frameTable;

    public MGSv1Parser(URL mgsUrl) {
	this.mgsUrl = mgsUrl;
	hasRead = false;
	frames = new Vector<MGSv1Frame>();
	frameTable = new Hashtable<String, MGSv1Frame>();
    }
    
    public MGSv1Parser(URL mgsUrl, boolean readImmediately) {
	this(mgsUrl);
	if(readImmediately)
	    read();
    }
    public MGSv1Parser(File f) {
	this(MGSv1Frame.toURL(f));
    }
    
    public MGSv1Parser(File f, boolean readImmediately) {
	this(MGSv1Frame.toURL(f), readImmediately);
    }
    
    public synchronized void read() {
	try {
	    DataInputStream dbf = new DataInputStream(new BufferedInputStream(mgsUrl.openStream()));
	    long currentPosition = 0;
	    
	    byte[] header = new byte[3];
	    if(dbf.read(header, 0, 3) == -1)
		throw new RuntimeException();
	    else if(!(header[0] == 'M' && header[1] == 'G' && header[2] == 'S'))
		throw new RuntimeException("Incorrect header");
	    currentPosition += 3;
	    
	    int version = dbf.readUnsignedByte();
	    ++currentPosition;
	    if(version != 1)
		throw new RuntimeException("Incorrect version number");
	    
	    int intRead = dbf.readInt();
	    //int counter = 0;
	    while(true) {
		//System.out.println("Frame " + ++counter + " read:");		
		int headerSize = intRead;
		//System.out.println("  headerSize=" + headerSize);
		int frameSize = dbf.readInt();
		//System.out.println("  frameSize=" + frameSize);
		String frameIdentifier = dbf.readUTF();
		//System.out.println("  frameIdentifier=" + frameIdentifier);
		String contentType = dbf.readUTF();
		//System.out.println("  contentType=" + contentType);
		long dataOffsetInFile = currentPosition+headerSize;
		//System.out.println("  dataOffsetInFile=" + dataOffsetInFile);
		
		MGSv1Frame currentFrame = new MGSv1Frame(mgsUrl, dataOffsetInFile, headerSize, 
							 frameSize, frameIdentifier, contentType);
		int bytesToSkip = currentFrame.frameSize-currentFrame.headerSize;
		//System.out.println("  Skipping " + bytesToSkip + " bytes...");
		int bytesSkipped = dbf.skipBytes(bytesToSkip);
		//System.out.println("  Skipped " + bytesSkipped + " bytes...");
		if(bytesToSkip != bytesSkipped)
		    System.out.println("<MGSv1Parser.read()>ERROR: DataInputStream.skipBytes() did not skip all bytes!");
		
		currentPosition += currentFrame.frameSize;
		
		frames.add(currentFrame);
		frameTable.put(currentFrame.getFrameIdentifier(), currentFrame);
		try {
		    intRead = dbf.readInt();
		}
		catch(EOFException ee) {
		    break;
		}
	    }
	    dbf.close();
	    hasRead = true;
	}
	catch(EOFException ee) {
	    ee.printStackTrace(); //Egentligen borde det kanske inte skrivas ut, inget �r inkonsistent. Men filen �r skadad.
	}
	catch(IOException ioe) {
	    ioe.printStackTrace();
	}
	if(!hasRead) {
	    frames.clear();
	    frameTable.clear();
	}
    }

    public MGSv1Frame getFrame(String identifier) {
	if(hasRead) {
	    return frameTable.get(identifier);
	    /*
	    for(int i = 0; i < frames.size(); i++) {
		MGSv1Frame currentFrame = frames.get(i);
		if(currentFrame.frameIdentifier.equals(identifier))
		    return currentFrame;
	    }
	    return null;
	    */
	}
	else
	    throw new RuntimeException("The file has not been read yet!");
    }
    
    public Vector<MGSv1Frame> getFrames() {
	Vector<MGSv1Frame> result = new Vector<MGSv1Frame>();
	for(Enumeration<MGSv1Frame> e = frames.elements() ; e.hasMoreElements() ;)
	    result.add(e.nextElement());
	
	return result;
    }
    
    public boolean hasRead() {
	return hasRead;
    }

    public int framesRead() {
	return frames.size();
    }
}
