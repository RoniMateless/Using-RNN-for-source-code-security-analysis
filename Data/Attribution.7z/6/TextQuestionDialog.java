package mathgame.question;

import mathgame.common.TextQuestion;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;

public class TextQuestionDialog extends JFrame {

    private int numberOfAnswers;
    int correctAnswer = -1;

    private QuestionEditor parent;

    private JTextField questionField = new JTextField(20);
    private JTextField[] answerField;


    public TextQuestionDialog(QuestionEditor iparent, TextQuestion iquestion){
	parent = iparent;
	numberOfAnswers = iquestion.answers.length;
	answerField = new JTextField[numberOfAnswers];
	correctAnswer = iquestion.correctAnswer;

	setUpGUI();

	questionField.setText(iquestion.question);
	for(int i=0; i<answerField.length; i++)
	    answerField[i].setText(iquestion.answers[i]);

    }

    public TextQuestionDialog(QuestionEditor iparent, int inumberOfAnswers){
	parent = iparent;
	numberOfAnswers = inumberOfAnswers;
	answerField = new JTextField[numberOfAnswers];

	setUpGUI();
    }

    private void setUpGUI(){
	Container cont = getContentPane();

	JPanel[] panels = new JPanel[answerField.length+1];
	for(int i=0; i<panels.length; i++){
	    panels[i] = new JPanel();
	    panels[i].setLayout(new BorderLayout());
	}

	JLabel question = new JLabel("Fr�ga:");
	
	panels[0].add(question, BorderLayout.NORTH);
	panels[0].add(questionField);
	
	for(int i=1; i<answerField.length+1; i++){
	    answerField[i-1] = new JTextField(20);
	    JLabel answer = new JLabel("Svar #" +i +":");
	    panels[i].add(answer, BorderLayout.NORTH);
	    panels[i].add(answerField[i-1]);
	}

	cont.setLayout(new GridLayout(0,1));
	for(int i=0; i<panels.length; i++)
	    cont.add(panels[i]);

	((JComponent) cont).setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

	pack();

	Rectangle parRect = parent.getBounds();
	setLocation(parRect.x+parRect.width, parRect.y);
	fitOnScreen();
	setTitle("Textfr�ga");
	setResizable(false);
	addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent e){
		    parent.dispose("tqd");
		}
	    });
	
	setVisible(true);
    }

    public void saveQuestion(String filename) throws Exception {
	DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(filename)));

	out.writeInt(QuestionEditor.HEADER);
	out.writeInt(QuestionEditor.TEXT);
	out.writeInt(answerField.length);
	out.writeInt(correctAnswer);
	out.writeInt(QuestionEditor.FOOTER);

	char[] qData = questionField.getText().toCharArray();
	out.writeInt(qData.length);
	for(int i=0; i<qData.length; i++)
	    out.writeChar(qData[i]);
	
	for(int i=0; i<answerField.length; i++){
	    char[] aData = answerField[i].getText().toCharArray();
	    out.writeInt(aData.length);
	    for(int j=0; j<aData.length; j++)
		out.writeChar(aData[j]);
	}

	out.close();
    }
    

    private void fitOnScreen(){
	Dimension screenDim = Toolkit.getDefaultToolkit().getScreenSize();
	Rectangle frame = getBounds();
	if(frame.x+frame.width > screenDim.width) frame.x = screenDim.width-frame.width;
	if(frame.y+frame.height > screenDim.height) frame.y = screenDim.height-frame.height;
	if(frame.x < 0) frame.x = 0;
	if(frame.y < 0) frame.y = 0;
	setBounds(frame);
    }

}
