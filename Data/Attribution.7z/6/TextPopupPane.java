package mathgame.game;

import mathgame.common.*;
import java.awt.*;
import java.awt.font.*;
import java.awt.event.*;
import java.awt.image.*;
import java.awt.geom.*;

public class TextPopupPane extends PopupPane {

    private Game game;
    private int widthIterator;
    private int hGap = 5;
    private int vGap = 10;
   
    private int questionHGap = 100;
    private int ansHGap = 40;
    

    private AWTEventListener listener;

    private boolean opaque = false;
    private boolean trueTransparency = false;
    private boolean paintBorder = true;

    private Color alphaColor = new Color(255,255,255,127);
    private Color alphaColorBlue = new Color(192,192,255,127);
    private Color stringColor = Color.blue;
     
    private FormattedString question;
    private FormattedString[] answers;
    private int correctAnswer;

    private TextQuestion tq;

    private int questionOffset = 100;
    private int[] offsets;

    private Font font = new Font("Dialog", Font.BOLD, 15);

    private int selected = 0;

    public TextPopupPane(Game game, TextQuestion question, int width, int height){
	this.game = game;
	this.tq = question;
	this.width = width;
	this.height = height;
	widthIterator = 0;

	transparentSurface = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
	
	formatQuestion(question);
	computeOffsets(10);

	listener = new AWTKeyListener();
	Toolkit.getDefaultToolkit().addAWTEventListener(listener, AWTEvent.KEY_EVENT_MASK);
    }

    private void formatQuestion(TextQuestion q){
	question = format(q.question, vGap, vGap);
	answers = new FormattedString[q.answers.length];
	correctAnswer = q.correctAnswer;
	for(int i=0; i<q.answers.length; i++)
	    answers[i] = format(q.answers[i], 3*vGap, vGap);
    }


    // ATT G�RA: Antag tokens[i].width > width!!
    private FormattedString format(String us, int leftGap, int rightGap){
	Graphics2D g = (Graphics2D) transparentSurface.getGraphics();
	g.setFont(font);
	FontRenderContext frc = g.getFontRenderContext();
	String[] tokens = us.split("\\s");
	String fs = "";
	String currentLine = "";
	int numberOfLines = 1;
	for(int i=0; i<tokens.length; i++){
	    currentLine += tokens[i];
	    TextLayout tl = new TextLayout(currentLine, font, frc);
	    Rectangle bounds = tl.getBounds().getBounds();
	    if(bounds.width + leftGap + rightGap <= width){
		fs += tokens[i]+" ";
		currentLine += " ";
	    }
	    else {
		fs += "\n"+tokens[i]+" ";
		currentLine = tokens[i]+" ";
		numberOfLines++;
	    }
	}
	TextLayout test = new TextLayout("fj", font, frc);
	int height = test.getBounds().getBounds().height;
	int totalHeight = (height+hGap)*numberOfLines;
	return new FormattedString(fs, height, totalHeight);
    }

    private void computeOffsets(int recursion){
	offsets = new int[answers.length];
	int total;
	int off = questionOffset + question.totalHeight + questionHGap;
	for(int i=0; i<offsets.length; i++){
	    offsets[i] = off;
	    off += answers[i].totalHeight;
	    off += ansHGap;
	}
	if(recursion == 0) return;

	if(offsets[offsets.length-1]+answers[answers.length-1].totalHeight > height-questionOffset*1.2){
	    float shrinkFactor = 0.8f;
	    questionOffset = (int) (questionOffset * shrinkFactor);
	    questionHGap = (int) (questionHGap * shrinkFactor);
	    ansHGap = (int) (ansHGap * shrinkFactor);
	    computeOffsets(--recursion);
	}
    }

    public void show(Graphics newg, int viewPortWidth, int viewPortHeight){
	//Graphics newg = g; //g.create(viewPortWidth-widthIterator, viewPortHeight-height, width, height);
	dx = viewPortWidth - widthIterator;
	if(!closed){
	    if(!trueTransparency)
		fixTransparency();
	    Color c = newg.getColor();
	    paintBackground(newg);
	    newg.setColor(c);
	    newg.setFont(font);
	    newg.setColor(stringColor);
	    drawQuestion(newg);
	    drawAnswers(newg);
	    paintSelection(newg);
	}
	if(closing){
	    widthIterator -= 20;
	    game.getRepaintManager().setDirty(game.viewport.x+game.viewport.width-width,
					      game.viewport.y+game.viewport.height-height,
					      width-widthIterator, height);
	    showResult(newg);
	    if(widthIterator < 0){
		closed = true;
		if(timeToShowResult <= 0){
		    transparentSurface.flush();
		    game.disposePopupPane();
		}
		else timeToShowResult--;
	    }
	}
	else if(widthIterator < width)
	    widthIterator += 20;
    }
    
    private void fixTransparency(){

	int whiteLow = (int) (0xFF >> 1);
	int whiteMid = (int) (0xFF00 >> 1);
	int whiteHigh = (int) (0xFF0000 >> 1);

	DataBufferInt db = (DataBufferInt) transparentSurface.getRaster().getDataBuffer();
			
	int[] data = db.getData();
	
	for(int i=0; i<data.length; i++){

	    int red = data[i] & 0xFF0000;
	    int green = data[i] & 0xFF00;
	    int blue = data[i] & 0xFF;
	    
	    red >>= 1;
	    green >>= 1;
	    blue >>= 1;
	    
	    red += whiteHigh;
	    green += whiteMid;
	    blue += whiteLow;
	    
	    data[i] = (red & 0xFF0000) + (green & 0xFF00) + (blue & 0xFF);
	}

	// Pixel (x, y) = data[x + transparentSurface.width * y]
	// Now with this info we can fix the selection transparency

	int width = transparentSurface.getWidth();
	if(width == -1){
	    System.err.println("Fatal error in PopupPane.java, fixTransparency()");
	    System.exit(1);
	}
	for(int x=2; x <= width; x++){
	    for(int y=offsets[selected]-answers[selected].height - hGap; y <= offsets[selected]+answers[selected].totalHeight-answers[selected].height + hGap; y++){
		try {
		    data[x + width * y] = 0xC0C0FF; 
		    /*
		    int index = x + width * y;
		    int red = data[index] & 0xFF0000;
		    int green = data[index] & 0xFF00;
		    data[index] |= 0xFF;  // Mask in full blue 
		    red = (red >> 1) + (red >> 2) + (red >> 3); // While toning down red
		    green = (green >> 1) + (green >> 2) + (green >> 3); // and green
		    data[index] = (red & 0xFF0000) + (green & 0xFF00) + (data[index] & 0xFF);
		    */
		} catch(Exception e){
		    System.err.println("Error while painting selection in PopupPane.java, fixTransparency()"); 
		}
	    }
	}
    }
    
    private void paintBackground(Graphics g){
	if(trueTransparency){
	    if(opaque) g.setColor(Color.white);
	    else g.setColor(alphaColor);
	    g.fillRect(dx, 0, dx+widthIterator, height);
	}
	else {
	    int picWidth = transparentSurface.getWidth();
	    g.drawImage(transparentSurface, dx, 0, game.viewport.width, height, 
			picWidth-widthIterator, 0, picWidth, height, null);

	}
	if(paintBorder){
	    g.setColor(Color.blue);
	    g.drawLine(dx, 0, dx, height);
	    g.drawLine(dx+1, 0, dx+1, height);
	}		       
    }
    private int dx = 0;

    private void drawQuestion(Graphics g){
	//g.drawString(question.question, 10+dx, 100);
	//g.drawRect(10+dx,100-stringBounds.height,stringBounds.width,stringBounds.height);
	question.drawString(g, vGap+dx, questionOffset);
    }

    private void drawAnswers(Graphics g){
	for(int i=0; i<answers.length; i++){
	    g.drawString(""+(i+1)+". ", vGap+dx, offsets[i]);
	    answers[i].drawString(g, 3*vGap+dx, offsets[i]);
	}
    }

    private void paintSelection(Graphics g){
	int y = offsets[selected] - answers[selected].height - hGap;
	int y2 = offsets[selected] + answers[selected].totalHeight - answers[selected].height + hGap;
	if(trueTransparency){
	    g.setColor(alphaColorBlue);
	    g.fillRect(2+dx, y, dx+width, y2-y);
	}
	g.setColor(Color.blue);
	g.drawLine(2+dx, y, dx+width, y);
	g.drawLine(2+dx, y2, dx+width, y2);
    }

    public void showResult(Graphics g){
	Image result;
	if(selected == correctAnswer)
	    result = correct;
	else result = wrong;
	int x = game.viewport.width/2 - result.getWidth(null)/2;
	int y = game.viewport.height/2 - result.getHeight(null)/2;
	g.drawImage(result, x, y, null);
	game.getRepaintManager().setDirty(game.viewport.x+x, game.viewport.y+y, result.getWidth(null), result.getHeight(null));
    }

    private class AWTKeyListener implements AWTEventListener {
	public void eventDispatched(AWTEvent event){
	    KeyEvent e = (KeyEvent) event;
	    if(event.getID() == KeyEvent.KEY_PRESSED){
		// keyPressed(KeyEvent e)
		switch(e.getKeyCode()){
		case KeyEvent.VK_UP:
		    if(selected <= 0) selected = answers.length-1;
		    else selected--;
		    break;
		case KeyEvent.VK_DOWN:
		    if(selected >= answers.length-1) selected = 0;
		    else selected++;
		    break;
		case KeyEvent.VK_ENTER:
		    //The question has been answered
		    Toolkit.getDefaultToolkit().removeAWTEventListener(listener);
		    closing = true;
		    break;
		default:
		    if(e.getKeyCode() - '0' - 1 >= 0 && e.getKeyCode() - '0' - 1 < answers.length){
			selected = e.getKeyCode() - '0' - 1;
			Toolkit.getDefaultToolkit().removeAWTEventListener(listener);
			closing = true;
		    }
		    break;
		}
		    
	    }
	    if(closing){
		if(selected == correctAnswer)
		    game.statusBar.addQuestionCorrect();
		//game.reportQuestion(tq.question, tq.filename, selected == correctAnswer);

		if(game.popupPause) 
		    game.popupPause = false;
	    }

	    e.consume();
	}
    }
    
    private class FormattedString {

	String string;
	int height;
	int totalHeight;

	public FormattedString(){}
	
	public FormattedString(String s, int h, int tH){
	    string = s;
	    height = h;
	    totalHeight = tH;
	}
      
	public void drawString(Graphics g, int x, int y){
	    String[] t = string.split("\\n");
	    for(int i=0; i<t.length; i++){
		g.drawString(t[i], x, y);
		y += height; y += hGap;
	    }
	}
	
    }

}
